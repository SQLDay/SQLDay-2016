-- Memory buffers allocated for data pages
SELECT * FROM sys.dm_os_buffer_descriptors
WHERE database_id = DB_ID('Twitter')
AND page_type = 'DATA_PAGE'

-- Averall count of allocated pages and rows in memory
SELECT COUNT(*) AS Page_Count, SUM(row_count) AS Row_Count
FROM sys.dm_os_buffer_descriptors 
WHERE database_id = DB_ID('Twitter')
AND page_type = 'DATA_PAGE'

-- Dump of a last page of a first extent
DECLARE @db int = DB_ID('Twitter')
DBCC PAGE (@db, 1, 37095, 3) WITH TABLERESULTS