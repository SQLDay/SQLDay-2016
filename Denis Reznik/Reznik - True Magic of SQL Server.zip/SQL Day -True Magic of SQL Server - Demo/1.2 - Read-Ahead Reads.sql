USE StackOverflow
GO

SET STATISTICS IO ON
DBCC DROPCLEANBUFFERS

-- Speaker's Note
-- Include actual execution plan

SELECT Id FROM Users
