USE StackOverflow
GO

SELECT NULL
GO 1000

