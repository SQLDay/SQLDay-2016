SELECT p.physical_operator_name, p.cpu_time_ms, p.elapsed_time_ms, 
	p.lob_logical_read_count, p.physical_read_count, 
	p.row_count, p.first_row_time, p.last_row_time  
FROM sys.dm_exec_query_profiles p