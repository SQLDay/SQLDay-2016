USE [AdventureWorks2012]
GO

CREATE NONCLUSTERED INDEX [IX_TRANSACTIONHISTORY2_TRANSACTIONDATE3] ON [dbo].[bigTransactionHistory3]
(
	[TransactionDate] ASC
)
INCLUDE (ProductId) WITH (DROP_EXISTING = ON)
GO

SET STATISTICS IO ON

-- Query 1
SELECT p.Name, COUNT(*) FROM bigTransactionHistory3 h
INNER JOIN dbo.bigProduct p
	ON h.ProductId = p.ProductId
LEFT JOIN Production.Product pp
	ON p.Name = pp.Name
LEFT JOIN Production.ProductCostHistory pch
	ON pp.ProductId = pch.ProductId
WHERE p.SellStartDate BETWEEN DATEADD(YEAR, -10, GETDATE()) AND GETDATE()
	AND (pch.StandardCost > 10 OR pch.StandardCost IS NULL)
	AND h.TransactionDate = '01-01-2013'
GROUP BY p.Name
HAVING COUNT(*) > 1

-- Query 2 (16s)
SELECT TOP(10000) * FROM bigTransactionHistory h
INNER JOIN dbo.bigProduct p
	ON h.ProductId = p.ProductId
WHERE p.SellStartDate BETWEEN dbo.GetStartDate() AND dbo.GetFinishDate()

-- Clean Database
CREATE NONCLUSTERED INDEX [IX_TRANSACTIONHISTORY2_TRANSACTIONDATE3] ON [dbo].[bigTransactionHistory3]
(
	[TransactionDate] ASC
)
WITH (DROP_EXISTING = ON)
GO