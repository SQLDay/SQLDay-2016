USE AdventureWorks2014
GO

-- Speakers Note:
-- 1) Turn on "Actual Execution Plan"

SET STATISTICS IO ON
GO

CREATE INDEX IX_BIGPRODUCT_PRODUCTNUMBER
	ON dbo.bigProduct(ProductNumber)
GO

-- Wildcard at the end
SELECT ProductNumber FROM dbo.bigProduct
WHERE ProductNumber LIKE 'BL%';

-- Wildcard at the start
SELECT ProductNumber FROM dbo.bigProduct
WHERE ProductNumber LIKE '%1000';

ALTER TABLE dbo.bigProduct
	ADD ProductNumberReversed AS REVERSE(ProductNumber) PERSISTED
GO

CREATE INDEX IX_BIGPRODUCT_PRODUCTNUMBERREVERSED
	ON dbo.bigProduct(ProductNumberReversed)
GO

-- Effective way on searching by wildcard at the start
SELECT ProductNumberReversed FROM dbo.bigProduct
WHERE ProductNumberReversed LIKE REVERSE('%1000');

-- LIKE operation simplification
SELECT ProductNumber FROM dbo.bigProduct
WHERE ProductNumber LIKE 'BL%1000';

SET STATISTICS TIME ON
GO

-- Full scan in any case
SELECT ProductNumber FROM dbo.bigProduct
WHERE ProductNumber LIKE '%BL%';

DROP INDEX IX_BIGPRODUCT_PRODUCTNUMBERREVERSED ON dbo.bigProduct
GO

ALTER TABLE dbo.bigProduct
	DROP COLUMN ProductNumberReversed
GO

DROP INDEX IX_BIGPRODUCT_PRODUCTNUMBER ON dbo.bigProduct
GO

-- Making things faster
ALTER TABLE dbo.bigProduct
	ALTER COLUMN ProductNumber nvarchar(56) COLLATE Latin1_General_BIN2 
GO

ALTER TABLE dbo.bigProduct
	ALTER COLUMN ProductNumber nvarchar(56) COLLATE SQL_Latin1_General_CP1_CI_AS
GO