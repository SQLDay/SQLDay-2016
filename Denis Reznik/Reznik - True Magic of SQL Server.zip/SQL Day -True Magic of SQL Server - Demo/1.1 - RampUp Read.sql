USE Twitter
GO

SET STATISTICS IO ON
DBCC DROPCLEANBUFFERS

-- First leaf record in the index
SELECT TOP(1) * FROM Statuses
ORDER BY id 

-- Last record of the first extent
SELECT * FROM Statuses
WHERE id = 4145634002

-- First record of the second extent
SELECT * FROM Statuses
WHERE id = 4145762174
