﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace Workload1
{
    class Program
    {
        static void Main(string[] args)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["AdventureWorks"].ConnectionString;

            // Parameter Sniffing
            SqlConnection connection = new SqlConnection(connectionString);
            using (connection)
            {
                connection.Open();
                SqlCommand command = new SqlCommand("dbo.GetTransactionsByDate", connection);
                command.Parameters.AddWithValue("@Date", DateTime.Parse(args[0]));
                command.CommandType = CommandType.StoredProcedure;
                var list = new List<object>();
                var reader = command.ExecuteReader();
                while(reader.Read())
                {
                     
                }
            }
        }
    }
}
