USE StackOverflow
GO

SET STATISTICS IO ON

SELECT COUNT(*) FROM Posts

-- Field with index
SELECT COUNT(ParentId) FROM Posts

-- NOT NULL Field
SELECT COUNT(PostTypeId) FROM Posts
 
-- NULL field
SELECT COUNT(Score) FROM Posts
