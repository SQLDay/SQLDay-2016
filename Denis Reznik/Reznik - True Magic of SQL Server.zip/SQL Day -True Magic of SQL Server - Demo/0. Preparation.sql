USE [AdventureWorks2012]
GO

-- Old Statisitcs
DELETE FROM dbo.bigTransactionHistory3
WHERE TransactionDate = '01-01-2013'
GO

UPDATE STATISTICS dbo.bigTransactionHistory3
GO

INSERT INTO dbo.bigTransactionHistory3
SELECT TOP(1000000) * FROM tempInsert 
GO

SELECT p.* FROM dbo.bigTransactionHistory3 t
INNER JOIN Production.Product p
	ON t.ProductID = p.ProductID 
WHERE t.TransactionDate = '01-01-2013'
OPTION (RECOMPILE)
GO

-- SQL 2014 Only
CREATE FUNCTION [dbo].[GetStartDate]()
RETURNS datetime
AS
BEGIN
	RETURN '01-01-2006';
END
GO

CREATE FUNCTION [dbo].[GetFinishDate]()
RETURNS datetime
AS
BEGIN
	RETURN (SELECT TOP(1) TransactionDate FROM bigTransactionHistory ORDER BY Quantity DESC);
END
GO

--ALTER TABLE [dbo].[Posts]
--	ALTER COLUMN [PostTypeId] tinyint NOT NULL
--GO