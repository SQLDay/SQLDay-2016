ALTER DATABASE [Twitter] SET ALLOW_SNAPSHOT_ISOLATION OFF
GO

ALTER DATABASE [Twitter] SET READ_COMMITTED_SNAPSHOT ON WITH ROLLBACK IMMEDIATE
GO

USE Twitter
GO

SET TRANSACTION ISOLATION LEVEL READ COMMITTED
GO

WHILE (1=1)
BEGIN
	BEGIN TRAN
		UPDATE Users SET name = 'Santa Claus' WHERE id = 77037235;
	
		UPDATE Users SET name = 'Santa' WHERE id = 77037235

		INSERT INTO [dbo].[Statuses] (id, created_at, text, source, truncated, in_reply_to_status_id, in_reply_to_user_id, favorited, user_id, cached_date)
		VALUES ((SELECT MAX(id) + 1 FROM Statuses), '2009-03-21 09:19:45.000', 'Admiring the designs for my new logo at http://99designs.com/contests/19433.', 'web', 0, 0, 0, 0, 77037235, '2009-10-02 21:03:42.247')
	ROLLBACK
END

