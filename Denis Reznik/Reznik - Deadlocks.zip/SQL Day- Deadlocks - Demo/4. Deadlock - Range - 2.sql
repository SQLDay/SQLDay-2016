USE TwitterLight
GO

SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO
 
WHILE (1=1)
BEGIN
	BEGIN TRAN
		DELETE FROM Statuses 
		WHERE UserId IN 
		(
			SELECT Id FROM Users
			WHERE Company = 'SQLSentry'
		);

		DELETE FROM Users
		WHERE Company = 'SQLSentry';
	ROLLBACK
END