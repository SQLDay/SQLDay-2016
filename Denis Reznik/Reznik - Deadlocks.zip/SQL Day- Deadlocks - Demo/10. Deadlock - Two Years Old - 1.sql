ALTER DATABASE [Twitter2] SET ALLOW_SNAPSHOT_ISOLATION OFF
GO

ALTER DATABASE [Twitter2] SET READ_COMMITTED_SNAPSHOT ON WITH ROLLBACK IMMEDIATE
GO

USE Twitter2
GO

SET TRANSACTION ISOLATION LEVEL READ COMMITTED
GO

WHILE (1=1)
BEGIN
	BEGIN TRAN
		INSERT INTO Statuses (id, created_at, text, source, truncated, in_reply_to_status_id, in_reply_to_user_id, favorited, user_id, cached_date)
		VALUES (2, '2009-11-08 12:18:23.000', 'Dear Twitter: it is not that hard to block spam accounts. Just search for ones called &lt;generic name&gt;&lt;number&gt; that have one tweet with a test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test URL.', 'web', 0, 0, 0, 0, 6489932, '2016-05-16 15:55:19.130')
	ROLLBACK
END
