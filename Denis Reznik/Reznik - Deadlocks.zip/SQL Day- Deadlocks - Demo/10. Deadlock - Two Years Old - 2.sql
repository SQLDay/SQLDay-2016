ALTER DATABASE [Twitter2] SET ALLOW_SNAPSHOT_ISOLATION OFF
GO

ALTER DATABASE [Twitter2] SET READ_COMMITTED_SNAPSHOT ON WITH ROLLBACK IMMEDIATE
GO

USE Twitter2
GO

SET TRANSACTION ISOLATION LEVEL READ COMMITTED
GO

WHILE (1=1)
BEGIN
	BEGIN TRAN
		INSERT INTO Statuses (id, created_at, text, source, truncated, in_reply_to_status_id, in_reply_to_user_id, favorited, user_id, cached_date)
		VALUES (1, '2009-10-13 15:51:56.000', 'url routing in asp.net looks useful. i wonder if @windowslive will use 4 their quite abysmal URLs #wlive test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test test #twitter', '<a href="http://dabr.co.uk" rel="nofollow">dabr</a>', 0, 0, 0, 0, 2786631, '2016-05-16 15:53:56.287')
	ROLLBACK
END
