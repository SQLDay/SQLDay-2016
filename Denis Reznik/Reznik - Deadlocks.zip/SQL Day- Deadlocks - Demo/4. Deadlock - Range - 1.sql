USE TwitterLight
GO

-- Speaker Notes: To show behavior execute only first query in transaction

SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO

WHILE (1=1)
BEGIN
	BEGIN TRAN
		
		UPDATE Users SET Company = 'SQLSkills'
		WHERE Company = 'SQL Skills';

		SELECT * FROM Statuses 
		WHERE UserId IN
		(
			SELECT Id FROM Users
			WHERE Company = 'SQLSkills'
		);

	ROLLBACK
END