USE Twitter2
GO

CREATE PROCEDURE QuickUpdate
AS
BEGIN

	BEGIN TRAN;

	DISABLE TRIGGER [trNewStatusesUpdate] ON [dbo].[NewStatuses];
	DISABLE TRIGGER [trNewUsersUpdate] ON [dbo].[NewUsers];

	UPDATE NewUsers SET name = 'Santa Claus' WHERE id = 77037235;
	UPDATE NewUsers SET name = 'Santa' WHERE id = 77037235;

	UPDATE NewStatuses SET text = '"Tweet" me your wishlist kids! Santa''s ready to block and report your dreams as spam.' WHERE id = 6243104882;
	UPDATE NewStatuses SET text = '"Tweet" me your wishlist kids! Santa''s ready to block your dreams as spam.' WHERE id = 6243104882;

	ENABLE TRIGGER [trNewStatusesUpdate] ON [dbo].[NewStatuses];
	ENABLE TRIGGER [trNewUsersUpdate] ON [dbo].[NewUsers];

	ROLLBACK

END
GO

CREATE TABLE Terms
(
	Id int NOT NULL IDENTITY PRIMARY KEY,
	Term nvarchar(100) NOT NULL
)
GO

CREATE UNIQUE INDEX UX_TERMS_TERM
	ON Terms (Term)
WITH (IGNORE_DUP_KEY = ON)
GO

CREATE TABLE FtsIndex
(
	TermId int NOT NULL,
	StatusId int NOT NULL,
	Position int NOT NULL,
	CONSTRAINT PK_FTSINDEX PRIMARY KEY(TermId, StatusId, Position)
)
GO

CREATE TRIGGER [dbo].[trStatusesInsertFtsData] ON [dbo].[Statuses] 
AFTER INSERT, UPDATE AS 
BEGIN

DELETE FROM FtsIndex
WHERE StatusId IN (SELECT Id FROM deleted);

INSERT INTO Terms (Term)
SELECT p.display_term FROM inserted i
CROSS APPLY sys.dm_fts_parser('"' + i.text + '"', 1033, NULL, 1) p
WHERE p.special_term = 'Exact Match'

-- INSERT INTO FtsIndex table

END
GO

UPDATE Statuses SET text = 'url routing in asp.net looks useful. i wonder if @windowslive will use 4 their quite abysmal URLs #wlive'
WHERE id = 4844248720

UPDATE Statuses SET text = 'url routing in asp.net looks useful. i wonder if @windowslive will use 4 their quite abysmal URLs #wlive #twitter'
WHERE id = 4844248720

UPDATE Statuses SET text = 'Dear Twitter: it is not that hard to block spam accounts. Just search for ones called &lt;generic name&gt;&lt;number&gt; that have one tweet with a URL'
WHERE id = 5537115739

UPDATE Statuses SET text = 'Dear Twitter: it is not that hard to block spam accounts. Just search for ones called &lt;generic name&gt;&lt;number&gt; that have one tweet with a URL.'
WHERE id = 5537115739
