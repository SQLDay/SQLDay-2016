/*============================================================================
	File:		0004 - sys.dm_db_index_physical_stats.sql

	Summary:	This script demonstrates the usage and use cases for the dmo.

				THIS SCRIPT IS PART OF THE TRACK: "DMO for index maintenance"

	Date:		Januar 2015

	SQL Server Version: 2012 / 2014
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE demo_db;
GO

-- get a few information about this DMF!
EXEC sp_help 'sys.dm_db_index_physical_stats';
GO

DECLARE	@table_name	sysname	=	'tbl_cluster';
DECLARE	@index_id	int		=	1;

-- get the physical information about the clustered table
SELECT	QUOTENAME(s.name) + '.' + QUOTENAME(t.name)		AS	table_name,
		i.index_id,
		i.name											AS	index_name,
		i.type_desc										AS	index_type,
		ps.index_level,
		ps.avg_fragmentation_in_percent,
		ps.fragment_count,
		ps.avg_fragment_size_in_pages,
		ps.avg_page_space_used_in_percent,
		ps.page_count,
		ps.record_count
FROM	sys.schemas s INNER JOIN sys.tables t
		ON (s.schema_id = t.schema_id) INNER JOIN sys.indexes i
		ON (t.object_id = i.object_id)
		CROSS APPLY sys.dm_db_index_physical_stats
		(
			db_id(),					-- Id der Datenbank
			i.object_id,				-- Id des Datenbankobjekts
			i.index_id,					-- Id des Indexobjekts
			i.data_space_id,			-- Id der Partition
			'DETAILED'					-- Modus der Evaluierung (LIMITED, DETAILED, SAMPLED)
		) ps
WHERE	t.name = @table_name AND
		i.index_id = @index_id
ORDER BY
		t.name,
		i.index_id;

-- Rebuild the clustered index and check the DMF again
-- for fragmentation