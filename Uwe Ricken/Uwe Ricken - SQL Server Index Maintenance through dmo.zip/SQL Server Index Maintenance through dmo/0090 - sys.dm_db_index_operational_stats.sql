/*============================================================================
	File:		0006 - sys.dm_db_index_operational_stats.sql

	Summary:	This script creates multiple relations and indexes for analysis

				THIS SCRIPT IS PART OF THE TRACK: "DMO for index maintenance"

	Date:		Januar 2015

	SQL Server Version: 2012 / 2014
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE demo_db;
GO

-- index operations for Objects (LEAF)
SELECT	QUOTENAME(s.name) + '.' + QUOTENAME(t.name)		AS	table_name,
		i.name											AS	index_name,
		i.type_desc										AS	index_type,
		os.leaf_insert_count,
		os.leaf_delete_count,
		os.leaf_update_count,
		os.leaf_ghost_count
FROM	sys.schemas s INNER JOIN sys.tables t
		ON (s.schema_id = t.schema_id) INNER JOIN sys.indexes i
		ON (t.object_id = i.object_id)
		CROSS APPLY sys.dm_db_index_operational_stats
		(
			db_id(),
			i.object_id,
			i.index_id,
			NULL
		) os
WHERE	i.object_id = OBJECT_ID('dbo.tbl_heap', 'U')
ORDER BY
		t.name,
		i.index_id;

-- index operations for Objects (B-TREE)
SELECT	QUOTENAME(s.name) + '.' + QUOTENAME(t.name)		AS	table_name,
		i.name											AS	index_name,
		i.type_desc										AS	index_type,
		os.nonleaf_insert_count,
		os.nonleaf_delete_count,
		os.nonleaf_update_count
FROM	sys.schemas s INNER JOIN sys.tables t
		ON (s.schema_id = t.schema_id) INNER JOIN sys.indexes i
		ON (t.object_id = i.object_id) CROSS APPLY sys.dm_db_index_operational_stats
		(
			db_id(),
			i.object_id,
			i.index_id,
			NULL
		) os
WHERE	i.object_id = OBJECT_ID('dbo.tbl_cluster', 'U')
ORDER BY
		t.name,
		i.index_id;

-- Indexoperationen for Objects (LOCKS)
-- run an UPDATE in a different window on the tbl_heap in a transaction
-- run a SELECT in another windows
-- commit the update transaction
-- rerun the next query
SELECT	QUOTENAME(s.name) + '.' + QUOTENAME(t.name)		AS	table_name,
		i.name											AS	index_name,
		i.type_desc										AS	index_type,
		os.page_io_latch_wait_count,
		os.page_io_latch_wait_in_ms,
		os.page_latch_wait_count,
		os.page_latch_wait_in_ms,
		os.page_lock_count,
		os.page_lock_wait_count,
		os.page_lock_wait_in_ms
FROM	sys.schemas s INNER JOIN sys.tables t
		ON (s.schema_id = t.schema_id) INNER JOIN sys.indexes i
		ON (t.object_id = i.object_id)
		CROSS APPLY sys.dm_db_index_operational_stats
		(
			db_id(),
			i.object_id,
			i.index_id,
			NULL
		) os
WHERE	i.object_id = OBJECT_ID('dbo.tbl_cluster', 'U')
ORDER BY
		t.name,
		i.index_id;

-- Statistiken l�schen f�r Abfrageanalyse
ALTER INDEX cix_tbl_cluster_id ON dbo.tbl_Cluster REBUILD;
ALTER INDEX ix_tbl_cluster_InsertPos ON dbo.tbl_Cluster REBUILD;
ALTER INDEX ix_tbl_cluster_c3 ON dbo.tbl_Cluster REBUILD;
GO

-- Demo: TABLE SCAN / SEEK / LOOKUP in Heap
SELECT * FROM dbo.tbl_cluster WHERE c3 = CAST(getdate() AS date);

SELECT	QUOTENAME(s.name) + '.' + QUOTENAME(t.name)		AS	table_name,
		i.name											AS	index_name,
		i.type_desc										AS	index_type,
		os.range_scan_count,
		os.singleton_lookup_count,
		os.forwarded_fetch_count
FROM	sys.schemas s INNER JOIN sys.tables t
		ON (s.schema_id = t.schema_id) INNER JOIN sys.indexes i
		ON (t.object_id = i.object_id) CROSS APPLY sys.dm_db_index_operational_stats

		(
			db_id(),
			i.object_id,
			i.index_id,
			NULL
		) os
WHERE	i.object_id = OBJECT_ID('dbo.tbl_cluster', 'U')
ORDER BY
		t.name,
		i.index_id;
GO

SELECT * FROM dbo.tbl_cluster WHERE InsertPos = 10;

SELECT	QUOTENAME(s.name) + '.' + QUOTENAME(t.name)		AS	table_name,
		i.name											AS	index_name,
		i.type_desc										AS	index_type,
		os.range_scan_count,
		os.singleton_lookup_count,
		os.forwarded_fetch_count
FROM	sys.schemas s INNER JOIN sys.tables t
		ON (s.schema_id = t.schema_id) INNER JOIN sys.indexes i
		ON (t.object_id = i.object_id) CROSS APPLY sys.dm_db_index_operational_stats

		(
			db_id(),
			i.object_id,
			i.index_id,
			NULL
		) os
WHERE	i.object_id = OBJECT_ID('dbo.tbl_cluster', 'U')
ORDER BY
		t.name,
		i.index_id;
GO

SELECT * FROM dbo.tbl_cluster WHERE InsertPos >= 10 AND InsertPos < 101;

SELECT	QUOTENAME(s.name) + '.' + QUOTENAME(t.name)		AS	table_name,
		i.name											AS	index_name,
		i.type_desc										AS	index_type,
		os.range_scan_count,
		os.singleton_lookup_count,
		os.forwarded_fetch_count
FROM	sys.schemas s INNER JOIN sys.tables t
		ON (s.schema_id = t.schema_id) INNER JOIN sys.indexes i
		ON (t.object_id = i.object_id) CROSS APPLY sys.dm_db_index_operational_stats

		(
			db_id(),
			i.object_id,
			i.index_id,
			NULL
		) os
WHERE	i.object_id = OBJECT_ID('dbo.tbl_cluster', 'U')
ORDER BY
		t.name,
		i.index_id;
GO

SELECT * FROM dbo.tbl_cluster WHERE InsertPos >= 1000 AND InsertPos < 50000;

SELECT	QUOTENAME(s.name) + '.' + QUOTENAME(t.name)		AS	table_name,
		i.name											AS	index_name,
		i.type_desc										AS	index_type,
		os.range_scan_count,
		os.singleton_lookup_count,
		os.forwarded_fetch_count
FROM	sys.schemas s INNER JOIN sys.tables t
		ON (s.schema_id = t.schema_id) INNER JOIN sys.indexes i
		ON (t.object_id = i.object_id) CROSS APPLY sys.dm_db_index_operational_stats

		(
			db_id(),
			i.object_id,
			i.index_id,
			NULL
		) os
WHERE	i.object_id = OBJECT_ID('dbo.tbl_cluster', 'U')
ORDER BY
		t.name,
		i.index_id;
GO

SELECT TOP 1000 * FROM dbo.tbl_Cluster;

SELECT	QUOTENAME(s.name) + '.' + QUOTENAME(t.name)		AS	table_name,
		i.name											AS	index_name,
		i.type_desc										AS	index_type,
		os.range_scan_count,
		os.singleton_lookup_count,
		os.forwarded_fetch_count
FROM	sys.schemas s INNER JOIN sys.tables t
		ON (s.schema_id = t.schema_id) INNER JOIN sys.indexes i
		ON (t.object_id = i.object_id) CROSS APPLY sys.dm_db_index_operational_stats

		(
			db_id(),
			i.object_id,
			i.index_id,
			NULL
		) os
WHERE	i.object_id = OBJECT_ID('dbo.tbl_cluster', 'U')
ORDER BY
		t.name,
		i.index_id;
GO
