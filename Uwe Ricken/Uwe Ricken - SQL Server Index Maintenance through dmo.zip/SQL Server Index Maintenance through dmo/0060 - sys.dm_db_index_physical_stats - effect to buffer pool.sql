/*============================================================================
	File:		0004a - sys.dm_db_index_physical_stats.sql

	Summary:	This script demonstrate the usage of the buffer pool based on
				index fragmentation

				THIS SCRIPT IS PART OF THE TRACK: "DMO for index maintenance"

	Date:		Feburary 2013

	SQL Server Version: 2012 / 2014
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE demo_db;
GO

SET NOCOUNT ON;
GO

-- Creation of two tables with different clustered index solutions
IF OBJECT_ID('dbo.BIGINT_Table', 'U') IS NOT NULL
	DROP TABLE dbo.BIGINT_Table;
	GO

CREATE TABLE dbo.BIGINT_Table
(
	id	bigint		NOT NULL	IDENTITY (1, 1),
	id1	bigint		NOT NULL	DEFAULT (RAND() * 10000),
	c1	char(200)	NOT NULL	DEFAULT ('only a filler'),
	c2	char(200)	NOT NULL	DEFAULT ('wow - a filler'),
	c3	char(200)	NOT NULL	DEFAULT ('ups - and another filler'),

	CONSTRAINT pk_bigint_table PRIMARY KEY CLUSTERED (id, id1),
);

IF OBJECT_ID('dbo.GUID_Table', 'U') IS NOT NULL
	DROP TABLE dbo.GUID_Table;
	GO

CREATE TABLE dbo.GUID_Table
(
	id	uniqueidentifier	NOT NULL	DEFAULT (newid()),
	c1	char(200)			NOT NULL	DEFAULT ('only a filler'),
	c2	char(200)			NOT NULL	DEFAULT ('wow - a filler'),
	c3	char(200)			NOT NULL	DEFAULT ('ups - and another filler'),

	CONSTRAINT pk_GUID_table PRIMARY KEY CLUSTERED (id),
);
GO

-- Fill tables with 10.000 records
INSERT INTO dbo.BIGINT_Table DEFAULT VALUES;
GO 10000

INSERT INTO dbo.GUID_Table DEFAULT VALUES;
GO 10000

-- Check the index fragmentation
SELECT	i.name			AS	index_name,
		i.type_desc		AS	type_desc,
		p.fragment_count,
		p.page_count,
		p.avg_page_space_used_in_percent,
		p.record_count,
		p.avg_record_size_in_bytes
FROM	sys.indexes i CROSS APPLY sys.dm_db_index_physical_stats(db_id(), i.object_id, i.index_id, NULL, 'DETAILED') p
WHERE	i.object_id IN
		(
			OBJECT_ID('dbo.BIGINT_Table', 'U'),
			OBJECT_ID('dbo.GUID_Table', 'U')
		);
GO

-- Now the data of the table will be tranfered to the BUFFER POOL!
SELECT * FROM dbo.BIGINT_Table;
SELECT * FROM dbo.GUID_Table;
GO

-- See the situation in the BUFFER POOL!
SELECT	OBJECT_NAME(p.object_id),
		bd.page_level,
		bd.page_type,
		COUNT_BIG(bd.page_id)			AS	Num_Pages,
		SUM(bd.row_count)				AS	Num_Rows,
		SUM(free_space_in_bytes)		AS	Free_space_in_bytes,
		SUM(free_space_in_bytes) * 1.0 / POWER(1024, 2)	AS	Free_space_in_MBytes
FROM	sys.dm_os_buffer_descriptors bd INNER JOIN sys.allocation_units au
		ON (bd.allocation_unit_id = au.allocation_unit_id) INNER JOIN sys.partitions p
		ON (au.container_id = CASE WHEN au.type IN (1, 3) THEN p.hobt_id ELSE p.partition_id END)
WHERE	database_id = db_id() AND
		bd.page_type != 'IAM_PAGE' AND
		p.object_id IN 
		(
			OBJECT_ID('dbo.BIGINT_Table', 'U'),
			OBJECT_ID('dbo.GUID_Table', 'U')
		)
GROUP BY
		OBJECT_NAME(p.object_id),
		bd.page_level,
		bd.page_type
ORDER BY
		OBJECT_NAME(p.object_id) ASC,
		page_level ASC;
GO

-- Clean the work bench :)
DROP TABLE dbo.BIGINT_Table;
DROP TABLE dbo.GUID_Table;