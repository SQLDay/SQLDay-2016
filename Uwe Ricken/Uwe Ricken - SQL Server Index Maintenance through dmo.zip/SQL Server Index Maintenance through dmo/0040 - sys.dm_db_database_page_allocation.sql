/*============================================================================
	File:		0003 - sys.dm_db_database_page_allocation.sql

	Summary:	This script creates multiple relations and indexes for analysis
				THIS SCRIPT IS PART OF THE TRACK: "DMO for index maintenance"

	Date:		Januar 2013

	SQL Server Version: 2012 / 2014
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.

	Links:

	Speicherung von Daten in HEAPS:
	http://db-berater.blogspot.de/2013/12/wie-alloziert-microsoft-sql-server.html
	http://db-berater.blogspot.de/2013/10/neue-daten-in-einen-heap-eintragen.html

============================================================================*/
USE demo_db;
GO

-- basic informaiton about the DMF!
EXEC sp_help 'sys.dm_db_database_page_allocations';
GO

-- How many pages must be read for a table scan?
-- Attention! Different no of IO in SELECT and DMF. Why?
SET STATISTICS IO ON;
GO

SELECT * FROM dbo.tbl_heap;

SET STATISTICS IO OFF;
GO

-- How many data used pages are allocated by the table?
SELECT	extent_page_id,
		allocated_page_iam_page_id,
		page_type,
		allocated_page_page_id,
		is_mixed_page_allocation,
		page_type_desc,
		page_free_space_percent,
		next_page_page_id,
		previous_page_page_id
FROM	sys.dm_db_database_page_allocations
(
	db_id(),							-- Id of the database
	OBJECT_ID('dbo.tbl_heap', 'U'),		-- Id of the table
	0,									-- Index_id (from sys.indexes),
	1,									-- Partition_number (from sys.partitions)
	'DETAILED'							-- DETAILED or LIMITED are available
)
WHERE	is_allocated = 1
ORDER BY
	page_type DESC,
	is_mixed_page_allocation DESC,
	allocated_page_page_id;

-- How many pages does the same table have as CI?
SET STATISTICS IO ON;
SELECT * FROM dbo.tbl_cluster WITH (INDEX(1));
SET STATISTICS IO OFF;
GO

SELECT	DDDPA.extent_page_id,
		DDDPA.allocated_page_iam_page_id,
		DDDPA.page_type,
		DDDPA.page_level,
		DDDPA.allocated_page_page_id,
		DDDPA.page_type_desc,
		DDDPA.page_free_space_percent,
		DDDPA.next_page_page_id,
		DDDPA.previous_page_page_id
FROM	sys.dm_db_database_page_allocations
(
	db_id(),							-- Id der Datenbank, in dem sich der Index befindet
	OBJECT_ID('dbo.tbl_cluster', 'U'),	-- Id der Tabelle, in der sich der Index befindet
	1,									-- Index_id (aus sys.indexes),
	NULL,									-- Partition_number (aus sys.partitions)
	'DETAILED'							-- nur DETAILED oder LIMITED m�glich
) AS DDDPA
WHERE	DDDPA.is_allocated = 1
ORDER BY
	DDDPA.page_type DESC,
	DDDPA.page_level DESC,
	DDDPA.allocated_page_page_id;
GO

-- Pages in Clustered Index from ROOT - LEAF
-- when an INDEX SEEK occurs for ONE record!
SET STATISTICS IO ON;

SELECT * FROM dbo.tbl_cluster
WHERE	Id = 'CDA42FB8-363A-404F-9855-054D3D277740'

SET STATISTICS IO OFF;
GO

DBCC TRACEON (3604);
DBCC PAGE ('demo_db', 1, 7772, 3);
DBCC PAGE ('demo_db', 1, 12800, 3);
DBCC PAGE ('demo_db', 1, 18333, 3);