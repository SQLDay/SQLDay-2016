/*============================================================================
	File:		0005 - sys.dm_db_index_usage_stats.sql

	Summary:	This script creates multiple relations and indexes for analysis

				THIS SCRIPT IS PART OF THE TRACK: "DMO for index maintenance"

	Date:		Januar 2015

	SQL Server Version: 2012 / 2014
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE demo_db;
GO

-- Information about the DMV!
EXEC sp_help 'sys.dm_db_index_usage_stats';
GO

-- usage of index in existing relations
SELECT	QUOTENAME(s.name) + '.' + QUOTENAME(t.name)		AS	table_name,
		i.name											AS	index_name,
		i.type_desc										AS	index_type,
		us.user_seeks,
		us.user_scans,
		us.user_lookups,
		us.user_updates,
		us.last_user_seek,
		us.last_user_scan,
		us.last_user_lookup,
		us.last_user_update
FROM	sys.schemas s INNER JOIN sys.tables t
		ON (s.schema_id = t.schema_id) INNER JOIN sys.indexes i
		ON (t.object_id = i.object_id) LEFT JOIN sys.dm_db_index_usage_stats us
		ON (
				i.object_id = us.object_id AND
				i.index_id = us.index_id
		   )
WHERE	i.object_id IN
		(
			OBJECT_ID('dbo.tbl_heap', 'U'),
			OBJECT_ID('dbo.tbl_cluster', 'U'),
			OBJECT_ID('dbo.tbl_blob', 'U')
		)
ORDER BY
		t.name,
		i.index_id;

-- system usage of indexes (STATISTICS UPDATE)
-- usage of index in existing relations
SELECT	QUOTENAME(s.name) + '.' + QUOTENAME(t.name)		AS	table_name,
		i.name											AS	index_name,
		i.type_desc										AS	index_type,
		us.system_seeks,
		us.system_scans,
		us.system_lookups,
		us.system_updates,
		us.last_system_seek,
		us.last_system_scan,
		us.last_system_lookup,
		us.last_system_update
FROM	sys.schemas s INNER JOIN sys.tables t
		ON (s.schema_id = t.schema_id) INNER JOIN sys.indexes i
		ON (t.object_id = i.object_id) LEFT JOIN sys.dm_db_index_usage_stats us
		ON (
				i.object_id = us.object_id AND
				i.index_id = us.index_id
		   )
WHERE	i.object_id IN
		(
			OBJECT_ID('dbo.tbl_heap', 'U'),
			OBJECT_ID('dbo.tbl_cluster', 'U'),
			OBJECT_ID('dbo.tbl_blob', 'U')
		)
ORDER BY
		t.name,
		i.index_id;

-- Demo 1: TABLE SCAN / SEEK / LOOKUP in Heap
SELECT * FROM dbo.tbl_heap WHERE c3 = CAST(getdate() AS date);

-- Indexverwendung f�r angelegte Relationen
SELECT	QUOTENAME(s.name) + '.' + QUOTENAME(t.name)		AS	table_name,
		i.name											AS	index_name,
		i.type_desc										AS	index_type,
		us.user_seeks,
		us.user_scans,
		us.user_lookups,
		us.user_updates,
		us.last_user_seek,
		us.last_user_scan,
		us.last_user_lookup,
		us.last_user_update
FROM	sys.schemas s INNER JOIN sys.tables t
		ON (s.schema_id = t.schema_id) INNER JOIN sys.indexes i
		ON (t.object_id = i.object_id) INNER JOIN sys.dm_db_index_usage_stats us
		ON (
				i.object_id = us.object_id AND
				i.index_id = us.index_id
		   )
WHERE	i.object_id = OBJECT_ID('dbo.tbl_heap', 'U')
ORDER BY
		t.name,
		i.index_id;

SELECT InsertPos FROM dbo.tbl_heap WHERE InsertPos = 10;

-- Indexverwendung f�r angelegte Relationen
SELECT	QUOTENAME(s.name) + '.' + QUOTENAME(t.name)		AS	table_name,
		i.name											AS	index_name,
		i.type_desc										AS	index_type,
		us.user_seeks,
		us.user_scans,
		us.user_lookups,
		us.user_updates,
		us.last_user_seek,
		us.last_user_scan,
		us.last_user_lookup,
		us.last_user_update
FROM	sys.schemas s INNER JOIN sys.tables t
		ON (s.schema_id = t.schema_id) INNER JOIN sys.indexes i
		ON (t.object_id = i.object_id) LEFT JOIN sys.dm_db_index_usage_stats us
		ON (
				i.object_id = us.object_id AND
				i.index_id = us.index_id
		   )
WHERE	i.object_id = OBJECT_ID('dbo.tbl_heap', 'U')
ORDER BY
		t.name,
		i.index_id;

SELECT * FROM dbo.tbl_heap WHERE InsertPos >= 10 AND InsertPos < 101;

-- index usage for existing user tables
SELECT	QUOTENAME(s.name) + '.' + QUOTENAME(t.name)		AS	table_name,
		i.name											AS	index_name,
		i.type_desc										AS	index_type,
		us.user_seeks,
		us.user_scans,
		us.user_lookups,
		us.user_updates,
		us.last_user_seek,
		us.last_user_scan,
		us.last_user_lookup,
		us.last_user_update
FROM	sys.schemas s INNER JOIN sys.tables t
		ON (s.schema_id = t.schema_id) INNER JOIN sys.indexes i
		ON (t.object_id = i.object_id) LEFT JOIN sys.dm_db_index_usage_stats us
		ON (
				i.object_id = us.object_id AND
				i.index_id = us.index_id
		   )
WHERE	i.object_id = OBJECT_ID('dbo.tbl_heap', 'U')
ORDER BY
		t.name,
		i.index_id;
GO