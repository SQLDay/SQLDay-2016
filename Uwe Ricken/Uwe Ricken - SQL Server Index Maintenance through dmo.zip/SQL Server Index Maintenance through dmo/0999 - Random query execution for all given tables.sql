/*============================================================================
	File:		0099 - Random query execution for all given tables.sql

	Summary:	This script can be run in SSMS or sqlcmd and access all
				given tables and run queries againt them in a random manner

				THIS SCRIPT IS PART OF THE TRACK: "DMO for index maintenance"

	Date:		Januar 2013

	SQL Server Version: 2012 / 2014
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE demo_db;
GO

SET NOCOUNT ON;
GO

DECLARE	@stmt		nvarchar(2000);
DECLARE	@table_name	nvarchar(128);
DECLARE	@i			int;

DECLARE	@stmt_id		int;
DECLARE	@condition_id	int;

DECLARE	@sqlstmt		nvarchar(1000);
DECLARE	@parms			nvarchar(255) = '@i int';

DECLARE	@stmts TABLE
(
	Id			int				NOT NULL	IDENTITY (1, 1) PRIMARY KEY CLUSTERED,
	stmt		nvarchar(2000)	NOT NULL,
	exec_count	int				NOT NULl	DEFAULT (0)
);

DECLARE	@conditions TABLE
(
	Id			int				NOT NULL	IDENTITY (1, 1) PRIMARY KEY CLUSTERED,
	condition	nvarchar(200)	NOT NULL,
	exec_count	int				NOT NULl	DEFAULT (0)
);

INSERT INTO @stmts (stmt)
VALUES
	('SELECT Id, c1, c2, c3 INTO #dummy FROM $table_name WHERE $condition;'),
	('SELECT * INTO #dummy FROM $table_name WHERE $condition;'),
	('SELECT Id, c1, c3 INTO #dummy FROM $table_name WHERE $condition;'),
	('SELECT Id, c1, c2, c3, InsertPos INTO #dummy FROM $table_name WHERE $condition;'),
	('SELECT id, c1, c2 INTO #dummy FROM $table_name WHERE $condition;'),
	('SELECT Id, InsertPos INTO #dummy FROM $table_name WHERE $condition;'),
	('SELECT * INTO #dummy FROM $table_name;'),
	('SELECT * INTO #dummy FROM $table_name WHERE c3 BETWEEN ''20130101'' AND ''20131231'';'),
	('SELECT * INTO #dummy FROM $table_name WHERE c3 = CAST(getdate() AS date);'),
	('SELECT * INTO #dummy FROM $table_name WHERE InsertPos = 10;'),
	('SELECT * INTO #dummy FROM $table_name WHERE InsertPos >= 10 AND InsertPos < 101;'),
	('SELECT * INTO #dummy FROM $table_name WHERE InsertPos >= 1000 AND InsertPos < 50000;');

INSERT INTO @conditions (condition)
VALUES
	('InsertPos >= @i'),
	('c1 = ''Das ist ein Test'''),
	('c3 = DATEADD(d, @i, getdate())'),
	('Id = newid()'),
	('c2 = ''Und noch ein Test''');

DECLARE	@Counter int = 1
WHILE @Counter <= 1000
BEGIN
	-- definition of random queries and result sets
	SET	@table_name		= CHOOSE(CAST(rand() * 3 + 1 AS int), 'dbo.tbl_heap', 'dbo.tbl_cluster', 'dbo.tbl_blob')
	SET	@stmt_id		= CAST(RAND() * 12 + 1 AS int);
	SET	@condition_id	= CAST(RAND() * 5 + 1 AS int);

	SET		@table_name	= ISNULL(@table_name, 'dbo.tbl_cluster');
	SET		@i			= CAST(RAND() * 10000 AS int);
	SELECT	@sqlstmt	= REPLACE(REPLACE(s.stmt, '$table_name', @table_name), '$condition', c.condition)
	FROM	@stmts s, @conditions c
	WHERE	s.Id = @stmt_id AND
			c.Id = @condition_id;

	RAISERROR ('Statement: %s', 0, 1, @sqlstmt) WITH NOWAIT;
	EXECUTE	sp_executesql @sqlstmt, @parms, @i = @i;

	SET	@Counter += 1;

	WAITFOR DELAY '00:00:01'
END