/*============================================================================
	File:		0001 - Preparation of tables and indexes.sql

	Summary:	This script creates multiple relations and indexes for analysis

				THIS SCRIPT IS PART OF THE TRACK: "DMO for index maintenance"

	Date:		Januar 2015

	SQL Server Version: 2012 / 2014 / 2016
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE master;
GO

-- if the database exists we drop it for a brand new database
RAISERROR ('Database [demo_db] will be created...', 0, 1) WITH NOWAIT;
IF db_id('demo_db') IS NOT NULL
BEGIN
	ALTER DATABASE demo_db SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
	DROP DATABASE demo_db;
END
GO

CREATE DATABASE [demo_db]
ON  PRIMARY 
(
	NAME = N'demo_db',
	FILENAME = N'F:\DATA\demo_db.mdf',
	SIZE = 100MB,
	MAXSIZE = 500MB,
	FILEGROWTH = 100MB
)
LOG ON 
(
	NAME = N'demo_log',
	FILENAME = N'F:\DATA\demo_db.ldf',
	SIZE = 100MB,
	MAXSIZE = 500MB,
	FILEGROWTH = 100MB
);
GO

ALTER AUTHORIZATION ON DATABASE::demo_db TO sa;
ALTER DATABASE demo_db SET RECOVERY SIMPLE;
GO

USE demo_db;
GO

IF OBJECT_ID('dbo.tbl_heap', 'U') IS NOT NULL
	DROP TABLE dbo.tbl_heap;
	GO

CREATE TABLE dbo.tbl_heap
(
	Id			uniqueidentifier	NOT NULL	DEFAULT (newid()),
	c1			char(200)			NOT NULL,
	c2			char(200)			NOT NULL,
	c3			date				NOT NULL,
	InsertPos	int					NOT NULL	IDENTITY (1, 1)
);
GO

-- NCI auf InsertPos
CREATE UNIQUE INDEX uix_tbl_heap_InsertPos ON dbo.tbl_heap (InsertPos);
GO

IF OBJECT_ID('dbo.tbl_cluster', 'U') IS NOT NULL
	DROP TABLE dbo.tbl_cluster;
	GO

CREATE TABLE dbo.tbl_cluster
(
	Id			uniqueidentifier	NOT NULL	DEFAULT (newid()),
	c1			char(200)			NOT NULL,
	c2			char(200)			NOT NULL,
	c3			date				NOT NULL,
	InsertPos	int					NOT NULL	IDENTITY (1, 1)
);

CREATE UNIQUE CLUSTERED INDEX cix_tbl_cluster_id ON dbo.tbl_cluster (id);
CREATE UNIQUE INDEX ix_tbl_cluster_InsertPos ON dbo.tbl_cluster (InsertPos)
INCLUDE (c1, c2, c3);
CREATE INDEX ix_tbl_cluster_c3 ON dbo.tbl_cluster (c3);
GO

IF OBJECT_ID('dbo.tbl_blob', 'U') IS NOT NULL
	DROP TABLE dbo.tbl_blob;
	GO

CREATE TABLE dbo.tbl_blob
(
	Id			uniqueidentifier	NOT NULL	DEFAULT (newid()),
	c1			varchar(max)		NOT NULL,
	c2			image				NOT NULL,
	c3			date				NOT NULL,
	InsertPos	int					NOT NULL	IDENTITY (1, 1),

	CONSTRAINT pk_tbl_blob_InsertPos PRIMARY KEY CLUSTERED (InsertPos),
	CONSTRAINT uix_tbl_blob_Id UNIQUE NONCLUSTERED (Id)
);

CREATE INDEX ix_tbl_blob_c3 ON dbo.tbl_blob (c3) INCLUDE (c1);
GO

SET NOCOUNT ON;
GO

RAISERROR ('Fillling dbo.tbl_heap... ', 0, 1) WITH NOWAIT;
DECLARE @i int = 1
WHILE @i <= 10000
BEGIN
	INSERT INTO dbo.tbl_heap (c1, c2, c3)
	VALUES	(
				'This is stuff ' + CAST(@i AS varchar(10)),
				'Another stuff ' + CAST(CAST(@i * RAND() AS int) AS varchar(10)),
				DATEADD(dd, CAST(@i * RAND() AS int), getdate())
			);

	SET	@i += 1;
END
GO

RAISERROR ('Filling dbo.tbl_cluster...', 0, 1) WITH NOWAIT;
DECLARE @i int = 1
WHILE @i <= 10000
BEGIN
	INSERT INTO dbo.tbl_cluster (c1, c2, c3)
	VALUES	(
				'This is stuff ' + CAST(@i AS varchar(10)),
				'Another stuff ' + CAST(CAST(@i * RAND() AS int) AS varchar(10)),
				DATEADD(dd, CAST(@i * RAND() AS int), getdate())
			);

	SET	@i += 1;
END
GO

RAISERROR ('Filling dbo.tbl_blob...', 0, 1) WITH NOWAIT;
DECLARE @i int = 1
WHILE @i <= 10000
BEGIN
	INSERT INTO dbo.tbl_blob (c1, c2, c3)
	VALUES	(
				'This is stuff ' + CAST(@i AS varchar(10)),
				'Another stuff ' + CAST(CAST(@i * RAND() AS int) AS varchar(10)),
				DATEADD(dd, CAST(@i * RAND() AS int), getdate())
			);

	SET	@i += 1;
END
GO

UPDATE STATISTICS dbo.tbl_Heap WITH FULLSCAN;
UPDATE STATISTICS dbo.tbl_Cluster WITH FULLSCAN;
UPDATE STATISTICS dbo.tbl_Blob WITH FULLSCAN;
GO
