/*============================================================================
	File:		0002b - Anatomie eines Index.sql

	Summary:	This script 
				THIS SCRIPT IS PART OF THE TRACK: "DMO for index maintenance"

	Date:		Januar 2013

	SQL Server Version: 2012 / 2014
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE demo_db
GO

IF OBJECT_ID('dbo.IndexDemo', 'U') IS NOT NULL
	DROP TABLE dbo.IndexDemo;
	GO

CREATE TABLE dbo.IndexDemo
(
	Id		int		NOT NULL	IDENTITY (1, 1),
	c1		char(200)	NOT NULL	DEFAULT ('filler'),
	c2		char(200)	NOT NULL	DEFAULT ('wow - another filler'),
	c3		date		NOT NULL
);
GO

SET NOCOUNT ON;
GO

INSERT INTO dbo.IndexDemo (c3) VALUES (DATEADD(day, CAST(RAND() * 1000 AS int), getdate()));
GO 100

-- Show the physical / logical position of the records
SELECT sys.fn_PhysLocFormatter(%%physloc%%) AS Position, * FROM dbo.IndexDemo;
GO

-- That's the structure of the table
SELECT	page_type_desc,
		allocated_page_iam_page_id,
		allocated_page_page_id,
		page_level,
		next_page_page_id,
		previous_page_page_id
FROM	sys.dm_db_database_page_allocations(db_id(), OBJECT_ID('dbo.Indexdemo', 'U'), 0, NULL, 'DETAILED')
ORDER BY
		Page_type DESC,
		page_level DESC;

-- Now create a clustered Index
CREATE UNIQUE CLUSTERED INDEX ix_Indexdemo_id ON dbo.IndexDemo (Id);
GO

-- what is the structure now?
SELECT	page_type_desc,
		allocated_page_iam_page_id,
		allocated_page_page_id,
		page_level,
		next_page_page_id,
		previous_page_page_id
FROM	sys.dm_db_database_page_allocations(db_id(), OBJECT_ID('dbo.Indexdemo', 'U'), 1, NULL, 'DETAILED')
ORDER BY
		Page_type DESC,
		page_level DESC,
		previous_page_page_id ASC;

-- Have a look to the root page
DBCC TRACEON (3604);
DBCC PAGE ('demo_db', 1, xxx, 3);

-- Create a non clustered index, too
CREATE INDEX ix_IndexDemo_c3 ON dbo.IndexDemo(c3);
SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID('dbo.IndexDemo', 'U');
GO

SELECT	page_type_desc,
		allocated_page_iam_page_id,
		allocated_page_page_id,
		page_level,
		next_page_page_id,
		previous_page_page_id
FROM	sys.dm_db_database_page_allocations(db_id(), OBJECT_ID('dbo.Indexdemo', 'U'), 2, NULL, 'DETAILED')
ORDER BY
		Page_type DESC,
		page_level DESC,
		previous_page_page_id ASC;

-- Look to the root and leaf level of the index
DBCC TRACEON (3604);
DBCC PAGE ('demo_db', 1, xxx, 3);
