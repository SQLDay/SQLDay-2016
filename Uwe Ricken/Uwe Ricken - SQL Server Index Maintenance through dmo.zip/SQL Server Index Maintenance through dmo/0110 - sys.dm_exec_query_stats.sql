/*============================================================================
	File:		0007 - sys.dm_exec_query_stats.sql

	Summary:	This script demonstrates the objects of columnstored indexes

				THIS SCRIPT IS PART OF THE TRACK: "DMO for index maintenance"

	Date:		Januar 2013

	SQL Server Version: 2012 / 2014
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE demo_db;
GO

SELECT	query_hash,
		sql_handle,
		statement_start_offset,
		statement_end_offset,
		creation_time,
		last_execution_time,
		execution_count
FROM	sys.dm_exec_query_stats
ORDER BY
		query_hash;

-- what is the query text?
-- what is the query plan?
SELECT	qs.query_hash,
		DEQP.query_plan,
		SUBSTRING	(
						st.text,
						qs.statement_start_offset / 2 + 1,
						CASE WHEN qs.statement_end_offset = -1
							 THEN LEN(st.text)
							 ELSE (qs.statement_end_offset - qs.statement_start_offset) / 2
						END
					)					AS	SQLCommand,
		qs.statement_start_offset,
		qs.statement_end_offset,
		qs.*
FROM	sys.dm_exec_query_stats qs
		CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) st
		CROSS APPLY sys.dm_exec_query_plan(qs.plan_handle) AS DEQP
WHERE	st.text LIKE '%tbl_cluster%' OR
		st.text LIKE '%tbl_heap%'
ORDER BY
		qs.query_hash;
GO

-- information about the produced IO by sql statement 
SELECT	TOP (100)
		DEST.text						AS SQL_Batch,
		SUBSTRING
		(
			DEST.text,
			DEQS.statement_start_offset / 2,
			CASE WHEN DEQS.statement_end_offset = -1
				 THEN DATALENGTH(DEST.text)
				 ELSE (DEQS.statement_end_offset - DEQS.statement_start_offset) / 2
			END
		)								AS	SQL_Command,
		DEQP.query_plan,
		last_logical_reads,
		last_logical_reads / 128.0		logical_reads_MB
FROM	sys.dm_exec_query_stats AS DEQS
		CROSS APPLY sys.dm_exec_sql_text(DEQS.sql_handle) AS DEST
		CROSS APPLY sys.dm_exec_query_plan(DEQS.plan_handle) DEQP
ORDER BY
		DEQS.last_logical_reads DESC;
GO