SET LANGUAGE us_english;
GO

/*============================================================================
	File:		0098 - sys.dm_db_index_physical_stats_demo.sql

	Summary:	This script demonstrates the usage and use cases for the dmo.

				THIS SCRIPT IS PART OF THE TRACK: "DMO for index maintenance"

	Date:		Januar 2013

	SQL Server Version: 2012 / 2014
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE AdventureWorksDW2012_FAT;
GO

DBCC DROPCLEANBUFFERS;
GO


IF OBJECT_ID('tempdb..#dummy', 'U') IS NOT NULL
	DROP TABLE #dummy;

DECLARE	@ResultTable TABLE
(
	Mode		varchar(10)	NOT NULL,
	StartDate	datetime	NOT NULL	DEFAULT (getdate())
);

RAISERROR ('Modus: SAMPLED', 0, 1) WITH NOWAIT;
INSERT INTO @ResultTable (Mode) VALUES ('Sampled');
SELECT * INTO #dummy FROM sys.dm_db_index_physical_stats(db_id(), OBJECT_ID('dbo.FactInternetSales'), 1, NULL, 'SAMPLED');

RAISERROR ('Modus: LIMITED', 0, 1) WITH NOWAIT;
INSERT INTO @ResultTable (Mode) VALUES ('LIMITED');
INSERT INTO #dummy
SELECT * FROM sys.dm_db_index_physical_stats(db_id(), OBJECT_ID('dbo.FactInternetSales'), 1, NULL, 'LIMITED');

RAISERROR ('Modus: DETAILED', 0, 1) WITH NOWAIT;
INSERT INTO @ResultTable (Mode) VALUES ('DETAILED');
INSERT INTO #dummy
SELECT * FROM sys.dm_db_index_physical_stats(db_id(), OBJECT_ID('dbo.FactInternetSales'), 1, NULL, 'DETAILED');

INSERT INTO @ResultTable (Mode) VALUES ('Finished');

;WITH cte
AS
(
	SELECT *, LEAD(StartDate, 1, NULL) OVER (ORDER BY StartDate ASC) AS FinishDate
	FROM @ResultTable
)
SELECT Mode, StartDate, FinishDate, DATEDIFF(ms, StartDate, FinishDate) AS Duration
FROM cte;