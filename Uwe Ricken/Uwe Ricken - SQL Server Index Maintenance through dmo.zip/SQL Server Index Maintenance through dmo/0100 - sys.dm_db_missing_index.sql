/*============================================================================
	File:		0007 - sys.dm_db_index_operational_stats.sql

	Summary:	This script creates multiple relations and indexes for analysis

				THIS SCRIPT IS PART OF THE TRACK: "DMO for index maintenance"

	Date:		Januar 2013

	SQL Server Version: 2012 / 2014
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE demo_db;
GO

-- START demo 0099 - Random query execution for all given tables.sql vor der Analyse!

-- information about "gleich gelagerte" Abfragen
SELECT * FROM sys.dm_db_missing_index_groups;

-- Informationen �ber die "Probleme dieser Abfragegruppen
SELECT * FROM sys.dm_db_missing_index_group_stats;

-- Informationen �ber die Indexdetails von "m�glichen" neuen Indexen
SELECT * FROM sys.dm_db_missing_index_details
ORDER BY
	database_id,
	index_handle;

-- Informationen �ber die Attribute, die bei einer Indexgestaltung ber�cksichtigt werden m�ssen / sollen
SELECT * FROM sys.dm_db_missing_index_columns (NULL)

-- Analyse

SELECT * FROM dbo.tbl_Cluster WHERE c1 = 'Test';
SELECT * FROM dbo.tbl_Cluster WHERE c2 = 'Noch ein Test';

-- Analyse der m�glichen Verbesserungspotentiale!
SELECT	ig.index_group_handle,
		ig.index_handle,
		igs.unique_compiles,
		igs.user_seeks,
		igs.user_scans,
		igs.avg_user_impact
FROM	sys.dm_db_missing_index_groups ig INNER JOIN sys.dm_db_missing_index_group_stats igs
		ON (ig.index_group_handle = igs.group_handle)
ORDER BY
		igs.avg_user_impact DESC,
		ig.index_group_handle,
		ig.index_handle;

-- Welche Indexe sollen denn gesetzt werden?
SELECT	ig.index_handle,
		igs.unique_compiles,
		igs.user_seeks,
		igs.user_scans,
		igs.avg_user_impact,
		id.statement,
		id.equality_columns,
		id.inequality_columns,
		id.included_columns
FROM	sys.dm_db_missing_index_groups ig INNER JOIN sys.dm_db_missing_index_group_stats igs
		ON (ig.index_group_handle = igs.group_handle) INNER JOIN sys.dm_db_missing_index_details id
		ON (ig.index_handle = id.index_handle)
WHERE	id.database_id = db_id()
ORDER BY
		igs.avg_user_impact DESC,
		ig.index_group_handle,
		ig.index_handle;

-- Fehlende Attribute in Listenform
SELECT	id.statement,
		id.equality_columns,
		id.inequality_columns,
		id.included_columns,
		ic.*
FROM	sys.dm_db_missing_index_details id CROSS APPLY sys.dm_db_missing_index_columns (id.index_handle) ic

-- advanced index analysis by Glen Berry
-- http://www.sqlskills.com

SELECT	CAST(
				user_seeks * avg_total_user_cost *
				(avg_user_impact * 0.01)
				AS NUMERIC(10, 2)
			 )							AS [index_advantage], 
		DDMIGS.last_user_seek,
		DDMID.[statement]				AS [Database.Schema.Table],
		DDMID.equality_columns,
		DDMID.inequality_columns,
		DDMID.included_columns,
		DDMIGS.unique_compiles,
		DDMIGS.user_seeks,
		DDMIGS.avg_total_user_cost,
		DDMIGS.avg_user_impact
FROM	sys.dm_db_missing_index_group_stats AS DDMIGS
		INNER JOIN sys.dm_db_missing_index_groups AS DDMIG
		ON (DDMIGS.group_handle = DDMIG.index_group_handle)
		INNER JOIN sys.dm_db_missing_index_details AS DDMID
		ON (DDMIG.index_handle = DDMID.index_handle)
ORDER BY
		DDMIGS.unique_compiles DESC OPTION (RECOMPILE);
GO