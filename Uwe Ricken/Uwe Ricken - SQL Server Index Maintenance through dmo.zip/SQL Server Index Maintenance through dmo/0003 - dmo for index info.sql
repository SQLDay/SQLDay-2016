/*============================================================================
	File:		0003 � dmo for index info.sql

	Summary:	This script creates multiple relations and indexes for analysis
				THIS SCRIPT IS PART OF THE TRACK: "DMO for index maintenance"

	Date:		Januar 2015

	SQL Server Version: 2012 / 2014
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE demo_db
GO

-- DEMO 1:	Overview of existing indexes in a table
DECLARE	@table_name	sysname	=	'dbo.tbl_Cluster';

SELECT	QUOTENAME(s.name) + '.' + QUOTENAME(t.name)	AS	table_name,
		i.name,
		i.type_desc,
		i.index_id,
		i.is_unique,
		i.is_unique_constraint,
		i.is_primary_key,
		i.data_space_id,
		i.has_filter
FROM	sys.indexes i INNER JOIN sys.tables t
		ON	(i.object_id = t.object_id) INNER JOIN sys.schemas s
		ON	(t.schema_id = s.schema_id)
WHERE	t.object_id = OBJECT_ID(@table_name, 'U')
ORDER BY
		t.name,
		i.index_id;
GO

-- DEMO 2:	Speicherbelegung von Indexen (Partitionen)
DECLARE	@table_name	sysname	=	'dbo.tbl_Cluster';

SELECT	OBJECT_NAME(i.object_id)		AS	table_name,
		i.index_id,
		i.name,
		i.type_desc,
		p.partition_id,
		p.partition_number,
		p.hobt_id,
		p.rows,
		p.data_compression,
		p.data_compression_desc
FROM	sys.indexes i INNER JOIN sys.partitions p
		ON	(
				i.object_id = p.object_id AND
				i.index_id = p.index_id AND
				i.data_space_id = p.partition_number
			)
WHERE	i.object_id = OBJECT_ID(@table_name, 'U')
ORDER BY
		OBJECT_NAME(i.object_id),
		i.index_id;
GO

-- DEMO 3:	Speicherbelegung von Indexen (Allokationen)
DECLARE	@table_name	sysname	=	'dbo.tbl_heap';

SELECT	OBJECT_NAME(i.object_id)		AS	table_name,
		i.index_id,
		i.name,
		i.type_desc,
		p.rows,
		p.data_compression_desc,
		au.type_desc,
		au.total_pages,
		au.used_pages,
		au.data_pages
FROM	sys.indexes i INNER JOIN sys.partitions p
		ON	(
				i.object_id = p.object_id AND
				i.index_id = p.index_id AND
				i.data_space_id = p.partition_number
			) INNER JOIN sys.allocation_units au
		ON	(p.partition_id = au.container_id)
WHERE	i.object_id = OBJECT_ID(@table_name, 'U')
ORDER BY
		OBJECT_NAME(i.object_id),
		i.index_id;
GO

-- Demo 4:	Speicherbelegung von Indexen (Partitionsstatistiken)
DECLARE	@table_name	nvarchar(128) = 'dbo.tbl_blob';

SELECT	t.name,
		i.name,
		i.type_desc,
		ps.in_row_data_page_count,
		ps.lob_used_page_count,
		ps.row_overflow_used_page_count,
		ps.used_page_count,
		ps.reserved_page_count
FROM	sys.tables t INNER JOIN sys.indexes i
		ON	(t.object_id = i.object_id) INNER JOIN sys.dm_db_partition_stats ps
		ON	(
				i.object_id = ps.object_id AND
				i.index_id = ps.index_id AND
				i.data_space_id = ps.partition_number
			)
WHERE	t.object_id = OBJECT_ID(@table_name)
ORDER BY
		t.name,
		i.index_id;