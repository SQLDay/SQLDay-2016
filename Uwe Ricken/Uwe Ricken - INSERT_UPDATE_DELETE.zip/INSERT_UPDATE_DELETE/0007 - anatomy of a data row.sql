/*============================================================================
	File:		0007 - anatomy of a data row.sql

	Summary:	This script demonstrates the properties of data pages

				THIS SCRIPT IS PART OF THE TRACK: "INSERT - UPDATE - DELETE internals"

	Date:		September 2013

	SQL Server Version: 2008 / 2012
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE demo_db;
GO

SET LANGUAGE us_english;
SET NOCOUNT ON;
GO

-- create a simple HEAP!
IF OBJECT_ID('dbo.tbl_demo', 'U') IS NOT NULL
	DROP TABLE dbo.tbl_demo
	GO

CREATE TABLE dbo.tbl_demo
(
	Id	int				NOT NULL	IDENTITY,
	c1	char(20)		NOT NULL,
	c2	char(20)		NOT NULL,
	c3	datetime		NULL,
	c4	varchar(20)		NULL,
	c5	image			NULL,
	c6	varchar(max)	NULL
);
GO

CHECKPOINT;
GO

SELECT * FROM sys.fn_dblog(NULL, NULL);
GO

INSERT INTO dbo.tbl_demo (c1, c2, c3, c4)
VALUES ('Donald', 'Daisy', '19920321', 'married')

-- what pages will the data allocate?
SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS Alloction, * FROM dbo.tbl_demo;

-- what happend when the record has been inserted
SELECT	[Current LSN],
		Operation,
		Context,
		AllocUnitId,
		AllocUnitName,
		[Page ID],
		[Slot ID],
		[RowLog Contents 0]
FROM	sys.fn_dblog(NULL, NULL)
WHERE	Operation = 'LOP_INSERT_ROWS';
GO

/*
	30003800 01000000 446F6E61 6C642020 20202020
	20202020 20202020 44616973 79202020 20202020
	20202020 20202020 00000000 92830000 07006001
	0046006D 61727269 6564
*/

-- buffer and page header + row information + slot array
DBCC TRACEON(3604);
DBCC PAGE ('db_demo', 1, 291, 1);

-- RETURN TO PPT

SELECT	Id,
		c1,
		c2,
		c3,
		c4
FROM	dbo.tbl_demo

UNION ALL

SELECT	CAST(0x01 AS int)												AS	Id,
		CAST(0x446f6e616c642020202020202020202020202020 AS char(20))	AS	c1,
		CAST(0x4461697379202020202020202020202020202020 AS char(20))	AS	c2,
		DATEADD(dd, CAST(0x8392 AS int), '19000101')					AS	c3,
		CAST(0x6d617272696564 AS varchar(20))							AS	c4

CHECKPOINT;
GO

-- INSERT a new record + image
INSERT INTO dbo.tbl_demo (c1, c2, c3, c4, c5)
VALUES
('Mickey', 'Minnie', '20130101', 'divorced', 0x00);
GO

-- what happend when the record has been inserted
SELECT	[Current LSN],
		Operation,
		Context,
		AllocUnitId,
		AllocUnitName,
		[Page ID],
		[Slot ID],
		[RowLog Contents 0]
FROM	sys.fn_dblog(NULL, NULL)
WHERE	Operation = 'LOP_INSERT_ROWS';
GO

CHECKPOINT;
GO

-- Insert a new record + image + a few words
INSERT INTO dbo.tbl_demo (c1, c2, c3, c4, c5, c6)
VALUES
(
	'Goofy',
	'who :)',
	'20100101',
	'no status',
	0x01010101010101,
	'bla bla bla'
);

-- what happend when the record has been inserted
SELECT	[Current LSN],
		Operation,
		Context,
		AllocUnitId,
		AllocUnitName,
		[Page ID],
		[Slot ID],
		[RowLog Contents 0]
FROM	sys.fn_dblog(NULL, NULL)
WHERE	Operation = 'LOP_INSERT_ROWS';
GO

CHECKPOINT;
GO

-- Insert new record + image + lots of bla bla bla
INSERT INTO dbo.tbl_demo (c1, c2, c3, c4, c5, c6)
VALUES
(
	'Goofy',
	'who :)',
	'20100101',
	'no status',
	0x01010101010101,
	REPLICATE('bla bla bla ', 1000)
);

-- what happend when the record has been inserted
SELECT	[Current LSN],
		Operation,
		Context,
		AllocUnitId,
		AllocUnitName,
		[Page ID],
		[Slot ID],
		[RowLog Contents 0]
FROM	sys.fn_dblog(NULL, NULL)
WHERE	Operation = 'LOP_INSERT_ROWS';
GO
