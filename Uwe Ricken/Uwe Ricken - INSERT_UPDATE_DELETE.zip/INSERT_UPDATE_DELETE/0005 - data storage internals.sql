/*============================================================================
	File:		0005 - data storage internals.sql

	Summary:	This script demonstrates the dependencies from indexes to partitions
				and allocation units

				THIS SCRIPT IS PART OF THE TRACK: "INSERT - UPDATE - DELETE internals"

	Date:		September 2013

	SQL Server Version: 2008 / 2012
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE demo_db;
GO

SET LANGUAGE us_english;
SET NOCOUNT ON;
GO

-- create a simple HEAP!
IF OBJECT_ID('dbo.tbl_demo', 'U') IS NOT NULL
	DROP TABLE dbo.tbl_demo
	GO

CREATE TABLE dbo.tbl_demo
(
	Id	int			NOT NULL	IDENTITY,
	c1	char(20)	NOT NULL,
	c2	char(20)	NOT NULL,
	c3	datetime	NULL,
	c4	varchar(20)	NULL
);
GO

-- what indexes do we have?
SELECT * FROM sys.indexes i
WHERE	i.object_id = OBJECT_ID('dbo.tbl_demo', 'U');
GO

-- how is the relation (index) be separated on partitions?
SELECT	i.name,
		i.type_desc,
		p.partition_id,
		p.partition_number,
		p.hobt_id,
		p.rows,
		p.data_compression,
		p.data_compression_desc
FROM	sys.indexes i INNER JOIN sys.partitions p
		ON	(
				i.index_id = p.index_id AND
				i.object_id = p.object_id AND
				i.data_space_id = p.partition_number
			)
WHERE	p.object_id = OBJECT_ID('dbo.tbl_demo', 'U');
GO

-- what allocation units will be used by the relation / index
SELECT	au.*
FROM	sys.partitions p INNER JOIN sys.allocation_units au
		ON (p.partition_id = au.container_id)
WHERE	p.object_id = OBJECT_ID('dbo.tbl_demo', 'U');
GO

-- Now we check the allocation units with different storage types
ALTER TABLE dbo.tbl_demo
ADD c5 IMAGE NULL,
	c6 varchar(max) NULL
GO

-- Multiple allocation units have been created for BLOB and row overflow data
-- what allocation units will be used by the relation / index
SELECT	au.*
FROM	sys.partitions p INNER JOIN sys.allocation_units au
		ON (p.partition_id = au.container_id)
WHERE	p.object_id = OBJECT_ID('dbo.tbl_demo', 'U');
GO

-- Clean the kitchen
IF OBJECT_ID('dbo.tbl_demo', 'U') IS NOT NULL
	DROP TABLE dbo.tbl_demo;
	GO