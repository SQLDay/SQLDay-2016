/*============================================================================
	File:		0009 - HEAP vs Clustered Index.sql

	Summary:	This script creates a relation dbo.demo_table for the demonstration
				of INSERT-Internals for HEAPS

				THIS SCRIPT IS PART OF THE TRACK: "INSERT - UPDATE - DELETE internals"

	Date:		September 2013

	SQL Server Version: 2008 / 2012
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE demo_db;
GO

IF OBJECT_ID('dbo.Customer', 'U') IS NOT NULL
	DROP TABLE dbo.Customer;
	GO

-- First step is the creation of a HEAP
CREATE TABLE dbo.Customer
(
	Id		INT			NOT NULL	IDENTITY (1, 1),
	Name	CHAR(200)	NOT NULL,
	Street	CHAR(100)	NOT NULL,
	ZIP		CHAR(10)	NOT NULL,
	City	CHAR(100)	NOT NULL
);
GO

-- Fill the table with a few data with SQL Data Generator
-- [Insert Data into dbo.customers.sqlgen]

-- physical data structure of the heap
SELECT	page_type,
		page_type_desc,
		page_level,
		allocated_page_iam_page_id,
		page_free_space_percent,
		allocated_page_page_id,
		previous_page_page_id,
		next_page_page_id
FROM	sys.dm_db_database_page_allocations
(
	DB_ID(),
	OBJECT_ID('dbo.Customer', 'U'),
	NULL,
	NULL,
	'DETAILED'
)
WHERE	is_allocated = 1
ORDER BY
		page_type DESC,
		allocated_page_page_id ASC;
GO

-- See information in IAM-Page
DBCC TRACEON (3604);
DBCC PAGE ('demo_db', 1, 144, 3);
GO

-- See Information in DATA_PAGE
DBCC PAGE ('demo_db', 1, 142, 3);
GO

-- Now create a clustered index on that table!
CREATE UNIQUE CLUSTERED INDEX cix_Customer_Id
ON dbo.Customer (Id);
GO

-- physical data structure of the heap
SELECT	page_type,
		page_type_desc,
		page_level,
		allocated_page_page_id,
		page_free_space_percent,
		previous_page_page_id,
		next_page_page_id
FROM	sys.dm_db_database_page_allocations
(
	DB_ID(),
	OBJECT_ID('dbo.Customer', 'U'),
	1,
	NULL,
	'DETAILED'
)
WHERE	is_allocated = 1
ORDER BY
		page_type DESC,
		page_level DESC,
		previous_page_page_id ASC
GO

-- Have a look to the root node of the clustered index
DBCC TRACEON (3604);
DBCC PAGE ('demo_db', 1, 179, 3);
GO

-- Have a look to the intermediate level of the clustered index
DBCC PAGE ('demo_db', 1, 353, 3);
GO

-- Have a look to the leaf node of the clustered index
DBCC PAGE ('demo_db', 1, 5608, 3);
GO

-- Clear the kitchen
DROP TABLE dbo.Customer;
GO
