/*============================================================================
	File:		0002 - anatomy of a heap.sql

	Summary:	This script demonstrates the internals of a heap

				THIS SCRIPT IS PART OF THE TRACK: "INSERT - UPDATE - DELETE internals"

	Date:		September 2013

	SQL Server Version: 2008 / 2012
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH (Germany)

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE demo_db;
GO

SET LANGUAGE us_english;
SET NOCOUNT ON;
GO

-- Create a simple table with NO indexes (HEAP) and fill it with a few data
IF OBJECT_ID('dbo.tbl_heap', 'U') IS NOT NULL
	DROP TABLE dbo.tbl_heap;
	GO

CREATE TABLE dbo.tbl_heap
(
	Id	int			NOT NULL	IDENTITY (1, 1),
	c1	char(200)	NOT NULL	DEFAULT ('just stuff'),
	c2	char(200)	NOT NULl	DEFAULT ('the new fragrance'),
	c3	datetime	NOT NULL	DEFAULT (getdate())
);
GO

-- Now insert 1000 records and look to the internal structure
INSERT INTO dbo.tbl_heap DEFAULT VALUES
GO 1000

-- physical data structure of the heap
SELECT	page_type,
		page_type_desc,
		allocated_page_iam_page_id,
		allocated_page_file_id,
		allocated_page_page_id,
		previous_page_page_id,
		next_page_page_id
FROM	sys.dm_db_database_page_allocations
(
	DB_ID(),
	OBJECT_ID('dbo.tbl_heap', 'U'),
	NULL,
	NULL,
	'DETAILED'
)
WHERE	is_allocated = 1
ORDER BY
		page_type DESC,
		allocated_page_page_id ASC;
GO

-- Get deeper and have a look to the IAM and a data page
DBCC TRACEON (3604);
DBCC PAGE ('demo_db', 1, 119, 3);
GO

-- what's inside a page
DBCC PAGE ('demo_db', 1, 120, 1);
GO

-- clear the workbench :)
IF OBJECT_ID('dbo.tbl_heap', 'U') IS NOT NULL
	DROP TABLE dbo.tbl_heap;
	GO
