/*============================================================================
	File:		006 - INSERT in a CLUSTERED INDEX and PAGE SPLITS.sql

	Summary:	This script demonstrates INSERT-Internals for CLUSTERED INDEX

				THIS SCRIPT IS PART OF THE TRACK: "INSERT - UPDATE - DELETE internals"

	Date:		September 2013

	SQL Server Version: 2008 / 2012
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE demo_db;
GO

SET LANGUAGE us_english;
SET NOCOUNT ON;
GO

IF OBJECT_ID('dbo.tbl_Clustered', 'U') IS NOT NULL
	DROP TABLE dbo.tbl_Clustered;
	GO

CREATE TABLE dbo.tbl_Clustered
(
	Id				int				NOT NULL,
	Fix1			char(2000)		NOT NULL,
	col3			datetime		NOT NULL	DEFAULT (getdate())
);
GO

-- No we insert 20 records with even id
DECLARE	@i int = 2;
WHILE @i <= 20
BEGIN
	INSERT INTO dbo.tbl_Clustered (Id, Fix1) VALUES (@i, 'just stuff' + CAST(CHECKSUM(newid()) AS varchar(20)));
	SET	@i += 2;
END
GO

-- Rebuild the index
CREATE UNIQUE CLUSTERED INDEX pk_tbl_Clustered_Id
ON dbo.tbl_Clustered (Id);
GO

-- Clear the log by usinng CHECKPOINT!
CHECKPOINT
GO

/*
	See the physical / logical positions of each record
	Every page may contain max 4 records!
*/
SELECT	p.*, c.*
FROM	dbo.tbl_Clustered c CROSS APPLY sys.fn_PhysLocCracker(%%physloc%%) p
GO

-- What happens if we enter a new record at the end of the table
BEGIN TRANSACTION
GO
	INSERT INTO dbo.tbl_Clustered (Id, Fix1)
	VALUES (22, 'This is my last record');

	SELECT	dt.database_transaction_log_bytes_used,
			dt.database_transaction_log_record_count
	FROM	sys.dm_tran_database_transactions dt
	WHERE	database_id = db_id();
COMMIT TRANSACTION
GO

-- See the physical / logical positions of each record
SELECT	p.*, c.*
FROM	dbo.tbl_Clustered AS c CROSS APPLY sys.fn_PhysLocCracker(%%physloc%%) AS p
GO

-- Clear the log!
CHECKPOINT;
GO

-- Now we enter a new record in between 
BEGIN TRANSACTION PageSplit
GO
	INSERT INTO dbo.tbl_Clustered (Id, Fix1)
	VALUES (5, 'This is my very last record');
	GO

	SELECT	dt.database_transaction_log_bytes_used,
			dt.database_transaction_log_record_count
	FROM	sys.dm_tran_database_transactions dt
	WHERE	database_id = db_id();
	GO

COMMIT TRANSACTION PageSplit
GO

-- See the physical / logical positions of each record
SELECT	p.*, c.*
FROM	dbo.tbl_Clustered c CROSS APPLY sys.fn_PhysLocCracker(%%physloc%%) p

-- what did happen inside the named transaction?
SELECT	[Current LSN],
		Operation,
		Context,
		AllocUnitId,
		AllocUnitName,
		[Page ID],
		[Slot ID],
		[Lock Information],
		[RowLog Contents 0]
FROM	sys.fn_dblog(NULL, NULL)
WHERE	Context != 'LCX_NULL' AND
		[Transaction ID] IN
		(
			SELECT	[Transaction ID]
			FROM	sys.fn_dblog(NULL, NULL)
			WHERE	[Transaction Name] = 'PageSplit'
		)
ORDER BY
		[Current LSN];
GO

-- But what did happen overall?
SELECT	[Current LSN],
		Operation,
		Context,
		AllocUnitId,
		AllocUnitName,
		[Page ID],
		[Slot ID],
		[Lock Information],
		[RowLog Contents 0]
FROM	sys.fn_dblog(NULL, NULL)
WHERE	Context != 'LCX_NULL'
ORDER BY
		[Current LSN];
GO

CHECKPOINT;
GO

-- Clear the kitchen
IF OBJECT_ID('dbo.tbl_Clustered', 'U') IS NOT NULL
	DROP TABLE dbo.tbl_Clustered;
	GO
