/*
	Property of Paul Randal (SQLSkills) - http://www.sqlskills.com
	Blog article:	Inside the Storage Engine: Ghost cleanup in depth
					http://www.sqlskills.com/blogs/paul/inside-the-storage-engine-ghost-cleanup-in-depth/	
*/

SET NOCOUNT ON; 
GO 

DECLARE	@Result TABLE
(
	session_id	int				NULL,
	request_id	int				NULL,
	start_time	datetime		NULL,
	status		varchar(255)	NULL,
	command		varchar(255)	NULL,
	sql_handle	varbinary(255)	NULL,
	wait_type	varchar(255)	NULL,
	wait_time	int				NULL
);

WHILE NOT EXISTS (SELECT * FROM @Result) 
	INSERT INTO @Result
	(session_id, request_id, start_time, status, command, sql_handle, wait_type, wait_time)
	SELECT	session_id, request_id, start_time, status, command, sql_handle, wait_type, wait_time
	FROM	sys.dm_exec_requests
	WHERE	command = 'GHOST CLEANUP' AND
			database_id = db_id('demo_db');

SELECT * FROM @Result; 
GO