/*============================================================================
	File:		0001 - create database and relations.sql

	Summary:	This script creates a demo database which will be used for
				the future demonstration scripts

				THIS SCRIPT IS PART OF THE TRACK: "INSERT - UPDATE - DELETE internals"

	Date:		September 2013

	SQL Server Version: 2008 / 2012
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE master;
GO

-- if the database exists we drop it for a brand new database
RAISERROR ('Databse [demo_db] will be created...', 0, 1) WITH NOWAIT;
IF db_id('demo_db') IS NOT NULL
BEGIN
	ALTER DATABASE demo_db SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
	DROP DATABASE demo_db;
END
GO

CREATE DATABASE demo_db
ON PRIMARY
(
	Name = 'demo_db',
	FILENAME = 'F:\DATA\demo_db.mdf',
	SIZE = 100MB,
	MAXSIZE = 1000MB,
	FILEGROWTH = 100MB
)
LOG ON
(
	NAME = 'demo_log',
	FILENAME = 'F:\DATA\demo_db.ldf',
	SIZE = 100MB,
	MAXSIZE = 1000MB,
	FILEGROWTH = 100MB
);
GO

RAISERROR ('Changing the datbaase owner to [sa]', 0, 1) WITH NOWAIT;
ALTER AUTHORIZATION ON DATABASE::demo_db TO sa;

-- for the demos concerning fn_dbLog() keep in mind to set the
-- RECOVERY model to full unless you want run investigation later on
RAISERROR ('Set the recovery model to SIMPLE!', 0, 1) WITH NOWAIT;
ALTER DATABASE demo_db SET RECOVERY SIMPLE;
GO