/*============================================================================
	File:		0006 - anatomy of a data page.sql

	Summary:	This script demonstrates the properties of data pages

				THIS SCRIPT IS PART OF THE TRACK: "INSERT - UPDATE - DELETE internals"

	Date:		September 2013

	SQL Server Version: 2008 / 2012
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE demo_db;
GO

SET LANGUAGE us_english;
SET NOCOUNT ON;
GO

-- create a simple HEAP!
IF OBJECT_ID('dbo.tbl_demo', 'U') IS NOT NULL
	DROP TABLE dbo.tbl_demo
	GO

CREATE TABLE dbo.tbl_demo
(
	Id	int				NOT NULL	IDENTITY,
	c1	char(200)		NOT NULL,
	c2	char(200)		NOT NULL,
	c3	datetime		NULL,
	c4	varchar(200)	NULL
);
GO

-- Insert some data
SET NOCOUNT ON
GO

DECLARE	@i int = 1
WHILE @i <= 100
BEGIN
	INSERT INTO dbo.tbl_demo (c1, c2, c3, c4)
	SELECT	'value: ' + CAST(@i % 100 AS varchar(3)),
			'value: ' + CAST(@i % 200 AS varchar(3)),
			DATEADD(dd, -(@i % 50), getdate()),
			'value: ' + CAST(@i % 300 AS varchar(3))
			
	SET	@i += 1;
END
GO

-- Check the physical location for analysis
SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS	Location, * FROM	dbo.tbl_demo;
GO

---- Get the page header
--DBCC TRACEON (3604);
--DBCC PAGE ('db_demo', 1, 168, 0);

-- Get the hex dump of the page by records
DBCC TRACEON (3604);
DBCC PAGE ('demo_db', 1, 163, 1);
GO

---- Get the hex dump of the page
--DBCC PAGE ('db_demo', 1, 163, 2);

---- get the hex records plus slots
--DBCC PAGE ('db_demo', 1, 163, 3);

-- See the page header differences if the HEAP turns into a clustered index
IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'cix_tbl_demo_Id')
	DROP INDEX cix_tbl_demo_Id ON dbo.tbl_demo;
	GO

CREATE UNIQUE CLUSTERED INDEX cix_tbl_demo_Id ON dbo.tbl_demo (Id);
GO

SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS Location, * FROM dbo.tbl_demo;
GO

DBCC PAGE ('demo_db', 1, 179, 0);

-- Clean the kitchen
IF OBJECT_ID('dbo.tbl_demo', 'U') IS NOT NULL
	DROP TABLE dbo.tbl_demo;
	GO
