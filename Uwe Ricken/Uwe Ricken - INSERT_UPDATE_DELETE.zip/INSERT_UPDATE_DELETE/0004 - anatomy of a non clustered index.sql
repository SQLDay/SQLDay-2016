/*============================================================================
	File:		0004 - anatomy of a non clustered index.sql

	Summary:	This script demonstrates the internal structure of a nonclustered index

				THIS SCRIPT IS PART OF THE TRACK: "INSERT - UPDATE - DELETE internals"

	Date:		September 2013

	SQL Server Version: 2008 / 2012
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH (Germany)

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE demo_db;
GO

SET LANGUAGE us_english;
SET NOCOUNT ON;
GO

-- Create a simple heap and fill it with data
IF OBJECT_ID('dbo.tbl_demo', 'U') IS NOT NULL
	DROP TABLE dbo.tbl_demo;
	GO

CREATE TABLE dbo.tbl_demo
(
	Id	int			NOT NULL	IDENTITY (1, 1),
	c1	char(200)	NOT NULL	DEFAULT ('just stuff'),
	c2	char(200)	NOT NULl	DEFAULT ('the new fragrance'),
	c3	datetime	NOT NULL	DEFAULT (getdate())
);
GO

-- Now insert 1000 records and look to the internal structure
DECLARE	@i int = 1
WHILE @i <= 1000
BEGIN
	INSERT INTO dbo.tbl_demo (c1, c2, c3)
	VALUES (DEFAULT, DEFAULT, DATEADD(dd, -(@i % 100), getdate()))

	SET	@i += 1
END
GO

-- Create a nonclustered index on c3
CREATE INDEX ix_tbl_demo_c3 ON dbo.tbl_demo (c3);
GO

-- Welche Indexe gibt es
SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID('dbo.tbl_demo', 'U');


-- See the data in it's physical location
SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS physical_location, *
FROM	dbo.tbl_demo WITH (INDEX = 0);
GO

-- and now based on the location of the non clustered index
SELECT	p.*, d.*
FROM	dbo.tbl_demo d WITH (INDEX = 2)
		CROSS APPLY sys.fn_PhysLocCracker(%%physloc%%) AS p;
GO

-- Data structure
DBCC IND ('demo_db', 'tbl_demo', 2);

-- Get deeper and have a look to the data page of the nci!
DBCC TRACEON (3604);
DBCC PAGE ('demo_db', 1, 415, 3);	-- Data page
DBCC PAGE ('demo_db', 1, 181354, 3);
GO

SELECT	Id, C1, C2, C3
FROM	dbo.tbl_demo
WHERE	C3 = '19531014 20:53:28.850';

CREATE UNIQUE CLUSTERED INDEX ix_tbl_demo_Id ON dbo.tbl_demo(Id);

SELECT * FROM sys.dm_db_database_page_allocations
(
	DB_ID(),
	OBJECT_ID('tbl_demo'),
	2,
	NULL,
	'DETAILED'
) AS DDDPA
ORDER BY
	Page_type DESC,
	page_level DESC;


-- Create a nonclustered index on c3
CREATE INDEX ix_tbl_demo_c3 ON dbo.tbl_demo (c3) INCLUDE(c2)
WITH DROP_EXISTING;
GO

SET STATISTICS IO ON;
GO

SELECT	C3 FROM dbo.tbl_demo
WHERE	c3 = '20141221 11:07:57.157';
GO

-- What will change if the heap become a clustered index?
-- Create a UNIQUE CLUSTERED INDEX on Id.
IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'cix_tbl_demo_Id')
	CREATE UNIQUE CLUSTERED INDEX cix_tbl_demo_id ON dbo.tbl_demo (Id) WITH DROP_EXISTING;
ELSE
	CREATE UNIQUE CLUSTERED INDEX cix_tbl_demo_id ON dbo.tbl_demo (Id);
GO

-- the data have been reorganized completly and the physical location
-- has changed!
SELECT	1 AS IndexId, sys.fn_PhysLocFormatter(%%physloc%%) AS Location, *
FROM	dbo.tbl_demo WITH (INDEX = 1)
WHERE	Id = 99

UNION ALL

SELECT	2 AS IndexId, sys.fn_PhysLocFormatter(%%physloc%%) AS Location, *
FROM	dbo.tbl_demo WITH (INDEX = 2)
WHERE	Id = 99;
GO

-- oops - both have been rebuild!
-- check the page information for the Id = 99 of the NCIagain!
DBCC TRACEON (3604);
DBCC PAGE ('demo_db', 1, 874, 3);	-- Data page
GO

-- Clean the kitchen
IF OBJECT_ID('dbo.tbl_demo', 'U') IS NOT NULL
	DROP TABLE dbo.tbl_demo;
	GO
