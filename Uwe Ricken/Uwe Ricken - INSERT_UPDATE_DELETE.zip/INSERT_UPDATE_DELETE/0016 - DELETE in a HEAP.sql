/*============================================================================
	File:		0015 - DELETE in a HEAP.sql

	Summary:	This script creates a relation dbo.demo_table for the demonstration
				of DELETE-Internals for heaps

				THIS SCRIPT IS PART OF THE TRACK: "INSERT - UPDATE - DELETE internals"

	Date:		September 2013

	SQL Server Version: 2008 / 2012
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE demo_db;
GO

SET LANGUAGE us_english;
SET NOCOUNT ON;
GO

IF OBJECT_ID('dbo.demo_table', 'U') IS NOT NULL
	DROP TABLE dbo.demo_table;
	GO

CREATE TABLE dbo.demo_table
(
	Id		int				NOT NULL,
	col1	char(1000)		NOT NULL	DEFAULT ('some stuff'),
	col2	varchar(200)	NOT NULL	DEFAULT ('some more stuff'),
	col3	datetime		NOT NULL	DEFAULT (getdate()),
	OrdPos	int				NOT NULL	IDENTITY (1, 1)
);
GO

-- Insert 100 records
DECLARE	@i int = 1;
WHILE @i <= 100
BEGIN
	INSERT INTO dbo.demo_table (Id, col1, col2, col3) VALUES (@i, DEFAULT, DEFAULT, DEFAULT);
	SET @i += 1;
END
GO

-- physical data structure of the heap
SELECT	page_type,
		page_type_desc,
		allocated_page_iam_page_id,
		allocated_page_file_id,
		allocated_page_page_id,
		previous_page_page_id,
		next_page_page_id
FROM	sys.dm_db_database_page_allocations(db_id(), OBJECT_ID('dbo.demo_table', 'U'), NULL, NULL, 'DETAILED')
WHERE	is_allocated = 1
ORDER BY
		page_type DESC,
		allocated_page_page_id ASC;
GO

CHECKPOINT;
GO

-- Delete one record from the heap and look to the transaction log
BEGIN TRANSACTION DeleteRecord
GO
	DELETE	dbo.demo_table WHERE Id = 5;
	GO

	-- what resources are blocked?
	SELECT	resource_type,
			resource_description,
			resource_associated_entity_id,
			u.type,
			u.type_desc,
			OBJECT_NAME(ISNULL(p.object_id, l.resource_associated_entity_id))	AS	object_name,
			request_mode,
			request_type
	FROM	sys.dm_tran_locks l LEFT JOIN sys.allocation_units u
			ON	(l.resource_associated_entity_id = u.container_id) LEFT JOIN sys.partitions p
			ON	(
					u.container_id = 
						CASE WHEN u.type IN (1, 3)
							THEN p.hobt_id
							ELSE p.partition_id
						END
				)
	WHERE	resource_database_id = db_id() AND
			request_session_id = @@SPID;
	GO

	-- see the amount of operations which took place!
	SELECT	database_transaction_log_bytes_used,
			database_transaction_log_record_count
	FROM	sys.dm_tran_database_transactions
	WHERE	database_id = db_id();
	GO
COMMIT TRANSACTION DeleteRecord
GO

-- What happend inside the named transaction?
SELECT	[Current LSN],
		Operation,
		Context,
		[Log Record Length],
		AllocUnitId,
		AllocUnitName,
		[Page ID],
		[Slot ID],
		[Lock Information],
		[RowLog Contents 0]
FROM	sys.fn_dblog(NULL, NULL)
WHERE	Context != 'LCX_NULL' AND
		LEFT([Current LSN], LEN([Current LSN]) - 5) IN
		(
			SELECT	LEFT([Current LSN], LEN([Current LSN]) - 5)
			FROM	sys.fn_dblog(NULL, NULL)
			WHERE	[Transaction Name] = 'DeleteRecord')
ORDER BY
		[Current LSN];
GO

CHECKPOINT;
GO

-- Delete records of one page in the heap and
-- look to the transaction log
BEGIN TRANSACTION DeleteRecord
GO
	DELETE	dbo.demo_table WHERE Id <= 7;
	GO

	-- what resources are blocked?
	SELECT	resource_type,
			resource_description,
			resource_associated_entity_id,
			u.type,
			u.type_desc,
			OBJECT_NAME(ISNULL(p.object_id, l.resource_associated_entity_id))	AS	object_name,
			request_mode,
			request_type
	FROM	sys.dm_tran_locks l LEFT JOIN sys.allocation_units u
			ON	(l.resource_associated_entity_id = u.container_id) LEFT JOIN sys.partitions p
			ON	(
					u.container_id = 
						CASE WHEN u.type IN (1, 3)
							THEN p.hobt_id
							ELSE p.partition_id
						END
				)
	WHERE	resource_database_id = db_id() AND
			request_session_id = @@SPID;
	GO

COMMIT TRANSACTION DeleteRecord
GO

-- What happend inside the named transaction?
SELECT	[Current LSN],
		Operation,
		Context,
		[Log Record Length],
		AllocUnitId,
		AllocUnitName,
		[Page ID],
		[Slot ID],
		[Lock Information],
		[RowLog Contents 0]
FROM	sys.fn_dblog(NULL, NULL)
WHERE	Context != 'LCX_NULL' AND
		LEFT([Current LSN], LEN([Current LSN]) - 5) IN
		(
			SELECT	LEFT([Current LSN], LEN([Current LSN]) - 5)
			FROM	sys.fn_dblog(NULL, NULL)
			WHERE	[Transaction Name] = 'DeleteRecord')
ORDER BY
		[Current LSN];
GO

-- physical data structure of the heap
SELECT	page_type,
		page_type_desc,
		allocated_page_iam_page_id,
		allocated_page_file_id,
		allocated_page_page_id,
		previous_page_page_id,
		next_page_page_id
FROM	sys.dm_db_database_page_allocations(db_id(), OBJECT_ID('dbo.demo_table', 'U'), NULL, NULL, 'DETAILED')
WHERE	is_allocated = 1
ORDER BY
		page_type DESC,
		allocated_page_page_id ASC;
GO

CHECKPOINT;
GO

SELECT	F.*,
		D.*
FROM	dbo.demo_table AS D
		CROSS APPLY sys.fn_PhysLocCracker(%%physloc%%) AS F;
GO

-- Delete complete heap
BEGIN TRANSACTION DeleteRecord
GO
	-- to release the allocated pages a TABLOCK hint
	-- need to be used because of an eXclusive table
	-- lock!
	DELETE	dbo.demo_table WITH (TABLOCK)
	WHERE	Id BETWEEN 8 AND 14;
	GO

	-- what resources are blocked?
	SELECT	resource_type,
			resource_description,
			resource_associated_entity_id,
			u.type,
			u.type_desc,
			OBJECT_NAME(ISNULL(p.object_id, l.resource_associated_entity_id))	AS	object_name,
			request_mode,
			request_type
	FROM	sys.dm_tran_locks l LEFT JOIN sys.allocation_units u
			ON	(l.resource_associated_entity_id = u.container_id) LEFT JOIN sys.partitions p
			ON	(
					u.container_id = 
						CASE WHEN u.type IN (1, 3)
							THEN p.hobt_id
							ELSE p.partition_id
						END
				)
	WHERE	resource_database_id = db_id() AND
			request_session_id = @@SPID;
	GO

COMMIT TRANSACTION DeleteRecord
GO

SELECT	F.*,
		D.*
FROM	dbo.demo_table AS D
		CROSS APPLY sys.fn_PhysLocCracker(%%physloc%%) AS F;
GO


/*
	physical data structure of the heap
	notice that the very first page from the demos has not been
	removed!
	It has never been touched anymore by a DELETE-transaction
	so SQL Server doesn't need to remove it automatically
	ONLY A REBUILD WILL REMOVE EMPTY PAGES!
*/
SELECT	page_type,
		page_type_desc,
		allocated_page_iam_page_id,
		allocated_page_file_id,
		allocated_page_page_id,
		previous_page_page_id,
		next_page_page_id
FROM	sys.dm_db_database_page_allocations(DB_ID(), OBJECT_ID('dbo.demo_table', 'U'), NULL, NULL, 'DETAILED')
WHERE	is_allocated = 1
ORDER BY
		page_type DESC,
		allocated_page_page_id ASC;
GO

SET STATISTICS IO ON;
GO

SELECT * FROM dbo.demo_table;
GO

SET STATISTICS IO OFF;
GO

CHECKPOINT;
GO

DBCC TRACEON (3604);
DBCC PAGE (demo_db, 1, 1, 3);
GO


ALTER TABLE dbo.demo_table REBUILD;
GO

-- clean the kitchen
IF OBJECT_ID('dbo.demo_table', 'U') IS NOT NULL
	DROP TABLE dbo.demo_table;
	GO
