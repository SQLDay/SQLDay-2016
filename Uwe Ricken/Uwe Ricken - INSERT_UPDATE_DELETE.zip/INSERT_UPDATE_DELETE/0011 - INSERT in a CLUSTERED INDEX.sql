/*============================================================================
	File:		0011 - INSERT in a CLUSTERED INDEX.sql

	Summary:	This script creates a relation dbo.demo_table for the demonstration
				of INSERT-Internals for CLUSTERED INDEXES

				THIS SCRIPT IS PART OF THE TRACK: "INSERT - UPDATE - DELETE internals"

	Date:		September 2013

	SQL Server Version: 2008 / 2012
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
SET NOCOUNT ON;
SET LANGUAGE us_english;
GO

USE demo_db;
GO

/*
	Demo 1:	Simple insert of data into a brand new Cluster
*/

IF OBJECT_ID('dbo.demo_table', 'U') IS NOT NULL
	DROP TABLE dbo.demo_table;
	GO

CREATE TABLE dbo.demo_table
(
	Id		int				NOT NULL,
	col1	char(200)		NOT NULL	DEFAULT ('some stuff'),
	col2	varchar(200)	NOT NULL	DEFAULT ('some more stuff'),
	col3	datetime		NOT NULL	DEFAULT (getdate()),
	OrdPos	int				NOT NULL	IDENTITY (1, 1)
);
GO

-- Create the clustered index
CREATE UNIQUE CLUSTERED INDEX ix_tbl_cluster_id ON dbo.demo_table (Id);
GO

CHECKPOINT;
GO

SELECT * FROM sys.fn_dblog(NULL, NULL);

-- Insert ONE row into the CLUSTER and see the transactions
BEGIN TRANSACTION InsertRecord
GO
	INSERT INTO dbo.demo_table(Id, col1, col2, col3)
	VALUES (10, 'Uwe', 'Ricken', '19640218')

	/*
		what resources are blocked?
		watch the resource description for the row (hash value)
	*/
	SELECT	resource_type,
			resource_description,
			resource_associated_entity_id,
			u.type,
			u.type_desc,
			OBJECT_NAME(ISNULL(p.object_id, l.resource_associated_entity_id))	AS	object_name,
			request_mode,
			request_type
	FROM	sys.dm_tran_locks l LEFT JOIN sys.allocation_units u
			ON	(l.resource_associated_entity_id = u.container_id) LEFT JOIN sys.partitions p
			ON	(
					u.container_id = 
						CASE WHEN u.type IN (1, 3)
							THEN p.hobt_id
							ELSE p.partition_id
						END
				)
	WHERE	resource_database_id = db_id() AND
			request_session_id = @@SPID;
	GO

COMMIT TRANSACTION InsertRecord
GO

-- What happend inside the named transaction?
SELECT	[Current LSN],
		Operation,
		Context,
		[Log Record Length],
		AllocUnitId,
		AllocUnitName,
		[Page ID],
		[Slot ID],
		[Lock Information]
FROM	sys.fn_dblog(NULL, NULL)
WHERE	Context != 'LCX_NULL' AND
		LEFT([Current LSN], LEN([Current LSN]) - 5) IN
		(
			SELECT	LEFT([Current LSN], LEN([Current LSN]) - 5)
			FROM	sys.fn_dblog(NULL, NULL)
			WHERE	[Transaction Name] = 'InsertRecord')
ORDER BY
		[Current LSN];
GO


-- Select records and it's location
SELECT	p.*, c.*
FROM	dbo.demo_table AS c
		CROSS APPLY sys.fn_PhysLocCracker(%%physloc%%) AS p
GO

-- Free the log again and enter another record
CHECKPOINT;
GO

-- Insert ONE new row into the clustered index and see the transactions
BEGIN TRANSACTION InsertRecord
GO

	INSERT INTO dbo.demo_table(Id, col1, col2, col3)
	VALUES (5, 'Katharina', 'Ricken', '19921011')

COMMIT TRANSACTION InsertRecord
GO

-- take care of the transaction log what slot will be used by the transaction
SELECT	[Current LSN],
		Operation,
		Context,
		AllocUnitId,
		AllocUnitName,
		[Page ID],
		[Slot ID],
		[Lock Information],
		[RowLog Contents 0]
FROM	sys.fn_dblog(NULL, NULL)
WHERE	[Transaction ID] IN
		(
			SELECT	[Transaction ID]
			FROM	sys.fn_dblog(NULL, NULL)
			WHERE	[Transaction Name] = 'InsertRecord'
		)
ORDER BY
		[Current LSN];
GO

-- Select records and it's location
SELECT	sys.fn_PhysLocFormatter(%%physloc%%) AS Location, * FROM dbo.demo_table WITH (INDEX (1));
GO

/*
	When investigating the affected data page you will notice that
	data will not be stored in their physical order but only the 
	slot array will determine the offset where a record starts!
*/
DBCC TRACEON (3604);
DBCC PAGE ('demo_db', 1,168, 1);
GO

-- Clean the kitchen
IF OBJECT_ID('dbo.demo_table', 'U') IS NOT NULL
	DROP TABLE dbo.demo_table;
	GO

/*
	===================================================================================
	Demo 2:	What will happen if multiple records will be inserted into a table.
	===================================================================================
*/

-- Let's fill a few pages with new records for the next demo
IF OBJECT_ID('dbo.demo_table', 'U') IS NOT NULL
	DROP TABLE dbo.demo_table;
	GO

CREATE TABLE dbo.demo_table
(
	Id	int			NOT NULL	IDENTITY (1, 1),
	c1	char(2500)	NOT NULL,

	CONSTRAINT pk_tbl_Cluster_Id PRIMARY KEY CLUSTERED (Id)
);
GO


CHECKPOINT;
GO

-- Calculation for the amount of data for one page:
/*
	Pagesize:	8192 Bytes
	Header:		  96 Bytes
	SlotArray:	  36 Bytes
	Data:		8060 Bytes

	1 Record has a size of 2510Bytes (4 + 2500 + 4 (Header) + 2 (Slot Array))
	8096 Bytes / 2510 Bytes = 3 records + 1556 Bytes!
*/ 

-- Let's insert 3 rows!
INSERT INTO dbo.demo_table (c1)
VALUES
('Uwe Ricken'),
('Beate Ricken'),
('Alicia Ricken');
GO

-- What pages will be allocated by the table
SELECT	p.*, h.*
FROM	dbo.demo_table AS h
		CROSS APPLY sys.fn_PhysLocCracker(%%physloc%%) AS p;
GO

INSERT INTO dbo.demo_table (c1)
VALUES
('Katharina Ricken')
GO

INSERT INTO dbo.demo_table (c1)
VALUES
('Emma Ricken');
GO

INSERT INTO dbo.demo_table (c1)
VALUES
('Josie Ricken');
GO

-- What pages will be allocated by the table
SELECT	p.*, h.*
FROM	dbo.demo_table AS h
		CROSS APPLY sys.fn_PhysLocCracker(%%physloc%%) AS p;
GO

-- what is the free space on the data page of the first three records?
/*
	Become aware that all pages which are part of an index doesn't have
	ANY information about it's filling status!
	This is only available for HEAPS!
*/
DBCC TRACEON (3604);
DBCC PAGE ('demo_db', 1, 1, 3);
DBCC PAGE ('demo_db', 1, 168, 1);
GO

-- Clean the kitchen!
IF OBJECT_ID('dbo.demo_table', 'U') IS NOT NULL
	DROP TABLE dbo.demo_table;
	GO
