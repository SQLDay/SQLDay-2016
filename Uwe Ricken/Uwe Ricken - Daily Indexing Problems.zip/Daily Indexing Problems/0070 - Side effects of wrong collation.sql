/*============================================================================
	File:		0070 - Side effects of wrong collation.sql

	Summary:	This script creates two tables with the same structure to
				store actual data and historical data (partitioning).
				The query will always use both tables although data are
				only expected in ONE table!

	WebLink:	http://db-berater.blogspot.de/2013/07/optimierung-von-partitioned-views.html

	Date:		Dezember 2014

	SQL Server Version: 2012 / 2014
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
SET NOCOUNT ON;
SET LANGUAGE us_english;
USE master;
GO

-- What collation for TEMPDB and Server?
SELECT	name                        AS DatabaseName,
		collation_name              AS DatabaseCollation,
		SERVERPROPERTY('Collation') AS ServerCollation
FROM    sys.databases AS D
WHERE   D.database_id = 2;
GO

-- Create a new database with a different collation than TEMPDB!
RAISERROR ('Datenbank %s will be created...', 0, 1, 'demo_db') WITH NOWAIT;
IF DB_ID('demo_db') IS NOT NULL
BEGIN
	ALTER DATABASE [demo_db] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
	DROP DATABASE [demo_db];
END
GO

CREATE DATABASE [demo_db]
ON  PRIMARY 
(
	NAME = N'demo_db',
	FILENAME = N'F:\DATA\demo_db.mdf',
	SIZE = 100MB,
	MAXSIZE = 500MB,
	FILEGROWTH = 100MB
)
LOG ON 
(
	NAME = N'demo_log',
	FILENAME = N'F:\DATA\demo_db.ldf',
	SIZE = 100MB,
	MAXSIZE = 500MB,
	FILEGROWTH = 100MB
)
COLLATE Latin1_General_BIN;
GO

ALTER AUTHORIZATION ON DATABASE::demo_db TO sa;
ALTER DATABASE [demo_db] SET RECOVERY SIMPLE;
GO

-- Get a look to the settings of demo_db and TEMPDB;
-- What collation for TEMPDB and Server?
SELECT	name                        AS DatabaseName,
		collation_name              AS DatabaseCollation,
		SERVERPROPERTY('Collation') AS ServerCollation
FROM    sys.databases AS D
WHERE   D.database_id IN (2, DB_ID('demo_db'));
GO

-- Create a table in demo_db with an attribute which can be affected
-- by collation conflicts!
USE demo_db;
GO

CREATE TABLE dbo.Customers
(
	Customer_Id		INT				NOT NULL    IDENTITY (1, 1),
	Customer_Number	CHAR(5)			NOT NULL,
	Customer_Name	VARCHAR(255)    NOT NULL,
	
	CONSTRAINT pk_Customers_Id PRIMARY KEY CLUSTERED (Customer_Id)
);
GO

/*
	Fill the data with SQL Data Generator from Red Gate
	use Demodata 0080.sqlgen!
*/

-- Additional index on Customer_Number because this is the natural unique key!
CREATE UNIQUE INDEX ix_Customers_Number ON dbo.Customers (Customer_Number)
INCLUDE (Customer_Name);
GO

SELECT * FROM dbo.Customers ORDER BY Customer_Number;
GO

-- Have a look to the meta data of the attributes of dbo.Customers
SELECT	OBJECT_NAME(C.object_id)	AS Table_Name,
		C.name						AS Column_Name,
		S.name						AS Type_Name,
		C.column_id,
		C.max_length,
		C.collation_name
FROM	sys.columns AS C INNER JOIN sys.types AS S
		ON (C.system_type_id = S.system_type_id)
WHERE   object_id = object_id('dbo.Customers', 'U');
GO

-- Create a temporary table
CREATE TABLE #t (Customer_Number CHAR(5) PRIMARY KEY CLUSTERED);
GO

-- Fill it with a few data
INSERT INTO #t ( Customer_Number )
SELECT TOP 50 Customer_Number
FROM dbo.Customers;


SET STATISTICS IO ON;
GO


-- Run a query against the customer table with a JOIN to #t
-- Test 1: WILL IT work?
SELECT	C.*
FROM	dbo.Customers AS C INNER JOIN #t AS CN
		ON	(C.Customer_Number = CN.Customer_Number);

-- NO: fails with collation conflict(s)!

-- Test 2: use the collation of TEMPDB!
SELECT	C.*
FROM	dbo.Customers AS C INNER JOIN #t AS CN
		ON	(C.Customer_Number = CN.Customer_Number COLLATE Latin1_General_CI_AS)
ORDER BY
		CN.Customer_Number;

-- Test 3: use the collation of UserDB!
SELECT	C.*
FROM	dbo.Customers AS C INNER JOIN #t AS CN
		ON	(C.Customer_Number = CN.Customer_Number COLLATE Latin1_General_BIN)
ORDER BY
		CN.Customer_Number;

DROP TABLE #t;
GO

-- will it work with a table variable?
DECLARE @t TABLE (Customer_Number CHAR(5) PRIMARY KEY CLUSTERED);

INSERT INTO @t ( Customer_Number )
SELECT TOP 50 Customer_Number
FROM dbo.Customers;

SELECT	C.*
FROM	dbo.Customers AS C INNER JOIN @t AS CN
		ON	(C.Customer_Number = CN.Customer_Number)
ORDER BY
		CN.Customer_Number
OPTION (RECOMPILE);
GO

/* FINAL SOLUTION AT CUSTOMER SIDE */
-- A user definied procedure was used to select data
-- from an array coming from a table variable

-- First we create the type
IF EXISTS (SELECT * FROM sys.types WHERE name = 'CustomerNumbers')
	DROP TYPE CustomerNumbers;
	GO

CREATE TYPE CustomerNumbers AS TABLE (Customer_Number CHAR(5) PRIMARY KEY CLUSTERED);
GO

-- next step is the creation of a simple procedure for selection of filtered data
IF OBJECT_ID('dbo.proc_GetCustomers', 'P') IS NOT NULL
	DROP PROC dbo.proc_GetCustomers;
	GO

CREATE PROC dbo.proc_GetCustomers
	@Numbers AS CustomerNumbers READONLY
AS
	SET NOCOUNT ON;

	SELECT	C.*
	FROM	dbo.Customers AS C INNER JOIN @Numbers AS CN
			ON (C.Customer_Number = CN.Customer_Number)
	ORDER BY
			CN.Customer_Number;

	SET NOCOUNT OFF;
GO

DECLARE @t AS CustomerNumbers;

INSERT INTO @t (Customer_Number)
SELECT TOP 5 Customer_Number
FROM dbo.Customers;

-- Execute the stored procedure with the array of customer numbers
EXEC dbo.proc_GetCustomers @t;
GO

-- Clear the kitchen
DROP PROCEDURE dbo.proc_GetCustomers;
DROP TABLE dbo.Customers;
DROP TYPE CustomerNumbers;
GO