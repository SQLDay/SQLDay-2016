/*============================================================================
	File:		0060 - ranking of data types.sql

	Summary:	This script creates a table with different data types to check
				the execution plan! Although the execution plan is showing a
				SEEK operation it is a SCAN in behind!

	WebLink:	http://db-berater.blogspot.de/2014/11/rangfolge-von-datentypen-auswirkung-auf.html

	Date:		Dezember 2014

	SQL Server Version: 2012 / 2014
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
SET NOCOUNT ON;
SET LANGUAGE us_english;
USE demo_db;
GO

IF OBJECT_ID('dbo.demo_table', 'U') IS NOT NULL
	DROP TABLE dbo.demo_table;
	GO

CREATE TABLE dbo.demo_table
(
	Id	INT			NOT NULL	IDENTITY (1, 1),
	c1	SMALLMONEY	NOT NULL,
	c2	CHAR(5)		NOT NULL,

	CONSTRAINT pk_demo_table_id PRIMARY KEY CLUSTERED (Id)
);

/*
	Now we fill both tables with redgate data monitor with sample data
	use Demodata 0060.sqlgen!
*/

-- Create an additional index for demonstration
CREATE INDEX ix_demo_table_c2 ON dbo.demo_table (c2) INCLUDE (c1);
GO

SET STATISTICS IO ON;
GO

SELECT c1, c2 FROM dbo.demo_table WHERE c2 = 10275;
SELECT c1, c2 FROM dbo.demo_table WHERE c2 = '10275';
GO

-- Change the data type from char(5) to INT
DROP INDEX ix_demo_table_c2 ON dbo.demo_table;
GO

-- Change the data type of the attribute
ALTER TABLE dbo.demo_table ALTER COLUMN c2 INT NOT NULL;
GO

-- Rebuild the index
CREATE INDEX ix_demo_table_c2 ON dbo.demo_table (c2) INCLUDE (c1);
GO

-- what will be the faster of these queries?
SELECT c1, c2 FROM dbo.demo_table WHERE c2 = 10275;
SELECT c1, c2 FROM dbo.demo_table WHERE c2 = '10275';
GO

SET STATISTICS IO OFF;
GO

-- precedence of data types in Microsoft SQL Server!
http://msdn.microsoft.com/en-us/library/ms190309.aspx

-- clean the kitchen
IF OBJECT_ID('dbo.demo_table', 'U') IS NOT NULL
	DROP TABLE dbo.demo_table;
	GO
