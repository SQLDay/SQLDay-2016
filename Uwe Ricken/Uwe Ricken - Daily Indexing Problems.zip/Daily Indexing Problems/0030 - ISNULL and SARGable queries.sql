/*============================================================================
	File:		0030 - ISNULL and SARGable queries.sql

	Summary:	This script creates two tables with the same structure to
				store actual data and historical data (partitioning).
				The query will always use both tables although data are
				only expected in ONE table!

	WebLink:	http://db-berater.blogspot.de/2014/08/isnull-als-predikat-seek-oder-scan.html

	Date:		Dezember 2014

	SQL Server Version: 2012 / 2014
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
SET NOCOUNT ON;
SET LANGUAGE us_english;
USE demo_db;
GO

IF OBJECT_ID('dbo.ZIP_PROD', 'U') IS NOT NULL
	DROP TABLE dbo.ZIP_PROD;
	GO

IF OBJECT_ID('dbo.ZIP_TEST', 'U') IS NOT NULL
	DROP TABLE dbo.ZIP_TEST;
	GO

CREATE TABLE dbo.ZIP_PROD
(
	Id		INT			NOT NULL,
	CCode	CHAR(3)		NULL,
	ZIP		CHAR(10)	NULL,

	CONSTRAINT pk_ZIP_PROD_Id PRIMARY KEY CLUSTERED (Id)
);
GO

CREATE TABLE dbo.ZIP_TEST
(
	Id		INT			NOT NULL,
	CCode	CHAR(3)		NOT NULL,
	ZIP		CHAR(10)	NOT NULL,

	CONSTRAINT pk_ZIP_NOT_NULL_Id PRIMARY KEY CLUSTERED (Id)
);

/*
	Now we fill both tables with redgate data monitor with sample data
	use Demodata 0030.sqlgen!
*/

/*
	For better query power an additional index will be set on CCode
*/
CREATE INDEX ix_ZIP_PROD_CCode ON dbo.ZIP_PROD (CCode) INCLUDE (ZIP);
CREATE INDEX ix_ZIP_NOT_NULL_CCode ON dbo.ZIP_TEST (CCode) INCLUDE (ZIP);
GO

SET STATISTICS IO ON;
GO

DECLARE @Id INT;
DECLARE @CCode CHAR(3);
DECLARE @ZIP CHAR(10);

SELECT	@Id = Id,
		@CCode = CCode,
		@ZIP = ZIP
FROM	dbo.ZIP_TEST
WHERE	ISNULL(CCode, 'AA') = 'AA';
GO

DECLARE @Id INT;
DECLARE @CCode CHAR(3);
DECLARE @ZIP CHAR(10);

SELECT	@Id = Id,
		@CCode = CCode,
		@ZIP = ZIP
FROM	dbo.ZIP_PROD
WHERE	ISNULL(CCode, 'AA') = 'AA';
GO

-- make the action visible!
SELECT * FROM dbo.ZIP_TEST WHERE ISNULL(CCode, 'AA') = 'AA' OPTION (QUERYTRACEON 9130);
SELECT * FROM dbo.ZIP_PROD WHERE ISNULL(CCode, 'AA') = 'AA' OPTION (QUERYTRACEON 9130);
GO

-- Solution
DECLARE @Id INT;
DECLARE @CCode CHAR(3);
DECLARE @ZIP CHAR(10);

SELECT	@Id = Id,
		@CCode = CCode,
		@ZIP = ZIP
FROM	dbo.ZIP_TEST WHERE ISNULL(CCode, 'AA') = 'AA';
GO

DECLARE @Id INT;
DECLARE @CCode CHAR(3);
DECLARE @ZIP CHAR(10);

SELECT	@Id = Id,
		@CCode = CCode,
		@ZIP = ZIP
FROM	dbo.ZIP_PROD
WHERE	CCode IS NULL OR
		CCode = 'AA';

SELECT	Id,
		CCode,
		ZIP
FROM	dbo.ZIP_PROD
WHERE	CCode IS NULL

UNION ALL

SELECT	Id,
		CCode,
		ZIP
FROM	dbo.ZIP_PROD
WHERE	CCode = 'AA';
GO

SET STATISTICS IO OFF;
GO

-- OR make the attribute NOT NULLABLE!!!
BEGIN TRANSACTION
	-- Drop the existing index before altering the attribute
	DROP INDEX ix_ZIP_PROD_CCode ON dbo.ZIP_PROD;

	-- make the column NOT NULLable
	ALTER TABLE dbo.ZIP_PROD ALTER COLUMN CCode CHAR(3) NOT NULL;

	-- Recreate the former dropped index
	CREATE INDEX ix_ZIP_PROD_CCode ON dbo.ZIP_PROD (CCode) INCLUDE (ZIP);
COMMIT TRANSACTION
GO

-- � voil�
SELECT * FROM dbo.ZIP_TEST WHERE ISNULL(CCode, 'AA') = 'AA';
SELECT * FROM dbo.ZIP_PROD WHERE ISNULL(CCode, 'AA') = 'AA';
GO

-- Clean the kitchen
DROP TABLE dbo.ZIP_TEST;
DROP TABLE dbo.ZIP_PROD;
GO
