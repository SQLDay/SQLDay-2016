/*============================================================================
	File:		0040 - Rangfolge von Datentypen.sql

	Summary:	This script demonstrates the execution of queries which uses
				the wrong data types as predicates for indexes

	WebLink:	http://db-berater.blogspot.de/2014/11/rangfolge-von-datentypen-auswirkung-auf.html

	Date:		Dezember 2014

	SQL Server Version: 2012 / 2014
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE demo_db;
GO

IF OBJECT_ID('dbo.Orders', 'U') IS NOT NULL
	DROP TABLE dbo.Orders
	GO

CREATE TABLE dbo.Orders
(
	Id			INT			NOT NULL	IDENTITY (1, 1),
	OrderNo		VARCHAR(20)	NOT NULL,
	Customer	CHAR(1000)	NOT NULL,
	Amount		MONEY		NOT NULL	DEFAULT (0),

	CONSTRAINT pk_Orders_Id PRIMARY KEY CLUSTERED (Id)
);

/*
	Now the tables will be filled with redgate data monitor with sample data
	use Demodata 0040.sqlgen!
*/

-- Create an additional index for the next queries
CREATE UNIQUE NONCLUSTERED INDEX ix_Orders_OrderNo ON dbo.Orders (OrderNo) INCLUDE (Customer);
GO

