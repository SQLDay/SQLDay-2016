/*============================================================================
	File:		0020 - Problem with PARTITIONED VIEWS.sql

	Summary:	This script creates two tables with the same structure to
				store actual data and historical data (partitioning).
				The query will always use both tables although data are
				only expected in ONE table!

	WebLink:	http://db-berater.blogspot.de/2013/07/optimierung-von-partitioned-views.html

	Date:		Dezember 2014

	SQL Server Version: 2012 / 2014
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
SET NOCOUNT ON;
SET LANGUAGE us_english;
USE demo_db;
GO

IF OBJECT_ID('dbo.ActualOrders', 'U') IS NOT NULL
	DROP TABLE dbo.ActualOrders
	GO

CREATE TABLE dbo.ActualOrders
(
	Id			int			NOT NULL	IDENTITY (1, 1),
	Customer	char(200)	NOT NULL	DEFAULT ('just a filler'),
	OrderDate	datetime	NOT NULL	DEFAULT (getdate()),
	OrderAmount	smallmoney	NOT NULL	DEFAULT (0),

	CONSTRAINT pk_ActualOrders_Id PRIMARY KEY CLUSTERED (Id)
);
GO

IF OBJECT_ID('dbo.HistoryOrders', 'U') IS NOT NULL
	DROP TABLE dbo.HistoryOrders
	GO

CREATE TABLE dbo.HistoryOrders
(
	Id			int			NOT NULL,
	Customer	char(200)	NOT NULL	DEFAULT ('just a filler'),
	OrderDate	datetime	NOT NULL	DEFAULT (getdate()),
	OrderAmount	smallmoney	NOT NULL	DEFAULT (0),

	CONSTRAINT pk_HistoryOrders_Id PRIMARY KEY CLUSTERED (Id)
);
GO

/*
	Now we fill both tables with redgate data monitor with sample data
	USE DEMODATA 0020.SQLGEN!
*/

-- Testquery 1:	All orders in 2014
SET STATISTICS IO ON;
GO

SELECT	*
FROM	dbo.ActualOrders AS A
WHERE	A.OrderDate >= '20130101' AND
		A.OrderDate < '20140101'
GO

-- Testquery 2: All orders from all affected tables
SELECT	*
FROM	dbo.ActualOrders AS A
WHERE	A.OrderDate >= '20130101' AND
		A.OrderDate < '20140101'

UNION ALL

SELECT	*
FROM	dbo.HistoryOrders AS H
WHERE	H.OrderDate >= '20130101' AND
		H.OrderDate < '20140101'
GO

-- Because of heavy use of above construct the developer creates a INLINE-Function
IF OBJECT_ID('dbo.Num_Of_Orders', 'IF') IS NOT NULL
	DROP FUNCTION dbo.Num_Of_Orders;
	GO

CREATE FUNCTION dbo.Num_Of_Orders
(
	@StartDate	datetime,
	@EndDate	datetime
) RETURNS TABLE
AS
RETURN
(
	SELECT	*
	FROM	dbo.ActualOrders AS A
	WHERE	A.OrderDate >= @StartDate AND
			A.OrderDate < @EndDate + 1

	UNION ALL

	SELECT	*
	FROM	dbo.HistoryOrders AS H
	WHERE	H.OrderDate >= @StartDate AND
			H.OrderDate < @EndDate + 1
)
GO

-- After the function has been created it will be used by the application
SET STATISTICS IO ON;
GO

SELECT * FROM dbo.Num_Of_Orders('20130101', '20131231') 
GO

SELECT * FROM dbo.Num_Of_Orders('20130101', '20131231')
OPTION (QUERYTRACEON 9130);
GO

SET STATISTICS IO OFF;
GO

-- CAN an index on OrderDate solve the issue?
CREATE INDEX ix_ActualOrders_OrderDate ON dbo.ActualOrders (OrderDate)
INCLUDE (Customer, OrderAmount);

CREATE INDEX ix_HistoryOrders_OrderDate ON dbo.HistoryOrders (OrderDate)
INCLUDE (Customer, OrderAmount);
GO

-- NO!
SET STATISTICS IO ON;
SELECT * FROM dbo.Num_Of_Orders('20120101', '20121231');
SELECT * FROM dbo.Num_Of_Orders('20130101', '20131231');
SELECT * FROM dbo.Num_Of_Orders('20120101', '20131231');
SET STATISTICS IO OFF;
GO

/*
	Solution:	Usage of CONSTRAINTS to inform the query parser about the
				possible values in an index
*/
ALTER TABLE dbo.ActualOrders ADD CONSTRAINT CHK_MIN_ORDERDATE
CHECK (OrderDate >= '20130101');
ALTER TABLE dbo.HistoryOrders ADD CONSTRAINT CHK_MAX_ORDERDATE
CHECK (OrderDate < '20130101');
GO

-- After the function has been created it will be used by the application
SET STATISTICS IO ON;
SELECT * FROM dbo.Num_Of_Orders('20130101', '20131231');
SET STATISTICS IO OFF;
GO

/*
	Workflow for partition switch!
*/

-- Drop contraints CHK_MAX_ORDERDATE FROM dbo.HistoryOrders
ALTER TABLE dbo.HistoryOrders DROP CONSTRAINT CHK_MAX_ORDERDATE;
GO

-- Move all data from 2013 into the history table
BEGIN TRANSACTION
	-- Transfer data from ActualOrders to HistoryOrders
	INSERT INTO dbo.HistoryOrders
	SELECT * FROM dbo.ActualOrders
	WHERE	OrderDate < '20140101';

	-- Remove data from ActualOrders
	DELETE	dbo.ActualOrders
	WHERE	OrderDate < '20140101';
COMMIT TRANSACTION
GO

-- Add the constraint CHK_MAX_ORDERDATE again to dbo.HistoryOrders
ALTER TABLE dbo.HistoryOrders ADD CONSTRAINT CHK_MAX_ORDERDATE
CHECK (OrderDate < '20140101');
GO

-- Rebuild the indexes for proper statistics
CREATE INDEX ix_ActualOrders_OrderDate ON dbo.ActualOrders (OrderDate) INCLUDE (Customer, OrderAmount) WITH DROP_EXISTING;
CREATE INDEX ix_HistoryOrders_OrderDate ON dbo.HistoryOrders (OrderDate) INCLUDE (Customer, OrderAmount) WITH DROP_EXISTING;
GO

-- Is all working fine now?
SET STATISTICS IO ON;
GO

SELECT * FROM dbo.Num_Of_Orders('20130101', '20131231');
GO

SET STATISTICS IO OFF;
GO

-- NO, not solved because the check constraint for ActualOrders need to be changed, too!
ALTER TABLE dbo.ActualOrders DROP CONSTRAINT CHK_MIN_ORDERDATE
ALTER TABLE dbo.ActualOrders ADD CONSTRAINT CHK_MIN_ORDERDATE
CHECK (OrderDate >= '20140101');
GO

-- Is all working fine now?
SET STATISTICS IO ON;
SELECT * FROM dbo.Num_Of_Orders('20140101', '20141231');
SET STATISTICS IO OFF;
GO
-- YES!!!!

-- Cleaning the kitchen
DROP TABLE dbo.HistoryOrders;
DROP TABLE dbo.ActualOrders;
GO
