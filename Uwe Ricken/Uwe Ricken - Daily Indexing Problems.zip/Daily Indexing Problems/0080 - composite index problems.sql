/*============================================================================
	File:		0080 - composite index problems.sql

	Summary:	This script creates a table with composite index on a date
				attribute in conjunction with a customer_id attribite.
				
				The problem will occure if an INDEX RANGE SCAN will be processed!
				http://db-berater.blogspot.de/2014/12/kombinierte-indexe-richtig-definieren.html

	WebLink:	none

	Date:		Dezember 2014

	SQL Server Version: 2012 / 2014
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
SET NOCOUNT ON;
SET LANGUAGE us_english;
USE demo_db;
GO

IF OBJECT_ID('dbo.Orders', 'U') IS NOT NULL
	DROP TABLE dbo.Orders;
	GO

CREATE TABLE dbo.Orders
(
	Id			INT		NOT NULL	IDENTITY (1, 1),
	OrderNo		CHAR(5)	NOT NULL,
	Customer_Id	INT		NOT NULL,
	OrderDate	DATE	NOT NULL,

	CONSTRAINT pk_Orders_ID PRIMARY KEY CLUSTERED (Id)
);
GO

/*
	Now we fill both tables with redgate data monitor with sample data
	use Demodata 0070.sqlgen!
*/

-- Now a composite index will be created for a better search for date and customer_id
CREATE UNIQUE INDEX ix_Orders_OrderNo ON dbo.Orders (OrderNo);
CREATE INDEX ix_Orders_OrderDate ON dbo.Orders
(
	OrderDate,
	Customer_Id
);
GO

-- is that a good index?
SET STATISTICS IO ON;

SELECT	Id, Customer_Id, OrderDate
FROM	dbo.Orders
WHERE	OrderDate BETWEEN '20140101' AND '20140131';

SELECT Id, Customer_Id, OrderDate
FROM	dbo.Orders
WHERE	OrderDate BETWEEN '20140101' AND '20140131' AND
		Customer_Id = CAST(5 AS INT);
GO

-- let's make the information visible which is behind the scene
SELECT	Id, Customer_Id, OrderDate
FROM	dbo.Orders
WHERE	OrderDate BETWEEN '20140101' AND '20140131' AND
		Customer_Id = CAST(5 AS INT)
OPTION	(QUERYTRACEON 9130);


-- Show the execution details
SET STATISTICS PROFILE ON;
SET STATISTICS TIME ON;

GO

SELECT Id, Customer_Id, OrderDate
FROM	dbo.Orders
WHERE	OrderDate BETWEEN '20140101' AND '20140131' AND
		Customer_Id = CAST(5 AS INT)
OPTION	(QUERYTRACEON 9130);

SET STATISTICS PROFILE OFF;
GO

DBCC SHOW_STATISTICS('dbo.Orders', 'ix_Orders_OrderDate')
WITH HISTOGRAM;
GO

SELECT * FROM dbo.Orders WHERE OrderDate = '20140106'

-- What is the index id
SELECT * FROM sys.indexes 
WHERE	object_id = OBJECT_ID('dbo.Orders','U');

-- Show the index structure of the index ix_Orders_OrderDate
SELECT	page_type_desc,
		page_level,
		allocated_page_page_id,
		previous_page_page_id,
		next_page_page_id
FROM	sys.dm_db_database_page_allocations
(
	DB_ID(),
	OBJECT_ID('dbo.Orders', 'U'),
	3,
	NULL,
	'DETAILED'
) AS DDDPA
WHERE	is_allocated = 1
ORDER BY
	page_type DESC,
	page_level DESC,
	previous_page_page_id ASC;
GO

-- What data are in the root node?
DBCC TRACEON (3604);
DBCC PAGE ('demo_db', 1, 912, 3);

-- What data are in the leaf node(s)?
DBCC PAGE ('demo_db', 1, 880, 3);
GO

-- what will happen if the composite index will be "changed"
CREATE INDEX ix_Orders_OrderDate ON dbo.Orders
(Customer_Id, OrderDate) WITH DROP_EXISTING;
GO

-- and this combination?
SET STATISTICS IO ON;
GO

SELECT Id, Customer_Id, OrderDate
FROM	dbo.Orders
WHERE	OrderDate BETWEEN '20140101' AND '20140131' AND
		Customer_Id = CAST(5 AS INT);

-- let's make the information visible which is behind the scene
SELECT Id, Customer_Id, OrderDate
FROM	dbo.Orders
WHERE	OrderDate BETWEEN '20140101' AND '20140131' AND
		Customer_Id = CAST(5 AS INT)
OPTION	(QUERYTRACEON 9130);

SET STATISTICS IO OFF
GO

-- Show the index structure of the index ix_Orders_OrderDate
SELECT	page_type_desc,
		page_level,
		allocated_page_page_id,
		previous_page_page_id,
		next_page_page_id
FROM	sys.dm_db_database_page_allocations
(
	DB_ID(),
	OBJECT_ID('dbo.Orders', 'U'),
	3,
	NULL,
	'DETAILED'
) AS DDDPA
WHERE	is_allocated = 1
ORDER BY
	page_type DESC,
	page_level DESC,
	previous_page_page_id ASC;
GO

-- What data are in the root node?
DBCC TRACEON (3604);
DBCC PAGE ('demo_db', 1, 1176, 3);

DBCC PAGE ('demo_db', 1, 1144, 3);
GO


-- Clean the kitchen
DROP TABLE dbo.Orders;
GO
