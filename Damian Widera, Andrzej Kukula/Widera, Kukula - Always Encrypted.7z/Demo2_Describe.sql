exec sp_describe_parameter_encryption 
     N'INSERT INTO dbo.AETest (SSN, CustName, Age) VALUES (@SSN, @CustName, @Age)',
     N'@SSN varchar(11), @CustName nvarchar(60), @Age int'
