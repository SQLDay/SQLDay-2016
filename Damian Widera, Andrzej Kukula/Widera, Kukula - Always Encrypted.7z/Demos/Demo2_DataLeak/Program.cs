﻿using System;
using System.Data.SqlClient;
using System.Data;

namespace Demo2_DataLeak
{
    class Program
    {
        static void Main(string[] args)
        {
            // Set as StartUp Project to run
            var connString = @"Data Source=vwin2016\vsql2016;Integrated Security=SSPI;"
                    + "Initial Catalog=Test;Column Encryption Setting=enabled";
            using (var connection = new SqlConnection(connString))
            using (var command = connection.CreateCommand())
            {
                connection.Open();
                // programming bug: the query has changed (insert has just one column)
                // but all parameters remained. Observe the profiler
            //  command.CommandText = "INSERT INTO dbo.AETest (CustName, SSN, Age) VALUES (@CustName, @SSN, @Age)";
                command.CommandText = "INSERT INTO dbo.AETest (Age) VALUES (@Age)";
                command.Parameters.Add("@SSN", SqlDbType.VarChar, 11).Value = "123456";
                command.Parameters.AddWithValue("@CustName", "Customer1");
                command.Parameters.AddWithValue("@Age", 30);
                command.ExecuteNonQuery();
                command.ExecuteNonQuery();
                command.ExecuteNonQuery();
            }

            Console.WriteLine("Finished.");
            Console.ReadLine();
        }
    }
}
