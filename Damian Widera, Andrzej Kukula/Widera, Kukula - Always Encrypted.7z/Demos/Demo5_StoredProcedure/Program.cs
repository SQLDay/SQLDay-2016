﻿using System;
using System.Data.SqlClient;
using System.Data;

namespace Demo5_StoredProcedure
{
    class Program
    {
        static void Main(string[] args)
        {
            // Set as StartUp Project to run
            var connString = @"Data Source=vwin2016\vsql2016;Integrated Security=SSPI;"
                    + "Initial Catalog=Test;Column Encryption Setting=enabled";
            using (var connection = new SqlConnection(connString))
            using (var command = connection.CreateCommand())
            {
                connection.Open();
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = "dbo.InsertData";
                command.Parameters.Add("@SSN", SqlDbType.VarChar, 11).Value = "123456";
                command.Parameters.AddWithValue("@CustName", "Customer1");
                command.Parameters.AddWithValue("@Age", 31);
                command.ExecuteNonQuery();
            }

            Console.WriteLine("Finished.");
            Console.ReadLine();
        }
    }
}
