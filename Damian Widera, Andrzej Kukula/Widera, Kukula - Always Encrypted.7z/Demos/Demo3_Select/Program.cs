﻿using System;
using System.Data.SqlClient;
using System.Data;

namespace Demo3_Select
{
    class Program
    {
        static void Main(string[] args)
        {
            // Set as StartUp Project to run
            var connString = @"Data Source=vwin2016\vsql2016;Integrated Security=SSPI;"
                    + "Initial Catalog=Test;Column Encryption Setting=enabled";
            using (var connection = new SqlConnection(connString))
            using (var command = connection.CreateCommand())
            {
                connection.Open();
                // deterministic encryption in action
                command.CommandText = "SELECT CustName FROM dbo.AETest WHERE SSN=@SSN";
                command.Parameters.Add("@SSN", SqlDbType.VarChar, 11).Value = "123456";
                var custName = (string)command.ExecuteScalar();
                Console.WriteLine("CustName = {0}", custName);
            }

            Console.WriteLine("Finished.");
            Console.ReadLine();
        }
    }
}
