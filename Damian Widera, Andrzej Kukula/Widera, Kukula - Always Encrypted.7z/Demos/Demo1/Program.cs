﻿using System;
using System.Data.SqlClient;
using System.Data;

namespace Demo1
{
    class Program
    {
        static void Main(string[] args)
        {
            // Set as StartUp Project to run
            var connString = @"Data Source=vwin2016\vsql2016;Integrated Security=SSPI;"
                    + "Initial Catalog=Test;Column Encryption Setting=enabled";
            using (var connection = new SqlConnection(connString))
            using (var command = connection.CreateCommand())
            {
                connection.Open();
                // simple insert: no changes to non-encrypted code
                command.CommandText = "INSERT INTO dbo.AETest (SSN, CustName, Age) VALUES (@SSN, @CustName, @Age)";
                command.Parameters.Add("@SSN", SqlDbType.VarChar, 11).Value = "123456";
                command.Parameters.AddWithValue("@CustName", "Customer1");
                command.Parameters.AddWithValue("@Age", 30);
                command.ExecuteNonQuery();
                command.ExecuteNonQuery();
                command.ExecuteNonQuery();
            }

            Console.WriteLine("Finished.");
            Console.ReadLine();
        }
    }
}
