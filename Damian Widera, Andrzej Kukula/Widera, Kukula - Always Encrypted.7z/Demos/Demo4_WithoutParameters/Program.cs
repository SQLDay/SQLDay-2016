﻿using System;
using System.Data.SqlClient;
using System.Data;

namespace Demo4_WithoutParameters
{
    class Program
    {
        static void Main(string[] args)
        {
            // Set as StartUp Project to run
            var connString = @"Data Source=vwin2016\vsql2016;Integrated Security=SSPI;"
                    + "Initial Catalog=Test;Column Encryption Setting=enabled";
            using (var connection = new SqlConnection(connString))
            using (var command = connection.CreateCommand())
            {
                connection.Open();
                // this will not work
                command.CommandText = "SELECT CustName FROM dbo.AETest WHERE SSN='123456'";
                var custName = (string)command.ExecuteScalar();
                Console.WriteLine("CustName = {0}", custName);
            }

            Console.WriteLine("Finished.");
            Console.ReadLine();
        }
    }
}
