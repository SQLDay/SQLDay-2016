SELECT 
 ek.name AS column_encryption_key_name
 , ev.encrypted_value
 , ev.encryption_algorithm_name
 , mk.name as column_master_key_name
 , mk.key_store_provider_name AS column_master_key_store_provider_name
 , mk.key_path AS column_master_key_path 
 FROM sys.column_encryption_keys ek JOIN sys.column_encryption_key_values ev 
 ON (ek.column_encryption_key_id = ev.column_encryption_key_id) 
 JOIN sys.column_master_keys mk ON (ev.column_master_key_id = mk.column_master_key_id)



 SELECT 
 t.name AS table_name
 , c.name AS column_name 
 , c.encryption_type_desc 
 , c.encryption_algorithm_name 
 , k.name AS column_encryption_key_name 
 FROM sys.columns c JOIN sys.column_encryption_keys k 
 ON(c.column_encryption_key_id = k.column_encryption_key_id) 
 JOIN sys.tables t ON (c.object_id = t.object_id)  