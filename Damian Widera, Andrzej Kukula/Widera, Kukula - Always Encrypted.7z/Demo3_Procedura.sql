ALTER PROCEDURE dbo.InsertData
    @SSN varchar(11), @CustName nvarchar(60), @Age int
AS
	DECLARE @LocalSSN varchar(11);
	DECLARE @LocalCustName nvarchar(60);
	DECLARE @LocalAge int;

	SET @LocalSSN = @SSN;
	SELECT @LocalCustName = @CustName, @LocalAge = @Age;

	INSERT INTO dbo.AETest (SSN, CustName, Age)
	VALUES (@LocalSSN, @LocalCustName, @LocalAge);

