﻿###############################################################################
# this is a comment (so Bashy!)

###############################################################################
# Enable execution of scripts (run as admin)
Set-ExecutionPolicy RemoteSigned      # sane policy, there are more options

###############################################################################
# commands (cmdlets) are named Verb-Noun
# remember to use F8 to run selection
Write-Output "Hello world"
echo "Hello world"

Get-Process
ps

Get-Service

Get-ChildItem
#dir, ls, gci

Get-Content Demo1.ps1
#type Demo1.ps1
#cat Demo1.ps1
#gc Demo1.ps1

Get-Location
pwd

Copy-Item
#copy, cp, cpi

Move-Item
#move, mv

Remove-Item
#del, rm

# "dry" run
Remove-Item -WhatIf Demo1.ps1

# confirmation mode
New-Item file1.txt
Remove-Item -Confirm file1.txt

Get-Process | Get-Member
ps | gm
dir | gm


###############################################################################
# Variables, objects, properties, methods and expressions

$a = 1
$b = 2
Write-Output "The value of $a+$b is $($a+$b)"               # string interpolation
Write-Output ("The value of $a+$b is {0:000}" -f ($a+$b))   # .NET-like formatting

$fileName = 'Demo1.ps1'
$content = Get-Content $fileName
$content | Get-Member
$content[1..3]

$dateToday = Get-Date
$dateTomorrow = $dateToday.AddDays(1)
$dateTomorrow.Day
$dateTomorrow.ToString("yyyy|MM|dd")

$dateToday.DayOfWeek
$dateToday.DayOfWeek -eq 0  # is it Sunday? If so then launch some maintenance tasks...

(Get-Item C:\Windows).LastWriteTime.DayOfWeek

"Hello","world" -join " "

"Hello world" -split " "

###############################################################################

[ValidateRange(1,10)] $x = 1
$x
$x = 11

foreach ($a in 1..10) { echo "$a" }

$sql = Get-Process 'sqlservr'
$sql.WorkingSet
$sql.WorkingSet/1024/1024

# there will be more than one svchost process
$svchosts = Get-Process 'svchost'
$svchosts

# let's calculate total memory consumption
$svchosts | Measure-Object -Sum WorkingSet

# human readable value
$memoryMB = ($svchosts | Measure-Object -Sum WorkingSet).Sum/1024/1024
$memoryMB
[Math]::Round($memoryMB,1)
[Math]|gm -Static

# redirections
echo "Hello world" > C:\Temp\Hello.txt


###############################################################################
# Wildcards and regular expressions

# grep cmdlet
Select-String 'Get-(\S+)' Demo1.ps1 -quiet

$data = "123_456"
$data -like "*_*"
$data -split "_"
$data -replace "_", "|"

# match and capture data using regex
$data -match "(\d+)_(\d+)"
$Matches  # <-- automatically populated by -match
# also -notmatch -imatch -cmatch, ...

###############################################################################
# Iterative scripting

$proc = Get-Process -Name svchost

foreach ($p in $proc) {
    echo $p.Id
}

###############################################################################
# Pipeline scripting

Get-Process -Name svchost | Where-Object { $_.id -lt 1000 } | Format-Table Name, Id, WorkingSet

ps svchost | ? { $_.Id -lt 1000 } | ft Name,Id,WS

# stop all processes with specified name
1..5 | foreach { notepad }
Get-Process notepad | Stop-Process   # no need to use 'foreach'
# try again and observe the error
Get-Process notepad | Stop-Process
# the error can be muted
Get-Process -ErrorAction SilentlyContinue notepad | Stop-Process

# find out only folders from %WINDIR% that were modified during last week
dir $env:windir | ? { $_.LastWriteTime -gt (Get-Date).AddDays(-14) } `
    | ? { $_.PSIsContainer } `
    | sort LastWriteTime -Descending

# similar filter, output to grid, see filtering and sorting
dir $env:windir | ? { $_.LastWriteTime -gt (Get-Date).AddDays(-14) } `
    | sort LastWriteTime -Descending `
    | Out-GridView

# how to display values of all possible properties
Get-Process | Select-Object -Property * | ogv

# simplified loop
1..10 | % { echo $_ }

###############################################################################
# Functions

function add($x, $y) {
    $x+$y
}

add 1 2

# expressions are also allowed
add (Get-Date).Second $(1+2)

###############################################################################
# Data access

$sqlConnection = New-Object System.Data.SqlClient.SqlConnection
$sqlConnection.ConnectionString = 'Data Source=.\SQL2016;Integrated Security=SSPI;Initial Catalog=master'
$sqlConnection.Open()

# get a single value
$cmd = $sqlConnection.CreateCommand()
$cmd.CommandText = "SELECT @@VERSION"
$version = $cmd.ExecuteScalar()
$version

# execute a command which is not a query (i.e. an INSERT, UPDATE, DELETE - unless used with OUTPUT clause;
# DDL, DCL, session commands)
$cmd = $sqlConnection.CreateCommand()
$cmd.CommandText = "SET NOCOUNT ON";
$cmd.ExecuteNonQuery()

# get whole table of data
$cmd = $sqlConnection.CreateCommand()
$cmd.CommandText = "SELECT database_id, name, compatibility_level FROM sys.databases WHERE compatibility_level < 130"
$dataReader = $cmd.ExecuteReader()
$dataTable = New-Object System.Data.DataTable
$dataTable.Load($dataReader)
$dataTable

###############################################################################
# REST API access, JSON conversion
$soInfo = Invoke-RestMethod 'https://api.stackexchange.com/2.2/info?site=stackoverflow' -Method Get
echo "Questions per minute rate is now: $($soInfo.items.questions_per_minute)"

# export anything easily to CSV
Get-Process svchost | Export-Csv C:\temp\export-csv.txt -Delimiter '|'

# read CSV easily back and process it further
Import-Csv C:\temp\export-csv.txt -Delimiter '|' | ogv

# (we could create useful interfaces between different enterprise systems using PowerShell)
# there are FTP, SFTP libraries available, REST, CSV, JSON, XML and more

###############################################################################
# Background jobs
Start-Job { dir C:\Windows\System32\DriverStore -Recurse > C:\temp\listing.txt }
Get-Job
Get-Job | Wait-Job
Get-Job | Remove-Job

###############################################################################
# Remoting

<#
If you have no AD domain, prepare your server like this:
1. Obtain and install X509 certificate
2. winrm quickconfig
3. winrm quickconfig -transport:https @{CertificateThumbprint="4a3130edcf2f37ef2e4eb4e579127beee721a0a2"}
4. Enable-PSRemoting
5. Set-Item WSMan:\localhost\Client\TrustedHosts *
#>

$credential = Get-Credential
$sessionOption = New-PSSessionOption -SkipCACheck -SkipCNCheck -SkipRevocationCheck
$session = New-PSSession -computer VWIN2016 -credential $credential -UseSSL -SessionOption $sessionOption

Enter-PSSession $session
$env:COMPUTERNAME
Exit-PSSession
$env:COMPUTERNAME
Remove-PSSession $session

###############################################################################
# Builtin help

# help on help
Get-Help

# help on cmdlet
Get-Help Remove-Item

# search help
Get-Help About_

# help on a topic
Get-Help About_Operators

###############################################################################
# Miscellaneous

# ping
Test-Connection 8.8.8.8

# read Windows Event log (can read remote computers as well)
Get-EventLog Application -Newest 100 -Source 'mssql$sql2016'

# check if a file/folder exists
Test-Path c:\Windows -NewerThan (get-date).AddDays(-1)

# time command (get total running time)
Measure-Command { dir C:\Windows\System32\DriverStore -Recurse > C:\temp\listing.txt }

# introduce some delay in the script
Start-Sleep -Seconds 2

# start program as admin
Start-Process PowerShell -Verb RunAs

# now check if we're in admin console (pure .NET stuff)
([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(`
    [Security.Principal.WindowsBuiltInRole]::Administrator)

# interact with WMI engine - get disk free space (can be remote)
Get-WmiObject Win32_Volume | ft Name,Capacity,FreeSpace,
    @{Label="Percent Free";Expression={[int]($_.FreeSpace/$_.Capacity*100)}}

# check partition sizes and alignment for SQL Server
Get-WmiObject Win32_DiskPartition | ft DeviceId,
        @{Label="Aligned?";Expression={$_.StartingOffset/4096.0 -eq [int]($_.StartingOffset/4096)}},
        @{Label="StartingOffsetKB";Expression={$_.StartingOffset/1024.0}},
        @{Label="SizeMB";Expression={[int]($_.Size/1024/1024)}}

# get physical memory data
gwmi Win32_PhysicalMemory | ft BankLabel, Manufacturer, PartNumber,
    @{Label="Capacity GB";Expression={$_.Capacity/1024/1024/1024}}

# get operating system info
gwmi Win32_OperatingSystem | select Version,WindowsDirectory,InstallDate,LastBootUpTime,FreePhysicalMemory | fl

# get printer info
gwmi Win32_Printer | ft Caption,CapabilityDescriptions

# are we virtualized?
gwmi Win32_ComputerSystem | ft HypervisorPresent

# ... and a lot more

# reboot many machines at once
Restart-Computer -ComputerName (Get-Content c:\temp\computers_to_reboot)

# add computer to a domain
Add-Computer -DomainName domain.local -ComputerName computername ...

# test secure channel between this computer and domain controller
Test-ComputerSecureChannel -Repair

1..10 | % { New-Item c:\temp\zip\$_.aaa -Force }

# create a ZIP archive using .NET (PowerShell older than 5)
Add-Type -As System.IO.Compression.FileSystem 
[System.IO.Compression.ZipFile]::CreateFromDirectory( ('C:\temp\zip'), "c:\temp\temp.zip", "Optimal", $true )

# create a ZIP archive (PowerShell 5+)
Compress-Archive -Path C:\temp\zip -DestinationPath C:\temp\temp.zip -CompressionLevel Optimal
