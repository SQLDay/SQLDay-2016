/*
	Facet
	Pokazac je w SSMS
	Database Options

*/


/*
	Condition
	Utworzyc  COndition na Trustworthy

*/


/*
	Policy
	Zaimportowa� systemowe

	powiedzic o target
	restriction
	Evaluation modes - utworzyc jako scheduled
	
	Category!!!
*/

/*
	CMS - Centralized Management Server

	Zarejestrowa� dla serwer�w 2008, 2012, 2014, 2016 i Linuxa
	Pu�cic query o sprawdzeniu tryustworthy
	Pu�cic ewaluacj� polityki z trustworthy
 
*/


/*
	Error Handling
	- find information in the Windows Application Log
	- find information in the SQL Server Error Log
	
	Codes:
	34050 - on change prevent (auto)
	34051 - on change prevent (manual)
	34052 - on schedule
	34053 - on change log only

*/

/*
	Monitoring
	- Database Mail
	- Alert
	- Operator
*/


/*
	Execute Scripts

	ExecuteSQL
	ExecuteWQL
*/

/*
	PowerShell
*/