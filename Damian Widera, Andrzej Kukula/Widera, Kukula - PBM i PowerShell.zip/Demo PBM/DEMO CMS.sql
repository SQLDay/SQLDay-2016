SELECT @@VERSION, name, is_trustworthy_on 
FROM sys.databases WHERE name = 'BadDBTrustworthy'

