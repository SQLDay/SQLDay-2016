﻿sqlps

Set-Location SQLSERVER:\SQLPolicy\AK10\SQL2016\Policies
Get-ChildItem | Where-Object {$_.Name -eq "Log file stall < 10 ms"} | Invoke-PolicyEvaluation -TargetServer "AK10\SQL2016"


# Run a Category of policies
Set-Location SQLSERVER:\SQLPolicy\AK10\SQL2016\Policies
Get-ChildItem | Where-Object {$_.PolicyCategory -eq "DB"} | Invoke-PolicyEvaluation -TargetServer "AK10\SQL2008R2"


