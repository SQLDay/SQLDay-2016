SELECT * FROM sys.dm_io_virtual_file_stats(DB_ID(),NULL)



SELECT io_stall_write_ms FROM sys.dm_io_virtual_file_stats(DB_ID(),2)

ExecuteSql('Numeric','SELECT io_stall_write_ms FROM sys.dm_io_virtual_file_stats(DB_ID(),2)')