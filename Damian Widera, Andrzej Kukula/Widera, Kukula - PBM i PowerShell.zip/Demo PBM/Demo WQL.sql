get-wmiobject win32_service -filter 'name="SQLAGENT$SQL2016"' | SELECT Name, State


SELECT State FROM win32_service WHERE name = 'SQLAGENT$SQL2016'


ExecuteWql('string', 'root\CIMV2', 'SELECT State FROM win32_service WHERE name = "SQLAGENT$SQL2016"')

--SELECT * FROM sys.dm_server_services
