/*
	Facet

	- describes SQL Server objects and their properties
	- cannot be changed
	- cannot be modified or added
	- only 1 facet per policy (makes sense)
*/


/*
	Condition

	- describes the rule to check, audit or enforce
	- always describe the desired state
	- only one condition per policy
	- uses one facet
	- but can have many expression on the facet's attributes
	- Target & Restriction are also Conditions
	- one condition can be used in many policies

*/

/*
	Evaluation modes

	- on demand - manual
	- on schedule - uses SQL Server Agent Job
	- on change: log only - just logging when the policy is broken
	- on change: prevent - preventing the policy to be broken
*/

/*
	Policy
	- create it by yourself (SSMS, PowerShell, T-SQL)
	- Import Best Practices Policies given by Microsoft

*/

/*
	CMS - Centralized Management Server
	- all editions - even Express
	- run scripts
	- evaluate policies

	
exec sp_cycle_errorlog

*/


/*
	Error Handling
	- find information in the Windows Application Log
	- find information in the SQL Server Error Log
	
	Codes:
	34050 - on change prevent (auto)
	34051 - on change prevent (manual)
	34052 - on schedule
	34053 - on change log only

*/

/*
	Monitoring
	- Database Mail
	- Alert
	- Operator
*/


/*
	Execute Scripts

	ExecuteSQL
	ExecuteWQL
*/

/*
	PowerShell
*/