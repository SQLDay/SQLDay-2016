--:connect 

IF NOT EXISTS  (SELECT * FROM sys.databases 
			WHERE name = N'BadDBTrustworthy')
BEGIN
	CREATE DATABASE BadDBTrustworthy
END
GO
USE master
GO
ALTER DATABASE BadDBTrustworthy
SET TRUSTWORTHY ON



