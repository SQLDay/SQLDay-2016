-- subqueries in COALESCE
USE AdventureWorks;
SET NOCOUNT ON;
DBCC FREEPROCCACHE WITH NO_INFOMSGS;
GO

SELECT COALESCE((SELECT MAX(TotalDue) FROM Sales.SalesOrderHeader),0);

SELECT ISNULL((SELECT MAX(TotalDue) FROM Sales.SalesOrderHeader),0);