-- abusing dates demo

-- what happens when you try to find the "end" of a period?

DECLARE @start DATETIME, @end DATETIME;

SELECT 
  @start = DATEADD(DAY, -1, CONVERT(DATE, SYSDATETIME())),
  @end   = DATEADD(MILLISECOND, -3, DATEADD(DAY, 1, @start));

SELECT @start, [DT]  = @end;

SELECT @start, [SDT] 
  = CONVERT(SMALLDATETIME, @end); -- rounds up

SELECT @start, [D]   
  = CONVERT(DATE, @end);          -- rounds down

SELECT @start, [DT2] 
  = CONVERT(DATETIME2(7), @end);  -- could miss data


-- Always use open-ended range.
-- Instead of:

SELECT ... WHERE col BETWEEN @start AND @end;

-- Use:

SELECT ... WHERE col >= @start AND col < DATEADD(DAY, 1, @end);


GO

-- NEVER use shorthand
-- POP QUIZ: what will this yield?

DECLARE @d DATETIME = '20160517';  -- Tuesday, May 17, 2016

SELECT 
  [DATEPART(w)] = DATEPART(w, @d),-- (a) 21   (b) 3     (c) 20
  [DATEPART(y)] = DATEPART(y, @d);-- (a) 16   (b) 2016  (c) 138







-- spoiler below









-- Abbreviations are time-savers and productivity boosters
-- But some of them can be misleading!
-- w = WEEKDAY, not week; y = DAYOFYEAR, not YEAR!
GO
DECLARE @d DATETIME = '20160517';

SELECT 
  [weekday]   = DATEPART(WEEKDAY, @d),   -- w! w is not week
  [week]      = DATEPART(WEEK, @d), 
  [iso_week]  = DATEPART(ISO_WEEK, @d), 
  [dayofyear] = DATEPART(DAYOFYEAR, @d), -- y! y is not year
  [year]      = DATEPART(YEAR, @d); 
  


          






-- this works ok:
DECLARE @dt DATETIME = GETDATE();
SELECT @dt + 1;
GO

-- this breaks:
DECLARE @d DATE = GETDATE();
SELECT @d + 1;
GO

-- always use explicit DATEADD


-- date formats. Try the below queries after changing these settings around.
SET LANGUAGE FRENCH;
SET LANGUAGE ENGLISH;
SET LANGUAGE BRITISH;
SET DATEFORMAT YDM;
SET DATEFORMAT MDY;

-- unsafe:

SELECT CONVERT(DATETIME, '2012.09.08');
SELECT CONVERT(DATETIME, '09/08/2012');
SELECT CONVERT(DATETIME, '2012-09-08 12:34:56.789');

-- safe:

SELECT CONVERT(DATETIME, '20120908');
SELECT CONVERT(DATETIME, '2012-09-08T12:34:56.789');

-- always safe but only for DATE data type:

SELECT CONVERT(DATE, '2012-09-08');
SELECT CONVERT(DATE, '20120908');

