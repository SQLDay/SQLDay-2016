-- specify length/precision demo

-- POP QUIZ : what will these yield?
 
DECLARE @x VARCHAR = 'aaron';

     SELECT 
      [variable] = @x,
      [concat]   = CONCAT(@x, 'bertrand'),
      [cast]     = CAST('aaron' AS VARCHAR),
      [convert]  = CONVERT(VARCHAR, 'aaron');



-- spoiler below







GO
-- in some cases VARCHAR is 1 (like DECLARE), others 30 (like CAST).
DECLARE @x VARCHAR(64) = 'aaron';

     SELECT 
      [variable] = @x,
      [concat]   = CONCAT(@x, 'bertrand'),
      [cast]     = CAST('aaron' AS VARCHAR(64)),
      [convert]  = CONVERT(VARCHAR(64), 'aaron');


-- some violations get silent truncation, others error

-- silent truncation
GO
CREATE PROCEDURE dbo.foo
  @b VARCHAR,
  @r VARCHAR(5)
AS
BEGIN
  SET NOCOUNT ON;
  PRINT @b;
  PRINT @r;
END
GO
EXEC dbo.foo @b = 'Greater than thirty characters', 
             @r = 'Greater than five characters';
GO
-- you've lost data BUT there is no error
-- and it is not logged anywhere
DROP PROCEDURE dbo.foo;
GO


-- truncation yielding an error
DECLARE @t TABLE(x VARCHAR);
INSERT @t(x) SELECT 'NYC';