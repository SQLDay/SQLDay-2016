USE master;

IF EXISTS (SELECT * FROM sys.databases WHERE name = 'ServiceBrokerLearning')
BEGIN
	ALTER DATABASE [ServiceBrokerLearning] SET  SINGLE_USER WITH ROLLBACK IMMEDIATE
	DROP DATABASE ServiceBrokerLearning;
END
GO



CREATE DATABASE ServiceBrokerLearning
GO

ALTER DATABASE ServiceBrokerLearning
SET ENABLE_BROKER WITH ROLLBACK IMMEDIATE;


SELECT name, service_broker_guid, is_broker_enabled
FROM sys.databases WHERE name = 'ServiceBrokerLearning'


USE ServiceBrokerLearning
GO

/*
  MESSAGE TYPE
  A message type defines the name of a message 
  and the validation that Service Broker performs 

  URL-like format (not obligatory) to uniquely identify a message type
  
  DROP MESSAGE TYPE [//PLSSUG/SQLSB/MyMsg]
 -- DROP MESSAGE TYPE IF EXISTS [//PLSSUG/SQLSB/MyMsg] doesn't work :(
*/
CREATE MESSAGE TYPE [//PLSSUG/SQLSB/MyMsg]
VALIDATION = WELL_FORMED_XML
GO


SELECT * FROM sys.service_message_types 
GO


/*
  CONTRACT
  validate the types of messages that are sent in one or both directions
*/
CREATE CONTRACT [//PLSSUG/SQLSB/Contract]
(
	[//PLSSUG/SQLSB/MyMsg] SENT BY ANY
)
GO

-- alternate contract for 2 types of messages
CREATE MESSAGE TYPE [//PLSSUG/SQLSB/MyMsg2]
VALIDATION = WELL_FORMED_XML
GO

CREATE CONTRACT [//PLSSUG/SQLSB/Contract2]
(
	[//PLSSUG/SQLSB/MyMsg] SENT BY INITIATOR,
	[//PLSSUG/SQLSB/MyMsg2] SENT BY TARGET
)
GO


-- contract and message types
SELECT sc.name, cm.*, mt.*
FROM sys.service_contract_message_usages cm 
	INNER JOIN sys.service_message_types mt ON cm.message_type_id = mt.message_type_id
	INNER JOIN sys.service_contracts sc ON sc.service_contract_id = cm.service_contract_id
WHERE sc.name LIKE '//PLSSUG/SQLSB/Contract%'
GO

/*
  QUEUE
  a view over internal tables
  queues are the only SB objects that store data.
  You can specify schema and filegroup
*/
CREATE QUEUE SenderQueue
WITH STATUS = ON
GO

/*
  SERVICE
  messages are being sent to services

  DROP SERVICE [//PLSSUG/SQLSB/SenderService]
*/
CREATE SERVICE [//PLSSUG/SQLSB/SenderService]
ON QUEUE SenderQueue([//PLSSUG/SQLSB/Contract])
GO



CREATE QUEUE ReceiverQueue
WITH STATUS = ON
GO

-- DROP SERVICE [//PLSSUG/SQLSB/ReceiverService]
CREATE SERVICE [//PLSSUG/SQLSB/ReceiverService]
ON QUEUE ReceiverQueue([//PLSSUG/SQLSB/Contract])
GO

SELECT * FROM sys.service_queues
GO


-- services and contracts
SELECT
	sv.name AS 'Service',
	sc.name AS 'Contract',
	*
FROM sys.services sv
	INNER JOIN sys.service_contract_usages scu ON scu.service_id = sv.service_id
	INNER JOIN sys.service_contracts sc ON sc.service_contract_id = scu.service_contract_id
GO




