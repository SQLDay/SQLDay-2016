/*
USE master
GO
ALTER DATABASE [ServiceBrokerLearning] SET  SINGLE_USER WITH ROLLBACK IMMEDIATE
	DROP DATABASE ServiceBrokerLearning;
GO
*/

-- Setup
IF NOT EXISTS (SELECT * FROM sys.databases WHERE name = 'ServiceBrokerLearning')
  CREATE DATABASE ServiceBrokerLearning
GO

USE ServiceBrokerLearning
GO

IF NOT EXISTS(SELECT * FROM sys.service_message_types WHERE name = '//PLSSUG/SQLSB/MyMsg')
CREATE MESSAGE TYPE [//PLSSUG/SQLSB/MyMsg]
VALIDATION = WELL_FORMED_XML
GO

IF NOT EXISTS(SELECT * FROM sys.service_contracts WHERE name = '//PLSSUG/SQLSB/Contract')
CREATE CONTRACT [//PLSSUG/SQLSB/Contract]
(
	[//PLSSUG/SQLSB/MyMsg] SENT BY ANY
)
GO

IF NOT EXISTS(SELECT * FROM sys.service_queues WHERE name = 'SenderQueue')
CREATE QUEUE SenderQueue
WITH STATUS = ON
GO

IF NOT EXISTS(SELECT * FROM sys.services WHERE name = '//PLSSUG/SQLSB/SenderService')
CREATE SERVICE [//PLSSUG/SQLSB/SenderService]
ON QUEUE SenderQueue([//PLSSUG/SQLSB/Contract])
GO


IF NOT EXISTS(SELECT * FROM sys.service_queues WHERE name = 'ReceiverQueue')
CREATE QUEUE ReceiverQueue
WITH STATUS = ON
GO



IF NOT EXISTS(SELECT * FROM sys.services WHERE name = '//PLSSUG/SQLSB/ReceiverService')
CREATE SERVICE [//PLSSUG/SQLSB/ReceiverService]
ON QUEUE ReceiverQueue([//PLSSUG/SQLSB/Contract])
GO








-- ALTER DATABASE ServiceBrokerLearning SET NEW_BROKER

IF EXISTS(SELECT 1 FROM sys.databases WHERE name = 'ServiceBrokerLearning' AND is_broker_enabled = 0)
ALTER DATABASE ServiceBrokerLearning SET ENABLE_BROKER WITH ROLLBACK IMMEDIATE;


DECLARE @Ch AS UNIQUEIDENTIFIER;
DECLARE conv CURSOR FOR
SELECT conversation_handle FROM sys.conversation_endpoints -- WHERE state = 'ER';

OPEN conv;
FETCH NEXT FROM conv INTO @Ch;
WHILE @@FETCH_STATUS = 0
BEGIN
  END CONVERSATION @Ch WITH CLEANUP;
  FETCH NEXT FROM conv INTO @Ch;
END
CLOSE conv;
DEALLOCATE conv;





ALTER QUEUE SenderQueue WITH STATUS = ON

ALTER QUEUE ReceiverQueue WITH STATUS = ON
GO

SELECT * FROM SenderQueue
GO
SELECT * FROM ReceiverQueue
GO




SELECT name, activation_procedure, is_activation_enabled, is_receive_enabled, is_enqueue_enabled 
FROM sys.service_queues
WHERE is_receive_enabled=0 OR is_enqueue_enabled=0
GO



SELECT * FROM sys.conversation_endpoints










DROP TABLE IF EXISTS MessagesLog
GO

CREATE TABLE MessagesLog
(
	ID INT PRIMARY KEY ,
	MsgBody XML,
	ServiceName NVARCHAR(MAX),
	ReceivedTime datetime DEFAULT GETDATE(),
	ReplyTime datetime
)
GO

TRUNCATE TABLE MessagesLog
GO





DROP PROC IF EXISTS SenderBeginDialogAndSendFirstMessage
GO

-- the procedure for starting a conversation
CREATE PROCEDURE SenderBeginDialogAndSendFirstMessage
@MsgID varchar(5)
AS
BEGIN

BEGIN TRY
BEGIN TRANSACTION;
	DECLARE @Ch UNIQUEIDENTIFIER 
	DECLARE @MsgBody XML;

	BEGIN DIALOG CONVERSATION @Ch -- Conversation handle
		FROM SERVICE [//PLSSUG/SQLSB/SenderService] -- the name of the service that starts conversation. 
		TO SERVICE '//PLSSUG/SQLSB/ReceiverService', 'CURRENT DATABASE' -- target service, 
					-- target service as a 256-characer string because it could exist on other SQL instance 
		ON CONTRACT [//PLSSUG/SQLSB/Contract]
		WITH ENCRYPTION = OFF;

		SET @MsgBody = N'<MyMsg ID="'+CAST(@MsgID AS varchar(10))+'">This is the body of message</MyMsg>';

	SEND ON CONVERSATION @Ch MESSAGE TYPE [//PLSSUG/SQLSB/MyMsg] (@MsgBody);

END TRY
BEGIN CATCH
  ROLLBACK
END CATCH

COMMIT

END
GO


DROP PROCEDURE IF EXISTS ReceiverActivated
GO

CREATE PROCEDURE ReceiverActivated
AS
	DECLARE @Ch UNIQUEIDENTIFIER
	DECLARE @MsgTypeName NVARCHAR(256)
	DECLARE	@MsgBody XML
	DECLARE @ReplyMsg XML;

	WHILE (1=1) -- process all the msg in the queue
	BEGIN
		BEGIN TRY
			BEGIN TRANSACTION

			WAITFOR (
				RECEIVE TOP(1)
					@Ch = conversation_handle,
					@MsgTypeName = message_type_name,
					@MsgBody = CAST(message_body AS XML)
				FROM dbo.ReceiverQueue
			), TIMEOUT 10000

			IF (@@ROWCOUNT = 0)
			BEGIN
				ROLLBACK TRANSACTION
				BREAK -- break out if ReceiverQueue is empty
			END


			-- a simple handling logic
			IF @MsgTypeName = N'//PLSSUG/SQLSB/MyMsg' -- check the message type
			BEGIN	
				-- processing (saving) message
				INSERT INTO MessagesLog (ID, MsgBody, ServiceName)
				SELECT @MsgBody.value('/MyMsg[1]/@ID', 'int') AS ID, @MsgBody, 'ReceiverService'

				-- reply
				SELECT @ReplyMsg = N'<MyMsg ID="'+@MsgBody.value('/MyMsg[1]/@ID', 'varchar(10)')+'">Message successfully processed</MyMsg>';

				-- send to other side of communication
				SEND ON CONVERSATION @Ch MESSAGE TYPE [//PLSSUG/SQLSB/MyMsg] (@ReplyMsg);

				-- End the conversation
				END CONVERSATION @Ch;
			END

			IF (@MsgTypeName = 'http://schemas.microsoft.com/SQL/ServiceBroker/EndDialog')
			BEGIN
				END CONVERSATION @Ch;
			END

			COMMIT TRANSACTION
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION
		END CATCH
	END
GO



DROP PROC IF EXISTS SenderActivated
GO

CREATE PROCEDURE SenderActivated
AS
	DECLARE @Ch UNIQUEIDENTIFIER
	DECLARE @MsgTypeName NVARCHAR(256)
	DECLARE	@MsgBody XML
	DECLARE @MsgID INT

	WHILE (1=1)
	BEGIN
		BEGIN TRY
			BEGIN TRANSACTION

			WAITFOR (
				RECEIVE TOP(1)
					@Ch = conversation_handle,
					@MsgTypeName = message_type_name,
					@MsgBody = CAST(message_body AS XML)
				FROM SenderQueue
			), TIMEOUT 60000

			IF (@@ROWCOUNT = 0)
			BEGIN
				ROLLBACK TRANSACTION
				BREAK
			END

			IF (@MsgTypeName = '//PLSSUG/SQLSB/MyMsg')
			BEGIN
				
			-- update replytime  and don't answer
			SELECT @MsgID = @MsgBody.value('/MyMsg[1]/@ID', 'int')
			UPDATE MessagesLog SET ReplyTime = GETDATE() WHERE ID = @MsgID
			END

			IF (@MsgTypeName = 'http://schemas.microsoft.com/SQL/ServiceBroker/EndDialog')
			BEGIN
				-- End the conversation
				END CONVERSATION @Ch;
			END

			COMMIT TRANSACTION
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION
		END CATCH
	END
GO



-- turn off activation
ALTER QUEUE dbo.SenderQueue 
WITH ACTIVATION (DROP)

ALTER QUEUE dbo.ReceiverQueue 
WITH ACTIVATION (DROP)



EXEC sp_cycle_errorlog
