USE ServiceBrokerLearning
GO

-- queues are empty at the begining
SELECT * FROM SenderQueue
SELECT * FROM ReceiverQueue
GO


DROP PROC IF EXISTS SenderBeginDialogAndSendFirstMessage
GO

-- the procedure for starting a conversation
CREATE PROCEDURE SenderBeginDialogAndSendFirstMessage
@MsgID varchar(5)
AS
BEGIN

BEGIN TRANSACTION;
	DECLARE @Ch UNIQUEIDENTIFIER 
	DECLARE @MsgBody XML;

	BEGIN DIALOG CONVERSATION @Ch -- Conversation handle
		FROM SERVICE [//PLSSUG/SQLSB/SenderService] -- the name of the service that starts conversation. 
		TO SERVICE '//PLSSUG/SQLSB/ReceiverService', 'CURRENT DATABASE' -- target service, 
					-- target service as a 256-characer string because it could exist on other SQL instance 
		ON CONTRACT [//PLSSUG/SQLSB/Contract]
		WITH ENCRYPTION = OFF;

		SET @MsgBody = N'<MyMsg ID="'+CAST(@MsgID AS varchar(10))+'">This is the body of message</MyMsg>';

	SEND ON CONVERSATION @Ch MESSAGE TYPE [//PLSSUG/SQLSB/MyMsg] (@MsgBody);
COMMIT
END
GO

-- send first message
EXEC SenderBeginDialogAndSendFirstMessage 1



-- ? which queue contain the message now
SELECT * FROM SenderQueue
SELECT * FROM ReceiverQueue
GO




-- receiving the message
DECLARE @Ch UNIQUEIDENTIFIER
DECLARE @MsgTypeName NVARCHAR(256)
DECLARE	@MsgBody XML;

BEGIN TRANSACTION;

	WAITFOR(
		RECEIVE TOP(1)
			@Ch = conversation_handle,
			@MsgTypeName = message_type_name,
			@MsgBody = CAST(message_body AS XML)
		FROM ReceiverQueue
	), TIMEOUT 5000 -- if there is no message- wait for 5 secs

	IF (@@ROWCOUNT > 0)
	SELECT 
		CAST(@Ch AS NVARCHAR(MAX)) AS 'Conversation handle',
		@MsgTypeName AS 'Message type',
		@MsgBody AS 'Message body'

COMMIT
GO




DROP TABLE IF EXISTS MessagesLog
GO

CREATE TABLE MessagesLog
(
	ID INT PRIMARY KEY,
	MsgBody XML,
	ServiceName NVARCHAR(MAX),
	ReceivedTime datetime DEFAULT GETDATE(),
	ReplyTime datetime
)
GO


--- re-sent message...
EXEC SenderBeginDialogAndSendFirstMessage 1



-- receive message, save in ReceivedMessages, reply
DECLARE @Ch UNIQUEIDENTIFIER
DECLARE @MsgTypeName NVARCHAR(256)
DECLARE	@MsgBody XML;

BEGIN TRANSACTION;

	WAITFOR(
		RECEIVE TOP(1)
			@Ch = conversation_handle,
			@MsgTypeName = message_type_name,
			@MsgBody = CAST(message_body AS XML)
		FROM ReceiverQueue
	), TIMEOUT 5000


	IF @MsgTypeName = N'//PLSSUG/SQLSB/MyMsg'
	BEGIN
		-- processing (saving) message
		INSERT INTO MessagesLog (ID, MsgBody, ServiceName)
		SELECT @MsgBody.value('/MyMsg[1]/@ID', 'int') AS ID, @MsgBody, 'ReceiverService'

		-- reply
		DECLARE @ReplyMsg XML;
		SELECT @ReplyMsg = N'<MyMsg ID="'+@MsgBody.value('/MyMsg[1]/@ID', 'varchar(10)')+'">Message successfully processed</MyMsg>';
 
		SEND ON CONVERSATION @Ch MESSAGE TYPE [//PLSSUG/SQLSB/MyMsg] (@ReplyMsg);

		-- end the conversation
		END CONVERSATION @Ch;
	END
	
	SELECT @ReplyMsg AS SentReplyMsg;
COMMIT TRAN
GO

SELECT * FROM MessagesLog


-- ? how many messages and where
SELECT * FROM SenderQueue
SELECT * FROM ReceiverQueue
GO





-- (SENDER) receive messages and end conversation 
DECLARE @Ch UNIQUEIDENTIFIER
DECLARE @MsgTypeName NVARCHAR(256)
DECLARE @MsgBody XML
DECLARE @MsgID INT

BEGIN TRANSACTION;

	WAITFOR
	( RECEIVE TOP(1)
		@Ch = conversation_handle,
		@MsgTypeName = message_type_name,
		@MsgBody = CAST(message_body AS XML)
	  FROM dbo.SenderQueue
	), TIMEOUT 5000;

		IF @MsgTypeName = N'//PLSSUG/SQLSB/MyMsg'
		BEGIN
			-- update replytime in MessageLog
			SELECT @MsgID = @MsgBody.value('/MyMsg[1]/@ID', 'int')
			UPDATE MessagesLog SET ReplyTime = GETDATE() WHERE ID = @MsgID

			END CONVERSATION @Ch;
		END

	SELECT @MsgBody AS MsgBody;

COMMIT TRANSACTION;
GO


SELECT * FROM MessagesLog
GO

SELECT * FROM SenderQueue
SELECT * FROM ReceiverQueue
GO

