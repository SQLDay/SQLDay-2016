-- http://www.sqlteam.com/article/scheduling-jobs-in-sql-server-express

-- conversation timer
-- (row 130)

/*

When the conversation timer is set it waits the number of seconds 
specified in the timeout and then it sends the 
http://schemas.microsoft.com/SQL/ServiceBroker/DialogTimer message 
to the local queue that is the part of a conversation. 
It never sends the message to the remote queue. 
As the DialogTimer message comes to the queue, 
the activation stored procedure associated with the queue fires, 
receives the message from the queue and executes whatever logic we have programmed it to. 

*/

-- 1/ Setup

USE ServiceBrokerLearning
GO

ALTER DATABASE ServiceBrokerLearning SET TRUSTWORTHY ON;
GO



-- 2/ Needed tables
-- DROP TABLE ScheduledJobs
CREATE TABLE ScheduledJobs
(
      ID INT IDENTITY(1, 1) ,
      ScheduledSql NVARCHAR(MAX) NOT NULL ,
      FirstRunOn DATETIME NOT NULL ,
      LastRunOn DATETIME,
      LastRunOK BIT NOT NULL DEFAULT (0),
      IsRepeatable BIT NOT NULL DEFAULT (0),
      IsEnabled BIT NOT NULL DEFAULT (0),
      ConversationHandle UNIQUEIDENTIFIER NULL
) 

-- DROP TABLE ScheduledJobsErrors
CREATE TABLE ScheduledJobsErrors
(
      Id BIGINT IDENTITY(1, 1) PRIMARY KEY,
      ErrorLine INT,
      ErrorNumber INT,
      ErrorMessage NVARCHAR(MAX),
      ErrorSeverity INT,
      ErrorState INT,
      ScheduledJobId INT,
      ErrorDate DATETIME NOT NULL DEFAULT GETUTCDATE()
) 


-- 3/ Needed stored procedures

DROP PROC IF EXISTS usp_RemoveScheduledJob 
GO

CREATE PROC usp_RemoveScheduledJob
	@ScheduledJobId INT
AS	
	BEGIN TRANSACTION
	BEGIN TRY
		DECLARE @ConversationHandle UNIQUEIDENTIFIER
		-- get the conversation handle for our job
		SELECT	@ConversationHandle = ConversationHandle
		FROM	ScheduledJobs 
		WHERE	Id = @ScheduledJobId 
		
		-- if the job doesn't exist return
		IF @@ROWCOUNT = 0
			RETURN;
		
		-- end the conversation if it is active
		IF EXISTS (SELECT * FROM sys.conversation_endpoints WHERE conversation_handle = @ConversationHandle)
			END CONVERSATION @ConversationHandle
		
		-- delete the scheduled job from out table
		DELETE ScheduledJobs WHERE Id = @ScheduledJobId 	
		
		COMMIT	
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0
		BEGIN 
			ROLLBACK;
		END
		INSERT INTO ScheduledJobsErrors (
				ErrorLine, ErrorNumber, ErrorMessage, 
				ErrorSeverity, ErrorState, ScheduledJobId)
		SELECT	ERROR_LINE(), ERROR_NUMBER(), 'usp_RemoveScheduledJob: ' + ERROR_MESSAGE(), 
				ERROR_SEVERITY(), ERROR_STATE(), @ScheduledJobId
	END CATCH

GO

DROP PROC IF EXISTS usp_AddScheduledJob
GO


CREATE PROC usp_AddScheduledJob
(
	@ScheduledSql NVARCHAR(MAX),
	@FirstRunOn DATETIME, 
	@IsRepeatable BIT	
)
AS
	DECLARE @ScheduledJobId INT, @TimeoutInSeconds INT, @ConversationHandle UNIQUEIDENTIFIER	
	BEGIN TRANSACTION
	BEGIN TRY

		PRINT @ScheduledSql
		-- add job to our table
		INSERT INTO ScheduledJobs(ScheduledSql, FirstRunOn, IsRepeatable, ConversationHandle)
		VALUES (@ScheduledSql, @FirstRunOn, @IsRepeatable, NULL)
		SELECT @ScheduledJobId = SCOPE_IDENTITY()
		
		-- set the timeout. It's in seconds so we need the datediff
		SELECT @TimeoutInSeconds = DATEDIFF(s, GETDATE(), @FirstRunOn);
		-- begin a conversation for our scheduled job
		BEGIN DIALOG CONVERSATION @ConversationHandle
			FROM SERVICE   [//ScheduledJobService]
			TO SERVICE      '//ScheduledJobService', 
							'CURRENT DATABASE'
			ON CONTRACT     [//ScheduledJobContract]
			WITH ENCRYPTION = OFF;

		-- start the conversation timer
		BEGIN CONVERSATION TIMER (@ConversationHandle)
		TIMEOUT = @TimeoutInSeconds;

		-- SELECT name, validation, validation_desc FROM sys.service_message_types


		-- associate or scheduled job with the conversation via the Conversation Handle
		UPDATE	ScheduledJobs
		SET		ConversationHandle = @ConversationHandle, 
				IsEnabled = 1
		WHERE	ID = @ScheduledJobId 
		IF @@TRANCOUNT > 0
		BEGIN 
			COMMIT;
		END
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0
		BEGIN 
			ROLLBACK;
		END
		INSERT INTO ScheduledJobsErrors (
				ErrorLine, ErrorNumber, ErrorMessage, 
				ErrorSeverity, ErrorState, ScheduledJobId)
		SELECT	ERROR_LINE(), ERROR_NUMBER(), 'usp_AddScheduledJob: ' + ERROR_MESSAGE(), 
				ERROR_SEVERITY(), ERROR_STATE(), @ScheduledJobId
	END CATCH

GO



DROP PROC IF EXISTS usp_RunScheduledJob
GO

CREATE PROC usp_RunScheduledJob
WITH EXECUTE AS  'dbo'
AS
	DECLARE @ConversationHandle UNIQUEIDENTIFIER, @ScheduledJobId INT, @LastRunOn DATETIME, @IsEnabled BIT, @LastRunOK BIT
	
	SELECT	@LastRunOn = GETDATE(), @IsEnabled = 0, @LastRunOK = 0
	-- we don't need transactions since we don't want to put the job back in the queue if it fails
	BEGIN TRY
		DECLARE @message_type_name sysname;			
		-- receive only one message from the queue
		RECEIVE TOP(1) 
			    @ConversationHandle = conversation_handle,
			    @message_type_name = message_type_name
		FROM ScheduledJobQueue
	
		-- exit if no message or other type of message than DialgTimer 
		IF @@ROWCOUNT = 0 OR ISNULL(@message_type_name, '') != 'http://schemas.microsoft.com/SQL/ServiceBroker/DialogTimer'
			RETURN;
		
		DECLARE @ScheduledSql NVARCHAR(MAX), @IsRepeatable BIT				
		-- get a scheduled job that is enabled and is associated with our conversation handle.
		-- if a job fails we disable it by setting IsEnabled to 0
		SELECT	@ScheduledJobId = ID, @ScheduledSql = ScheduledSql, @IsRepeatable = IsRepeatable
		FROM	ScheduledJobs 
		WHERE	ConversationHandle = @ConversationHandle AND IsEnabled = 1
					
		-- end the conversation if it's non repeatable
		IF @IsRepeatable = 0
		BEGIN			
			END CONVERSATION @ConversationHandle
			SELECT @IsEnabled = 0
		END
		ELSE
		BEGIN 
			-- reset the timer to fire again in one day
			BEGIN CONVERSATION TIMER (@ConversationHandle)
				TIMEOUT = 86400; -- 60*60*24 secs = 1 DAY
			SELECT @IsEnabled = 1
		END

		-- run our job
		EXEC (@ScheduledSql)
		
		SELECT @LastRunOK = 1
	END TRY
	BEGIN CATCH		
		SELECT @IsEnabled = 0
		
		INSERT INTO ScheduledJobsErrors (
				ErrorLine, ErrorNumber, ErrorMessage, 
				ErrorSeverity, ErrorState, ScheduledJobId)
		SELECT	ERROR_LINE(), ERROR_NUMBER(), 'usp_RunScheduledJob: ' + ERROR_MESSAGE(), 
				ERROR_SEVERITY(), ERROR_STATE(), @ScheduledJobId
		
		-- if an error happens end our conversation if it exists
		IF @ConversationHandle != NULL		
		BEGIN
			IF EXISTS (SELECT * FROM sys.conversation_endpoints WHERE conversation_handle = @ConversationHandle)
				END CONVERSATION @ConversationHandle
		END
			
	END CATCH;
	-- update the job status
	UPDATE	ScheduledJobs
	SET		LastRunOn = @LastRunOn,
			IsEnabled = @IsEnabled,
			LastRunOK = @LastRunOK
	WHERE	ID = @ScheduledJobId
GO



-- 4/ Service Broker objects

IF EXISTS(SELECT * FROM sys.services WHERE NAME = N'//ScheduledJobService')
	DROP SERVICE [//ScheduledJobService]

IF EXISTS(SELECT * FROM sys.service_queues WHERE NAME = N'ScheduledJobQueue')
	DROP QUEUE ScheduledJobQueue

IF EXISTS(SELECT * FROM sys.service_contracts  WHERE NAME = N'//ScheduledJobContract')
	DROP CONTRACT [//ScheduledJobContract]
GO

CREATE CONTRACT [//ScheduledJobContract]
	([http://schemas.microsoft.com/SQL/ServiceBroker/DialogTimer] SENT BY INITIATOR)

CREATE QUEUE ScheduledJobQueue 
	WITH STATUS = ON, 
	ACTIVATION (	
		PROCEDURE_NAME = usp_RunScheduledJob,
		MAX_QUEUE_READERS = 20, -- we expect max 20 jobs to start simultaneously
		EXECUTE AS 'dbo' );

CREATE SERVICE [//ScheduledJobService] 
	AUTHORIZATION dbo
	ON QUEUE ScheduledJobQueue ([//ScheduledJobContract])


-- 5/ TEST
DECLARE @ScheduledSql nvarchar(max) = 'BACKUP DATABASE iFTSDemo TO DISK = ''C:\temp\SQL2012.bak'' WITH INIT, FORMAT'
DECLARE @RunOn DATETIME = DATEADD(s, 10, getdate())
DECLARE @IsRepeatable BIT = 1
EXEC usp_AddScheduledJob @ScheduledSql, @RunOn, @IsRepeatable
GO

DECLARE @ScheduledSql nvarchar(max) = N'EXEC sp_updatestats;' 
DECLARE @RunOn DATETIME = dateadd(s, 30, getdate())
DECLARE @IsRepeatable BIT = 1
EXEC usp_AddScheduledJob @ScheduledSql, @RunOn, @IsRepeatable
GO

EXEC usp_RemoveScheduledJob 15

--EXEC usp_RemoveScheduledJob 1
--EXEC usp_RemoveScheduledJob 2
GO

-- show the currently active conversations. 
-- Look at dialog_timer column to see when will the job be run next
SELECT * FROM sys.conversation_endpoints

-- shows the number of currently executing activation procedures
SELECT * FROM sys.dm_broker_activated_tasks

-- see how many unreceived messages are still in the queue. 
-- should be 0 when no jobs are running
SELECT * FROM ScheduledJobQueue with (nolock)

-- view our scheduled jobs' statuses
SELECT * FROM ScheduledJobs  with (nolock) ORDER BY ID DESC

-- view any scheduled jobs errors that might have happend
SELECT * FROM ScheduledJobsErrors  with (nolock) ORDER BY ID DESC



SELECT @@TRANCOUNT
-- ROLLBACK


/*
Service Broker messages that are not successfully transmitted to the receiving queue are held in 
the Service Broker transmission queue in the sending database. You can use the sys.transmission_queue 
system view in each database to see the messages in the queue. For any messages that are in the queue 
because of a transmission error, the transmission_status column contains the error message.
*/

SELECT * FROM sys.transmission_queue
