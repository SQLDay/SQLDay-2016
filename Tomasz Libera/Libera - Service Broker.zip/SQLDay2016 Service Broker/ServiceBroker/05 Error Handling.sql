USE ServiceBrokerLearning
GO


-- ReceiverQueue is enabled again
SELECT name, activation_procedure, is_receive_enabled, is_enqueue_enabled 
FROM sys.service_queues
GO




-- new version of activated procedure with error handling
DROP PROCEDURE IF EXISTS ReceiverActivatedVer2
GO
CREATE PROCEDURE ReceiverActivatedVer2
AS
	DECLARE @Ch UNIQUEIDENTIFIER
	DECLARE @MsgTypeName NVARCHAR(256)
	DECLARE	@MsgBody XML
	DECLARE @ReplyMsg XML;

	DECLARE @Error int
	DECLARE @ErrorMessage nvarchar(4000)

	WHILE (1=1) -- process all the msg in the queue
	BEGIN
		BEGIN TRY
			BEGIN TRANSACTION

			WAITFOR (
				RECEIVE TOP(1)
					@Ch = conversation_handle,
					@MsgTypeName = message_type_name,
					@MsgBody = CAST(message_body AS XML)
				FROM dbo.ReceiverQueue
			), TIMEOUT 10000

			IF (@@ROWCOUNT = 0)
			BEGIN
				ROLLBACK TRANSACTION
				BREAK -- break out if ReceiverQueue is empty
			END

			-- a simple handling logic
			IF @MsgTypeName = N'//PLSSUG/SQLSB/MyMsg' -- check the message type
			BEGIN	
				-- processing (saving) message
				INSERT INTO MessagesLog (ID, MsgBody, ServiceName)
				SELECT @MsgBody.value('/MyMsg[1]/@ID', 'int') AS ID, @MsgBody, 'ReceiverService'

				-- reply
				SELECT @ReplyMsg = N'<MyMsg ID="'+@MsgBody.value('/MyMsg[1]/@ID', 'varchar(10)')+'">Message successfully processed</MyMsg>';

				-- send to other side of communication
				SEND ON CONVERSATION @Ch MESSAGE TYPE [//PLSSUG/SQLSB/MyMsg] (@ReplyMsg);

				-- End the conversation
				END CONVERSATION @Ch;
			END

			IF (@MsgTypeName = 'http://schemas.microsoft.com/SQL/ServiceBroker/EndDialog')
			BEGIN
				END CONVERSATION @Ch;
			END

			COMMIT TRANSACTION
		END TRY
		BEGIN CATCH
			--ROLLBACK -- (ver1)

			/*
				1  = tran commitable
				-1 = uncommitable, should be rolled back
			*/
			IF(XACT_STATE())=1
			BEGIN
			  -- save the reason of problem...
			  SELECT @Error = ERROR_NUMBER(), @ErrorMessage = ERROR_MESSAGE();

			  END CONVERSATION @Ch WITH ERROR = @Error DESCRIPTION = @ErrorMessage			
			  COMMIT
			END

			IF(XACT_STATE())=-1
			BEGIN
			  ROLLBACK
			  SELECT @Error = ERROR_NUMBER(), @ErrorMessage = ERROR_MESSAGE();

			  BEGIN TRANSACTION;
			  RECEIVE TOP(1)
					@Ch = conversation_handle,
					@MsgTypeName = message_type_name,
					@MsgBody = CAST(message_body AS XML)
				FROM dbo.ReceiverQueue
			  END CONVERSATION @Ch WITH ERROR = @Error DESCRIPTION = @ErrorMessage 
			  COMMIT
			END 
		END CATCH
	END
GO



-- enable activation
ALTER QUEUE dbo.ReceiverQueue
WITH ACTIVATION
(
	STATUS = ON,
	PROCEDURE_NAME = dbo.ReceiverActivatedVer2,
	MAX_QUEUE_READERS = 1,
	EXECUTE AS SELF
)
GO



SELECT name, activation_procedure, is_receive_enabled, is_enqueue_enabled 
FROM sys.service_queues
GO





EXEC SenderBeginDialogAndSendFirstMessage 1
GO



-- message processed sucesfully 
SELECT * FROM MessagesLog

-- reply & EndDialog at the senderqueue
SELECT priority, message_sequence_number, CAST(message_body AS xml) AS message_body, message_type_name
FROM SenderQueue
GO





-- againt the same ID (PK violation)
EXEC SenderBeginDialogAndSendFirstMessage 1
GO


-- no new message
SELECT * FROM MessagesLog


-- catch block sent reply with error description
SELECT priority, message_sequence_number, CAST(message_body AS xml) AS message_body, message_type_name
FROM SenderQueue
GO



--SELECT * FROM sys.conversation_endpoints


--SELECT * FROM sys.dm_broker_queue_monitors









EXEC SenderBeginDialogAndSendFirstMessage 'A'
GO



SELECT name, activation_procedure, is_receive_enabled, is_enqueue_enabled 
FROM sys.service_queues
GO



-- no new message
SELECT * FROM MessagesLog


-- catch block sent reply with error description
SELECT priority, message_sequence_number, CAST(message_body AS xml) AS message_body, message_type_name
FROM SenderQueue
GO


