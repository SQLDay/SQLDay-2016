USE ServiceBrokerLearning
GO

-- cleanup

TRUNCATE TABLE dbo.MessagesLog
GO


DROP PROCEDURE IF EXISTS ReceiverActivated
GO
CREATE PROCEDURE ReceiverActivated
AS
	DECLARE @Ch UNIQUEIDENTIFIER
	DECLARE @MsgTypeName NVARCHAR(256)
	DECLARE	@MsgBody XML
	DECLARE @ReplyMsg XML;

	WHILE (1=1) -- process all the msg in the queue
	BEGIN
		BEGIN TRY
			BEGIN TRANSACTION

			WAITFOR (
				RECEIVE TOP(1)
					@Ch = conversation_handle,
					@MsgTypeName = message_type_name,
					@MsgBody = CAST(message_body AS XML)
				FROM dbo.ReceiverQueue
			), TIMEOUT 10000

			IF (@@ROWCOUNT = 0)
			BEGIN
				ROLLBACK TRANSACTION
				BREAK -- break out if ReceiverQueue is empty
			END


			-- a simple handling logic
			IF @MsgTypeName = N'//PLSSUG/SQLSB/MyMsg' -- check the message type
			BEGIN	
				-- processing (saving) message
				INSERT INTO MessagesLog (ID, MsgBody, ServiceName)
				SELECT @MsgBody.value('/MyMsg[1]/@ID', 'int') AS ID, @MsgBody, 'ReceiverService'

				-- reply
				SELECT @ReplyMsg = N'<MyMsg ID="'+@MsgBody.value('/MyMsg[1]/@ID', 'varchar(10)')+'">Message successfully processed</MyMsg>';

				-- send to other side of communication
				SEND ON CONVERSATION @Ch MESSAGE TYPE [//PLSSUG/SQLSB/MyMsg] (@ReplyMsg);

				-- End the conversation
				END CONVERSATION @Ch;
			END

			IF (@MsgTypeName = 'http://schemas.microsoft.com/SQL/ServiceBroker/EndDialog')
			BEGIN
				END CONVERSATION @Ch;
			END

			COMMIT TRANSACTION
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION
		END CATCH
	END
GO



-- enable activation
ALTER QUEUE dbo.ReceiverQueue
WITH ACTIVATION
(
	STATUS = ON,
	PROCEDURE_NAME = dbo.ReceiverActivated,
	MAX_QUEUE_READERS = 1,
	EXECUTE AS SELF
)
GO


-- which queue is activated
SELECT name, activation_procedure, is_activation_enabled, is_receive_enabled, is_enqueue_enabled 
FROM sys.service_queues
GO



EXEC SenderBeginDialogAndSendFirstMessage 1





-- ? which queue contain the message now
SELECT * FROM SenderQueue
SELECT * FROM ReceiverQueue
GO


SELECT * FROM MessagesLog
GO




DROP PROC IF EXISTS SenderActivated
GO

CREATE PROCEDURE SenderActivated
AS
	DECLARE @Ch UNIQUEIDENTIFIER
	DECLARE @MsgTypeName NVARCHAR(256)
	DECLARE	@MsgBody XML
	DECLARE @MsgID INT

	WHILE (1=1)
	BEGIN
		BEGIN TRY
			BEGIN TRANSACTION

			WAITFOR (
				RECEIVE TOP(1)
					@Ch = conversation_handle,
					@MsgTypeName = message_type_name,
					@MsgBody = CAST(message_body AS XML)
				FROM SenderQueue
			), TIMEOUT 60000

			IF (@@ROWCOUNT = 0)
			BEGIN
				ROLLBACK TRANSACTION
				BREAK
			END

			IF (@MsgTypeName = '//PLSSUG/SQLSB/MyMsg')
			BEGIN
				
			-- update replytime  and don't answer
			SELECT @MsgID = @MsgBody.value('/MyMsg[1]/@ID', 'int')
			UPDATE MessagesLog SET ReplyTime = GETDATE() WHERE ID = @MsgID
			END

			IF (@MsgTypeName = 'http://schemas.microsoft.com/SQL/ServiceBroker/EndDialog')
			BEGIN
				-- End the conversation
				END CONVERSATION @Ch;
			END

			COMMIT TRANSACTION
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION
		END CATCH
	END
GO


-- enable activation
ALTER QUEUE dbo.SenderQueue
WITH ACTIVATION
(
	STATUS = ON,
	PROCEDURE_NAME = dbo.SenderActivated,
	MAX_QUEUE_READERS = 1,
	EXECUTE AS SELF
)
GO

-- test activation
EXEC SenderBeginDialogAndSendFirstMessage 2

SELECT * FROM MessagesLog



ALTER QUEUE dbo.ReceiverQueue
WITH ACTIVATION
(
   STATUS = OFF
)





-- start 2000 conversations
DECLARE @i INT
SET @i = 11

WHILE (@i <= 2010)
BEGIN
	BEGIN TRAN;
    EXEC SenderBeginDialogAndSendFirstMessage @i
	COMMIT TRAN;
	SET @i = @i + 1
END
GO





SELECT * FROM ReceiverQueue
GO

-- activate receiver queue
ALTER QUEUE dbo.ReceiverQueue
WITH ACTIVATION
(
	STATUS = ON,
	PROCEDURE_NAME = dbo.ReceiverActivated,
	MAX_QUEUE_READERS = 20,
	EXECUTE AS SELF
)
GO





SELECT * FROM SenderQueue
GO

SELECT * FROM ReceiverQueue
GO




SELECT * FROM MessagesLog
GO

