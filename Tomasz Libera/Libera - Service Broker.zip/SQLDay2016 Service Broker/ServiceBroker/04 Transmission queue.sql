USE ServiceBrokerLearning
GO
-- cleanup
TRUNCATE table MessagesLog
GO

-- queues are empty at the begining
SELECT * FROM SenderQueue
SELECT * FROM ReceiverQueue
GO

SELECT * FROM sys.transmission_queue


-- turn off activation
ALTER QUEUE dbo.SenderQueue 
WITH ACTIVATION (DROP)

ALTER QUEUE dbo.ReceiverQueue 
WITH ACTIVATION (DROP)





SELECT name, activation_procedure, is_receive_enabled, is_enqueue_enabled 
FROM sys.service_queues
GO


-- send first message
EXEC SenderBeginDialogAndSendFirstMessage 1




-- no rows- message reached the target
SELECT transmission_status, * FROM sys.transmission_queue
GO

SELECT * FROM SenderQueue
SELECT * FROM ReceiverQueue
GO





ALTER QUEUE dbo.ReceiverQueue
WITH STATUS = OFF;


SELECT name, activation_procedure, is_receive_enabled, is_enqueue_enabled 
FROM sys.service_queues
GO





-- send the second message
EXEC SenderBeginDialogAndSendFirstMessage 2



-- still only one message; second didn't reach the target
SELECT * FROM SenderQueue
SELECT * FROM ReceiverQueue
GO

-- transmission_status: 
-- One or more messages could not be delivered to the local service targeted by this dialog.
SELECT transmission_status, * FROM sys.transmission_queue





-- send next 100 messages
DECLARE @i INT
SET @i = 11

WHILE (@i <= 110)
BEGIN
	BEGIN TRAN;
    EXEC SenderBeginDialogAndSendFirstMessage @i
	COMMIT TRAN;
	SET @i = @i + 1
END
GO





-- still only one message; second didn't reach the target
SELECT * FROM SenderQueue
SELECT * FROM ReceiverQueue
GO

-- transmission_status: 
-- One or more messages could not be delivered to the local service targeted by this dialog.
-- x 101
SELECT transmission_status, * FROM sys.transmission_queue



ALTER QUEUE dbo.ReceiverQueue
WITH STATUS = ON;



SELECT * FROM ReceiverQueue
GO



--.....

-- enable receiver activation- to process sent messages
ALTER QUEUE dbo.ReceiverQueue
WITH ACTIVATION
(
	STATUS = ON,
	PROCEDURE_NAME = dbo.ReceiverActivated,
	MAX_QUEUE_READERS = 1,
	EXECUTE AS SELF
)
GO


SELECT * FROM SenderQueue
SELECT * FROM ReceiverQueue
GO



SELECT * FROM MessagesLog






-- enable sender activation
ALTER QUEUE dbo.SenderQueue
WITH ACTIVATION
(
	STATUS = ON,
	PROCEDURE_NAME = dbo.SenderActivated,
	MAX_QUEUE_READERS = 1,
	EXECUTE AS SELF
)
GO



SELECT * FROM SenderQueue
SELECT * FROM ReceiverQueue
GO


SELECT * FROM MessagesLog





/*

  ServiceBroker is disabled...

*/
ALTER DATABASE ServiceBrokerLearning
SET DISABLE_BROKER WITH ROLLBACK IMMEDIATE;
GO

SELECT name, service_broker_guid, is_broker_enabled 
FROM sys.databases WHERE name = 'ServiceBrokerLearning'
GO


-- send next 100 messages, while SB is disabled
DECLARE @i INT
SET @i = 501

WHILE (@i <= 600)
BEGIN
	BEGIN TRAN;
    EXEC SenderBeginDialogAndSendFirstMessage @i
	COMMIT TRAN;
	SET @i = @i + 1
END
GO





-- no rows; messages didn't reach the target
SELECT * FROM SenderQueue
SELECT * FROM ReceiverQueue
GO

-- transmission_status: 
-- The broker is disabled in the sender's database.
-- x 100
SELECT transmission_status, * FROM sys.transmission_queue


ALTER DATABASE ServiceBrokerLearning
SET ENABLE_BROKER WITH ROLLBACK IMMEDIATE;


SELECT transmission_status, * FROM sys.transmission_queue



SELECT * FROM SenderQueue
SELECT * FROM ReceiverQueue
GO

SELECT * FROM MessagesLog





/*

  lets 

*/



-- !!! we don't need activation at sender
ALTER QUEUE dbo.SenderQueue 
WITH ACTIVATION (DROP)


SELECT name, activation_procedure, is_receive_enabled, is_enqueue_enabled 
FROM sys.service_queues
GO


SELECT MAX(ID) FROM MessagesLog


EXEC SenderBeginDialogAndSendFirstMessage 601



SELECT MAX(ID) FROM MessagesLog


EXEC SenderBeginDialogAndSendFirstMessage 601

EXEC SenderBeginDialogAndSendFirstMessage 602

EXEC SenderBeginDialogAndSendFirstMessage 603


--SELECT * FROM SenderQueue
-- only one message (ID: 601) reached the target
SELECT * FROM ReceiverQueue
GO


SELECT MAX(ID) FROM MessagesLog





SELECT transmission_status, * FROM sys.transmission_queue


SELECT name, activation_procedure, is_receive_enabled, is_enqueue_enabled 
FROM sys.service_queues
GO

/*

POISON MESSAGE:
When error ocurs during message processing 
� transaction is rolled back and message 
is going back to the queue

After 5 rollbacks in a row � a queue 
will be disabled to stop the poison message

*/


-- Cleanup...


-- ReceiverQueue is enabled again
SELECT name, activation_procedure, is_receive_enabled, is_enqueue_enabled 
FROM sys.service_queues
GO


