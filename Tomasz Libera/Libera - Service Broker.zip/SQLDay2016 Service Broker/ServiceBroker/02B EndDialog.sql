USE ServiceBrokerLearning
GO

-- ! cleaup

/*
  QUEUE
  message_sequence_number
*/



EXEC SenderBeginDialogAndSendFirstMessage 1


-- receive message, save in ReceivedMessages, reply
DECLARE @ch UNIQUEIDENTIFIER
DECLARE @MsgTypeName NVARCHAR(256)
DECLARE	@MsgBody XML;

BEGIN TRANSACTION;

	WAITFOR(
		RECEIVE TOP(1)
			@Ch = conversation_handle,
			@MsgTypeName = message_type_name,
			@MsgBody = CAST(message_body AS XML)
		FROM ReceiverQueue
	), TIMEOUT 5000

	
	IF @MsgTypeName = N'//PLSSUG/SQLSB/MyMsg'
	BEGIN;
		-- reply 1st
		SEND ON CONVERSATION @Ch MESSAGE TYPE [//PLSSUG/SQLSB/MyMsg] ('<MyMsg>FirstReply</MyMsg>');

		-- reply 2nd
		SEND ON CONVERSATION @Ch MESSAGE TYPE [//PLSSUG/SQLSB/MyMsg] ('<MyMsg>SeconfReply</MyMsg>');

		--PRINT @Ch
		DROP TABLE IF EXISTS #_lastCh 
		SELECT @Ch AS last_conversation_handle INTO #_lastCh

		SELECT * FROM #_lastCh
		--END CONVERSATION @Ch;

		END CONVERSATION @Ch;
	END
	
COMMIT TRAN
GO


SELECT priority, message_sequence_number, CAST(message_body AS xml) AS message_body, message_type_name
FROM SenderQueue
GO

SELECT * FROM #_lastCh

-- ! conversation handle
-- end the conversation
--END CONVERSATION '...';


-- reply 3rd
SEND ON CONVERSATION '5F045876-F11C-E611-9C0A-001A6B0DEE90'
MESSAGE TYPE [//PLSSUG/SQLSB/MyMsg] ('<MyMsg>ThirdReply</MyMsg>');

-- an error because the conversation is closed

-- ! cleanup...





-- re-run this example

EXEC SenderBeginDialogAndSendFirstMessage 1


-- receive message, save in ReceivedMessages, reply
DECLARE @ch UNIQUEIDENTIFIER
DECLARE @MsgTypeName NVARCHAR(256)
DECLARE	@MsgBody XML;

BEGIN TRANSACTION;

	WAITFOR(
		RECEIVE TOP(1)
			@Ch = conversation_handle,
			@MsgTypeName = message_type_name,
			@MsgBody = CAST(message_body AS XML)
		FROM ReceiverQueue
	), TIMEOUT 5000

	
	IF @MsgTypeName = N'//PLSSUG/SQLSB/MyMsg'
	BEGIN;
		-- reply 1st
		SEND ON CONVERSATION @Ch MESSAGE TYPE [//PLSSUG/SQLSB/MyMsg] ('<MyMsg>FirstReply</MyMsg>');

		-- reply 2nd
		SEND ON CONVERSATION @Ch MESSAGE TYPE [//PLSSUG/SQLSB/MyMsg] ('<MyMsg>SeconfReply</MyMsg>');

		--PRINT @Ch
		DROP TABLE IF EXISTS #_lastCh 
		SELECT @Ch AS last_conversation_handle INTO #_lastCh

		SELECT * FROM #_lastCh
		--END CONVERSATION @Ch;
	END
	
COMMIT TRAN
GO


SELECT priority, message_sequence_number, CAST(message_body AS xml) AS message_body, message_type_name
FROM SenderQueue
GO

SELECT * FROM #_lastCh


-- end with error
END CONVERSATION '51691C8C-F11C-E611-9C0A-001A6B0DEE90' WITH ERROR = 31472
DESCRIPTION = 'Something goes wrong'



SELECT priority, message_sequence_number, CAST(message_body AS xml) AS message_body, message_type_name
FROM SenderQueue
GO
