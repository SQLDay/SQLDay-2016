select  failure_condition_level, health_check_timeout from sys.availability_groups


ALTER AVAILABILITY GROUP [Contoso-ag] SET (FAILURE_CONDITION_LEVEL = 3)
ALTER AVAILABILITY GROUP [Contoso-ag] SET (HEALTH_CHECK_TIMEOUT = 30000)
