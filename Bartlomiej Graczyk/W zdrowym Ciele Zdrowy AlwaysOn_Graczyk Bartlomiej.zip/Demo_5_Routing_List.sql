ALTER AVAILABILITY GROUP [ag-sql2k16] MODIFY REPLICA ON 'SQLSERVER-1\SQL2K16'
WITH (SECONDARY_ROLE(READ_ONLY_ROUTING_URL=N'TCP://sqlserver-1.contoso.com:5024'))

ALTER AVAILABILITY GROUP [ag-sql2k16] MODIFY REPLICA ON 'SQLSERVER-0\SQL2K16'
WITH (SECONDARY_ROLE(READ_ONLY_ROUTING_URL=N'TCP://sqlserver-0.contoso.com:5024'))

ALTER AVAILABILITY GROUP [ag-sql2k16] MODIFY REPLICA ON 'SQLSERVER-0\SQL2K16'
WITH (PRIMARY_ROLE(READ_ONLY_ROUTING_LIST=(N'SQLSERVER-1\SQL2K16',N'SQLSERVER-0\SQL2K16')))

ALTER AVAILABILITY GROUP [ag-sql2k16] MODIFY REPLICA ON 'SQLSERVER-1\SQL2K16'
WITH (PRIMARY_ROLE(READ_ONLY_ROUTING_LIST=(N'SQLSERVER-0\SQL2K16',N'SQLSERVER-1\SQL2K16')))


--- list routingu
SELECT ag.name as 'Availability Group', ar.replica_server_name as 'When Primary Replica Is',
        rl.routing_priority as 'Routing Priority', ar2.replica_server_name as 'RO Routed To',

        ar.secondary_role_allow_connections_desc, ar2.read_only_routing_url
FROM sys.availability_read_only_routing_lists rl
        inner join sys.availability_replicas ar on rl.replica_id = ar.replica_id

        inner join sys.availability_replicas ar2 on rl.read_only_replica_id = ar2.replica_id

        inner join sys.availability_groups ag on ar.group_id = ag.group_id
ORDER BY ag.name, ar.replica_server_name, rl.routing_priority



ALTER AVAILABILITY GROUP [ag-sql2k16] MODIFY REPLICA ON 'SQLSERVER-0\SQL2K16'
WITH (PRIMARY_ROLE(READ_ONLY_ROUTING_LIST=(N'SQLSERVER-0\SQL2K16')))