--- Create the primary availability group on the first cluster
CREATE AVAILABILITY GROUP [ag1] 
FOR DATABASE db1 
REPLICA ON N'server1' WITH (ENDPOINT_URL = N'TCP://server1.contoso.com:5022',
    FAILOVER_MODE = AUTOMATIC,
    AVAILABILITY_MODE = SYNCHRONOUS_COMMIT, 
    BACKUP_PRIORITY = 50, 
    SECONDARY_ROLE(ALLOW_CONNECTIONS = NO), 
    SEEDING_MODE = AUTOMATIC), 
N'server2' WITH (ENDPOINT_URL = N'TCP://server2.contoso.com:5022', 
    FAILOVER_MODE = AUTOMATIC, 
    AVAILABILITY_MODE = SYNCHRONOUS_COMMIT, 
    BACKUP_PRIORITY = 50, 
    SECONDARY_ROLE(ALLOW_CONNECTIONS = NO), 
    SEEDING_MODE = AUTOMATIC); 
GO


--Join the secondary replicas to the primary availability group
ALTER AVAILABILITY GROUP [ag1] JOIN 
ALTER AVAILABILITY GROUP [ag1] GRANT CREATE ANY DATABASE
GO

--Create a listener for the primary availability group
ALTER AVAILABILITY GROUP [ag1]  
ADD LISTENER 'ag1-listener' ( WITH IP ( ('2001:db88:f0:f00f::cf3c'),('2001:4898:e0:f213::4ce2') ) , PORT = 60173);  
GO


--Create the secondary availability group on the second cluster
CREATE AVAILABILITY GROUP [ag2] 
FOR 
REPLICA ON N'server3' WITH (ENDPOINT_URL = N'TCP://server3.contoso.com:5022', 
    FAILOVER_MODE = MANUAL, 
    AVAILABILITY_MODE = SYNCHRONOUS_COMMIT, 
    BACKUP_PRIORITY = 50, 
    SECONDARY_ROLE(ALLOW_CONNECTIONS = NO), 
    SEEDING_MODE = AUTOMATIC), 
N'server4' WITH (ENDPOINT_URL = N'TCP://server4.contoso.com:5022', 
    FAILOVER_MODE = MANUAL, 
    AVAILABILITY_MODE = SYNCHRONOUS_COMMIT, 
    BACKUP_PRIORITY = 50, 
    SECONDARY_ROLE(ALLOW_CONNECTIONS = NO), 
    SEEDING_MODE = AUTOMATIC); 
GO

--Join the secondary replicas to the secondary availability group
ALTER AVAILABILITY GROUP [ag2] JOIN 
ALTER AVAILABILITY GROUP [ag2] GRANT CREATE ANY DATABASE
GO

--Create a listener for the secondary availability group
ALTER AVAILABILITY GROUP [ag2]  
ADD LISTENER 'ag2-listener' ( WITH IP ( ('2001:db88:f0:f00f::cf3c'),('2001:4898:e0:f213::4ce2') ) , PORT = 60173);  
GO


--Create the distributed availability group on the first cluster
CREATE AVAILABILITY GROUP [distributedag]
WITH (DISTRIBUTED) 
AVAILABILITY GROUP ON
'ag1' WITH  
( 
LISTENER_URL = 'tcp://ag1-listener:5022',  
AVAILABILITY_MODE = ASYNCHRONOUS_COMMIT, 
FAILOVER_MODE = MANUAL, 
SEEDING_MODE = AUTOMATIC 
), 
'ag2' WITH  
( 
LISTENER_URL = 'tcp://ag2-listener:5022', 
AVAILABILITY_MODE = ASYNCHRONOUS_COMMIT, 
FAILOVER_MODE = MANUAL, 
SEEDING_MODE = AUTOMATIC 
);  
GO 

--Join the distributed availability group on the second cluster
ALTER AVAILABILITY GROUP [distributedag] 
JOIN 
AVAILABILITY GROUP ON
'ag1' WITH  
   ( 
 LISTENER_URL = 'tcp://ag1-listener:5022',  
 AVAILABILITY_MODE = ASYNCHRONOUS_COMMIT, 
 FAILOVER_MODE = MANUAL, 
 SEEDING_MODE = AUTOMATIC 
 ), 
 'ag2' WITH  
( 
 LISTENER_URL = 'tcp://ag2-listener:5022', 
 AVAILABILITY_MODE = ASYNCHRONOUS_COMMIT, 
 FAILOVER_MODE = MANUAL, 
 SEEDING_MODE = AUTOMATIC 
 );  
GO


ALTER AVAILABILITY GROUP [distributedag] FORCE_FAILOVER_ALLOW_DATA_LOSS
