-- Anomaly Detection

USE AdventureWorksDW2012;
GO

-- Show DMX query to find outliers using a Clustering model

-- SSAS linked server
-- Creating a linked server
USE master;
GO
EXEC master.dbo.sp_addlinkedserver @server = N'ASLOCAL', 
  @srvproduct=N'', @provider=N'MSOLAP', 
  @datasrc=N'localhost', @catalog=N'AnomalyDetection';
GO
EXEC master.dbo.sp_serveroption @server=N'ASLOCAL',
 @optname=N'collation compatible', @optvalue=N'false';
EXEC master.dbo.sp_serveroption @server=N'ASLOCAL',
 @optname=N'data access', @optvalue=N'true';
EXEC master.dbo.sp_serveroption @server=N'ASLOCAL',
 @optname=N'rpc', @optvalue=N'false';
EXEC master.dbo.sp_serveroption @server=N'ASLOCAL',
 @optname=N'rpc out', @optvalue=N'false';
EXEC master.dbo.sp_serveroption @server=N'ASLOCAL',
 @optname=N'connect timeout', @optvalue=N'0';
EXEC master.dbo.sp_serveroption @server=N'ASLOCAL',
 @optname=N'collation name', @optvalue=NULL;
EXEC master.dbo.sp_serveroption @server=N'ASLOCAL',
 @optname=N'query timeout', @optvalue=N'0';
EXEC master.dbo.sp_serveroption @server=N'ASLOCAL',
 @optname=N'use remote collation', @optvalue=N'true';
GO
EXEC master.dbo.sp_addlinkedsrvlogin @rmtsrvname = N'ASLOCAL',
 @locallogin = NULL , @useself = N'True';
GO

-- Evaluate the clustering models
USE AdventureWorksDW2012;
GO

-- See the content of a model
SELECT *
FROM OPENQUERY(ASLOCAL, 'SELECT FLATTENED * FROM TMCL10.Content');

-- Evaluate clustering models with entropy
-- Average entropy in the clusters
SELECT sql1.ModelName, 
 SUM(sql1.ClusterAttrEntropy) / 
 COUNT(DISTINCT sql1.ClusterName) AS AvgModelEntropy
FROM
(
 SELECT dmx1.ModelName, dmx1.ClusterName, dmx1.AttrName,
  SUM((-1)*dmx1.AttrProb*LOG(dmx1.AttrProb,2))
   AS ClusterAttrEntropy
 FROM
  (
   SELECT CAST(dmx.MODEL_NAME AS nvarchar(max))
           AS ModelName,
    CAST(dmx.NODE_CAPTION AS nvarchar(max))
	 AS ClusterName,
    CAST(dmx.[NODE_DISTRIBUTION.ATTRIBUTE_NAME]
	 AS nvarchar(max)) AS AttrName,
    CAST(dmx.[NODE_DISTRIBUTION.ATTRIBUTE_VALUE]
	 AS nvarchar(max)) AS AttrValue,
    dmx.[NODE_DISTRIBUTION.PROBABILITY] AS AttrProb
   FROM OPENQUERY(ASLOCAL,
    'SELECT FLATTENED MODEL_NAME, NODE_CAPTION,
	  NODE_DISTRIBUTION
     FROM TMCL05.Content
     WHERE NODE_TYPE=5') AS dmx
   WHERE dmx.[NODE_DISTRIBUTION.VALUETYPE] >= 4 AND
	     dmx.[NODE_DISTRIBUTION.PROBABILITY] > 0
   ) AS dmx1
 GROUP BY dmx1.ModelName, dmx1.ClusterName, dmx1.AttrName
	) AS sql1
GROUP BY sql1.ModelName
UNION
SELECT sql1.ModelName, 
 SUM(sql1.ClusterAttrEntropy) / 
 COUNT(DISTINCT sql1.ClusterName) AS AvgModelEntropy
FROM
(
 SELECT dmx1.ModelName, dmx1.ClusterName, dmx1.AttrName,
  SUM((-1)*dmx1.AttrProb*LOG(dmx1.AttrProb,2))
   AS ClusterAttrEntropy
 FROM
  (
   SELECT CAST(dmx.MODEL_NAME AS nvarchar(max))
           AS ModelName,
    CAST(dmx.NODE_CAPTION AS nvarchar(max))
	 AS ClusterName,
    CAST(dmx.[NODE_DISTRIBUTION.ATTRIBUTE_NAME]
	 AS nvarchar(max)) AS AttrName,
    CAST(dmx.[NODE_DISTRIBUTION.ATTRIBUTE_VALUE]
	 AS nvarchar(max)) AS AttrValue,
    dmx.[NODE_DISTRIBUTION.PROBABILITY] AS AttrProb
   FROM OPENQUERY(ASLOCAL,
	'SELECT FLATTENED MODEL_NAME, NODE_CAPTION,
	  NODE_DISTRIBUTION
     FROM TMCL10.Content
     WHERE NODE_TYPE=5') AS dmx
   WHERE dmx.[NODE_DISTRIBUTION.VALUETYPE] >= 4 AND
         dmx.[NODE_DISTRIBUTION.PROBABILITY] > 0
  ) AS dmx1
 GROUP BY dmx1.ModelName, dmx1.ClusterName, dmx1.AttrName
) AS sql1
GROUP BY sql1.ModelName
UNION
SELECT sql1.ModelName, 
 SUM(sql1.ClusterAttrEntropy) / 
 COUNT(DISTINCT sql1.ClusterName) AS AvgModelEntropy
FROM
(
 SELECT dmx1.ModelName, dmx1.ClusterName, dmx1.AttrName,
  SUM((-1)*dmx1.AttrProb*LOG(dmx1.AttrProb,2))
   AS ClusterAttrEntropy
 FROM
  (
   SELECT CAST(dmx.MODEL_NAME AS nvarchar(max))
           AS ModelName,
    CAST(dmx.NODE_CAPTION AS nvarchar(max))
	 AS ClusterName,
    CAST(dmx.[NODE_DISTRIBUTION.ATTRIBUTE_NAME]
	 AS nvarchar(max)) AS AttrName,
    CAST(dmx.[NODE_DISTRIBUTION.ATTRIBUTE_VALUE]
	 AS nvarchar(max)) AS AttrValue,
    dmx.[NODE_DISTRIBUTION.PROBABILITY] AS AttrProb
   FROM OPENQUERY(ASLOCAL,
	'SELECT FLATTENED MODEL_NAME, NODE_CAPTION,
	  NODE_DISTRIBUTION
     FROM TMCLAuto.Content
     WHERE NODE_TYPE=5') AS dmx
   WHERE dmx.[NODE_DISTRIBUTION.VALUETYPE] >= 4 AND
         dmx.[NODE_DISTRIBUTION.PROBABILITY] > 0
  ) AS dmx1
 GROUP BY dmx1.ModelName, dmx1.ClusterName, dmx1.AttrName
) AS sql1
GROUP BY sql1.ModelName
ORDER BY AvgModelEntropy;
GO
/* Comment: this method could favor solutions with many clusters. 
As long as number of clusters is small compared to number of distinct states of all input variables,
you can disregards the problem.
Otherwise, you could subtract a corrective value
corrval = LOG(corrnum)/LOG(2),
WHERE
corrnum = number of distinct states of all input variables - number of clusters.
For smaller number of clusters, you would get bigger corrnum and thus lower corrected average entropy.
You can get number of distinct states of all input variables with
SELECT COUNT(DISTINCT CHECKSUM(inpvar1, inpvar2, ..., inpvarN) FROM inputtable), like
SELECT COUNT(DISTINCT
 CHECKSUM(
  BikeBuyer
 ,CommuteDistance
 ,EnglishEducation
 ,EnglishOccupation
 ,Gender
 ,HouseOwnerFlag
 ,MaritalStatus
 ,NumberCarsOwned
 ,Region
 ,TotalChildren))
FROM vTargetMail
The correction is based on fact that if we would have as many cluster as there are
distinct states of all variables, the average entropy without the correction would be 0.
*/


-- Clean-up
USE master;
GO
EXEC master.dbo.sp_dropserver @server = N'ASLOCAL';
GO
