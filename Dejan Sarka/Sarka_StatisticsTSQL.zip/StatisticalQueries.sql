/****************************************/
/* High Performance Statistical queries */
/****************************************/

USE AdventureWorksDW2012;
GO


/* Frequencies */

-- Without OVER clause, pre-SQL2012 solution
WITH freqCTE AS
(
SELECT v.NumberCarsOwned,
 COUNT(v.NumberCarsOwned) AS AbsFreq,
 CAST(ROUND(100. * (COUNT(v.NumberCarsOwned)) /
       (SELECT COUNT(*) FROM vTargetMail), 0) AS INT) AS AbsPerc
FROM dbo.vTargetMail AS v
GROUP BY v.NumberCarsOwned
)
SELECT c1.NumberCarsOwned,
 c1.AbsFreq,
 (SELECT SUM(c2.AbsFreq)
  FROM freqCTE AS c2
  WHERE c2.NumberCarsOwned <= c1.NumberCarsOwned) AS CumFreq,
 c1.AbsPerc,
 (SELECT SUM(c2.AbsPerc)
  FROM freqCTE AS c2
  WHERE c2.NumberCarsOwned <= c1.NumberCarsOwned) AS CumPerc,
 CAST(REPLICATE('*',c1.AbsPerc) AS varchar(100)) AS Histogram
  FROM freqCTE AS c1
ORDER BY c1.NumberCarsOwned;

-- SQL2012 solution 1
WITH freqCTE AS
(
SELECT v.NumberCarsOwned,
 COUNT(v.NumberCarsOwned) AS AbsFreq,
 CAST(ROUND(100. * (COUNT(v.NumberCarsOwned)) /
       (SELECT COUNT(*) FROM vTargetMail), 0) AS INT) AS AbsPerc
FROM dbo.vTargetMail AS v
GROUP BY v.NumberCarsOwned
)
SELECT NumberCarsOwned,
 AbsFreq,
 SUM(AbsFreq) 
  OVER(ORDER BY NumberCarsOwned 
       ROWS BETWEEN UNBOUNDED PRECEDING
	    AND CURRENT ROW) AS CumFreq,
 AbsPerc,
 SUM(AbsPerc)
  OVER(ORDER BY NumberCarsOwned
       ROWS BETWEEN UNBOUNDED PRECEDING
	    AND CURRENT ROW) AS CumPerc,
 CAST(REPLICATE('*',AbsPerc) AS VARCHAR(50)) AS Histogram
FROM freqCTE
ORDER BY NumberCarsOwned;

-- SQL2012 solution 2
WITH freqCTE AS
(
SELECT NumberCarsOwned,
 ROW_NUMBER() OVER(PARTITION BY NumberCarsOwned
  ORDER BY NumberCarsOwned, CustomerKey) AS Rn_AbsFreq,
 ROW_NUMBER() OVER(
  ORDER BY NumberCarsOwned, CustomerKey) AS Rn_CumFreq,
 ROUND(100 * PERCENT_RANK()
  OVER(ORDER BY NumberCarsOwned), 0) AS Pr_AbsPerc, 
 ROUND(100 * CUME_DIST()
  OVER(ORDER BY NumberCarsOwned, CustomerKey), 0) AS Cd_CumPerc
FROM dbo.vTargetMail
)
SELECT NumberCarsOwned,
 MAX(Rn_AbsFreq) AS AbsFreq,
 MAX(Rn_CumFreq) AS CumFreq,
 MAX(Cd_CumPerc) - MAX(Pr_Absperc) AS AbsPerc,
 MAX(Cd_CumPerc) AS CumPerc,
 CAST(REPLICATE('*',MAX(Cd_CumPerc) - MAX(Pr_Absperc)) AS varchar(100)) AS Histogram
FROM freqCTE
GROUP BY NumberCarsOwned
ORDER BY NumberCarsOwned;
GO


/* Centers of a distribution */

-- Mode
SELECT TOP (1) WITH TIES Age, COUNT(*) AS Number
FROM dbo.vTargetMail
GROUP BY Age
ORDER BY COUNT(*) DESC;
GO

-- Median
-- Difference between PERCENTILE_CONT() and PERCENTILE_DISC()
IF OBJECT_ID('dbo.TestMedian','U') IS NOT NULL
  DROP TABLE dbo.TestMedian;
GO
CREATE TABLE dbo.TestMedian
(
 Val INT	NOT NULL
);
GO
INSERT INTO dbo.TestMedian (Val)
VALUES (1), (2), (3), (4);
SELECT DISTINCT			-- can also use TOP (1)
 PERCENTILE_DISC(0.5) WITHIN GROUP (ORDER BY Val) OVER () AS MedianDisc,
 PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY Val) OVER () AS MedianCont
FROM dbo.TestMedian;
GO

-- Median
SELECT DISTINCT
 PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY 1.0*Age) OVER () AS Median
FROM dbo.vTargetMail;
GO

WITH C AS
(
  SELECT 
   ROW_NUMBER() OVER(ORDER BY (SELECT NULL)) AS rownum,
   PERCENTILE_CONT(0.5) WITHIN GROUP(ORDER BY 1.0*Age) OVER() AS Median
  FROM dbo.vTargetMail
)
SELECT Median
FROM C
WHERE rownum = 1;
GO

-- step 1: compute row numbers
SELECT CustomerKey, Age,
 ROW_NUMBER() OVER(ORDER BY Age, CustomerKey) AS rna,
 ROW_NUMBER() OVER(ORDER BY Age DESC, CustomerKey DESC) AS rnd
FROM dbo.vTargetMail;

-- complete solution
WITH C AS
(
 SELECT CustomerKey, Age,
  ROW_NUMBER() OVER(ORDER BY Age, CustomerKey) AS rna,
  ROW_NUMBER() OVER(ORDER BY Age DESC, CustomerKey DESC) AS rnd
 FROM dbo.vTargetMail
)
SELECT CustomerKey, AVG(1.0 * Age) AS median
FROM C
WHERE ABS(rna - rnd) <= 1
GROUP BY CustomerKey;


-- Mean
SELECT AVG(1.0*Age) AS Mean
FROM vtargetMail;
GO

/* Spread of a distribution */

-- Range
SELECT MAX(Age) - MIN(Age) AS Range
FROM dbo.vTargetMail;
GO

-- IQR
SELECT DISTINCT
 PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY 1.0*Age) OVER () -
 PERCENTILE_CONT(0.25) WITHIN GROUP (ORDER BY 1.0*Age) OVER () AS IQR
FROM dbo.vTargetMail;
GO

-- Variance, standard deviation, coeficient of variation
SELECT Var(1.0*Age) AS Variance,
 STDEV(1.0*Age) AS StandardDeviation,
 STDEV(1.0*Age) / AVG(1.0*Age) AS CVAge,
 STDEV(1.0*YearlyIncome) / AVG(1.0*YearlyIncome) AS CVYearlyIncome
FROM dbo.vTargetMail;
GO

-- Skewness
WITH SkewCTE AS
(
SELECT SUM(1.0*Age) AS rx,
 SUM(POWER(1.0*Age,2)) AS rx2,
 SUM(POWER(1.0*Age,3)) AS rx3,
 COUNT(1.0*Age) AS rn,
 STDEV(1.0*Age) AS stdv,
 AVG(1.0*Age) AS av
FROM dbo.vTargetMail
)
SELECT
   (rx3 - 3*rx2*av + 3*rx*av*av - rn*av*av*av)
   / (stdv*stdv*stdv) * rn / (rn-1) / (rn-2) AS Skewness
FROM SkewCTE;
GO

-- Kurtosis
WITH KurtCTE AS
(
SELECT SUM(1.0*Age) AS rx,
 SUM(POWER(1.0*Age,2)) AS rx2,
 SUM(POWER(1.0*Age,3)) AS rx3,
 SUM(POWER(1.0*Age,4)) AS rx4,
 COUNT(1.0*Age) AS rn,
 STDEV(1.0*Age) AS stdv,
 AVG(1.*Age) AS av
FROM dbo.vTargetMail
)
SELECT
   (rx4 - 4*rx3*av + 6*rx2*av*av - 4*rx*av*av*av + rn*av*av*av*av)
   / (stdv*stdv*stdv*stdv) * rn * (rn+1) / (rn-1) / (rn-2) / (rn-3)
   - 3.0 * (rn-1) * (rn-1) / (rn-2) / (rn-3) AS Kurtosis
FROM KurtCTE;
GO

/* C# version for skewness and kurtosis */
/*

using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.SqlServer.Server;

[Serializable]
[SqlUserDefinedAggregate(
   Format.Native,	              
   IsInvariantToDuplicates = false, 
   IsInvariantToNulls = true,       
   IsInvariantToOrder = true,     
   IsNullIfEmpty = false)]            
public struct Skew
{
	private double rx;		// running sum of current values (x)
	private double rx2;		// running sum of squared current values (x^2)
	private double r2x;		// running sum of doubled current values (2x)
	private double rx3;		// running sum of current values raised to power 3 (x^3)
	private double r3x2;	// running sum of tripled squared current values (3x^2)
	private double r3x;		// running sum of tripled current values (3x)
	private Int64 rn;		// running count of rows
 
	public void Init()
	{
		rx = 0;
		rx2 = 0;
		r2x = 0;
		rx3 = 0;
		r3x2 = 0;
		r3x = 0;
		rn = 0;
	}

	public void Accumulate(SqlDouble inpVal)
	{
		if (inpVal.IsNull)
		{
			return;
		}
		rx = rx + inpVal.Value;
		rx2 = rx2 + Math.Pow(inpVal.Value, 2);
		r2x = r2x + 2 * inpVal.Value;
		rx3 = rx3 + Math.Pow(inpVal.Value, 3);
		r3x2 = r3x2 + 3 * Math.Pow(inpVal.Value, 2);
		r3x = r3x + 3 * inpVal.Value;
		rn = rn + 1;
	}

	public void Merge(Skew Group)
	{
		this.rx = this.rx + Group.rx;
		this.rx2 = this.rx2 + Group.rx2;
		this.r2x = this.r2x + Group.r2x;
		this.rx3 = this.rx3 + Group.rx3;
		this.r3x2 = this.r3x2 + Group.r3x2;
		this.r3x = this.r3x + Group.r3x;
		this.rn = this.rn + Group.rn;
	}

	public SqlDouble Terminate()
	{
		double myAvg = (rx / rn);
		double myStDev = Math.Pow((rx2 - r2x * myAvg + rn * Math.Pow(myAvg, 2)) / (rn - 1), 1d / 2d);
		double mySkew = (rx3 - r3x2 * myAvg + r3x * Math.Pow(myAvg, 2) - rn * Math.Pow(myAvg, 3)) /
						Math.Pow(myStDev,3) * rn / (rn - 1) / (rn - 2);
		return (SqlDouble)mySkew;
	}

}


[Serializable]
[SqlUserDefinedAggregate(
   Format.Native,
   IsInvariantToDuplicates = false,
   IsInvariantToNulls = true,
   IsInvariantToOrder = true,
   IsNullIfEmpty = false)]
public struct Kurt
{
	private double rx;		// running sum of current values (x)
	private double rx2;		// running sum of squared current values (x^2)
	private double r2x;		// running sum of doubled current values (2x)
	private double rx4;		// running sum of current values raised to power 4 (x^4)
	private double r4x3;	// running sum of quadrupled current values raised to power 3 (4x^3)
	private double r6x2;	// running sum of squared current values multiplied by 6 (6x^2)
	private double r4x;		// running sum of quadrupled current values (4x)
	private Int64 rn;		// running count of rows

	public void Init()
	{
		rx = 0;
		rx2 = 0;
		r2x = 0;
		rx4 = 0;
		r4x3 = 0;
		r6x2 = 0;
		r4x = 0;
		rn = 0;
	}

	public void Accumulate(SqlDouble inpVal)
	{
		if (inpVal.IsNull)
		{
			return;
		}
		rx = rx + inpVal.Value;
		rx2 = rx2 + Math.Pow(inpVal.Value, 2);
		r2x = r2x + 2 * inpVal.Value;
		rx4 = rx4 + Math.Pow(inpVal.Value, 4);
		r4x3 = r4x3 + 4 * Math.Pow(inpVal.Value, 3);
		r6x2 = r6x2 + 6 * Math.Pow(inpVal.Value, 2);
		r4x = r4x + 4 * inpVal.Value;
		rn = rn + 1;
	}

	public void Merge(Kurt Group)
	{
		this.rx = this.rx + Group.rx;
		this.rx2 = this.rx2 + Group.rx2;
		this.r2x = this.r2x + Group.r2x;
		this.rx4 = this.rx4 + Group.rx4;
		this.r4x3 = this.r4x3 + Group.r4x3;
		this.r6x2 = this.r6x2 + Group.r6x2;
		this.r4x = this.r4x + Group.r4x;
		this.rn = this.rn + Group.rn;
	}

	public SqlDouble Terminate()
	{
		double myAvg = (rx / rn);
		double myStDev = Math.Pow((rx2 - r2x * myAvg + rn * Math.Pow(myAvg, 2)) / (rn - 1), 1d / 2d);
		double myKurt = (rx4 - r4x3 * myAvg + r6x2 * Math.Pow(myAvg, 2) - r4x * Math.Pow(myAvg, 3) + rn * Math.Pow(myAvg, 4)) /
						Math.Pow(myStDev, 4) * rn * (rn + 1) / (rn - 1) / (rn - 2) / (rn - 3) -
						3 * Math.Pow((rn - 1), 2) / (rn - 2) / (rn - 3);
		return (SqlDouble)myKurt;
	}

}

*/
/* C# version for skewness and kurtosis */

-- Deploying CLR UDAs for skewness and kurtosis
-- Enable CLR
EXEC sp_configure 'clr enabled', 1;
RECONFIGURE WITH OVERRIDE;
GO
-- Load CS Assembly - change the path if needed
CREATE ASSEMBLY DescriptiveStatistics 
FROM 'C:\StatisticalQueries\DescriptiveStatistics.dll'
WITH PERMISSION_SET = SAFE;
GO
-- Skewness UDA
CREATE AGGREGATE dbo.Skew(@s float)
RETURNS float
EXTERNAL NAME DescriptiveStatistics.Skew;
GO
-- Kurtosis UDA
CREATE AGGREGATE dbo.Kurt(@s float)
RETURNS float
EXTERNAL NAME DescriptiveStatistics.Kurt;
GO

-- Using the UDAs
SELECT dbo.Skew(1.0*Age) AS Skewness,
 dbo.Kurt(1.0*Age) AS Kurtosis
FROM dbo.vTargetMail;
-- The first four population moments in groups
SELECT NumberCarsOwned,
 AVG(1.0*Age) AS AgeMean,
 STDEV(1.0*Age) AS AgeStandardDeviation,
 dbo.Skew(1.0*Age) AS AgeSkewness,
 dbo.Kurt(1.0*Age) AS AgeKurtosis
FROM dbo.vTargetMail
GROUP BY NumberCarsOwned;
GO


/* Linear dependencies */
/* Continuous variables */

-- Covariance, correlation coeeficient,
-- and coefficient of determination
WITH CoVarCTE AS
(
SELECT 1.0*Age as val1,
 AVG(1.0*Age) OVER () AS mean1,
 1.0*YearlyIncome AS val2,
 AVG(1.0*YearlyIncome) OVER() AS mean2
FROM dbo.vTargetMail
)
SELECT 
 SUM((val1-mean1)*(val2-mean2)) / COUNT(*) AS Covar,
 (SUM((val1-mean1)*(val2-mean2)) / COUNT(*)) /
 (STDEVP(val1) * STDEVP(val2)) AS Correl,
 SQUARE((SUM((val1-mean1)*(val2-mean2)) / COUNT(*)) /
 (STDEVP(val1) * STDEVP(val2))) AS CD
FROM CoVarCTE;
GO


/* Linear dependencies */
/* Discrete variables */

-- Chi Squared */
-- pre-SQL2012 solution
WITH
ObservedCombination_CTE AS
(
SELECT NumberCarsOwned, MaritalStatus, COUNT(*) AS Observed
FROM dbo.vTargetMail
GROUP BY NumberCarsOwned, MaritalStatus
),
ObservedFirst_CTE AS
(
SELECT NumberCarsOwned, NULL AS MaritalStatus, COUNT(*) AS Observed
FROM dbo.vTargetMail
GROUP BY NumberCarsOwned
),
ObservedSecond_CTE AS
(
SELECT NULL AS NumberCarsOwned, MaritalStatus, COUNT(*) AS Observed
FROM dbo.vTargetMail
GROUP BY MaritalStatus
),
ObservedTotal_CTE AS
(
SELECT NULL AS NumberCarsOwned, NULL AS MaritalStatus, COUNT(*) AS Observed
FROM dbo.vTargetMail
),
ExpectedCombination_CTE AS
(
SELECT F.NumberCarsOwned, S.MaritalStatus, 
 CAST(ROUND(1.0 * F.Observed * S.Observed / T.Observed, 0) AS INT) AS Expected
FROM ObservedFirst_CTE AS F
 CROSS JOIN ObservedSecond_CTE AS S
 CROSS JOIN ObservedTotal_CTE AS T
),
ObservedExpected_CTE AS
(
SELECT O.NumberCarsOwned, O.MaritalStatus, O.Observed, E.Expected
FROM ObservedCombination_CTE AS O
 INNER JOIN ExpectedCombination_CTE AS E
  ON O.NumberCarsOwned = E.NumberCarsOwned
   AND O.MaritalStatus = E.MaritalStatus
)
--SELECT * FROM ObservedExpected_CTE
SELECT SUM(SQUARE(1.0 * Observed - Expected) / Expected) AS ChiSquared,
 (COUNT(DISTINCT NumberCarsOwned) - 1) * 
 (COUNT(DISTINCT MaritalStatus) - 1) AS DegreesOfFreedom
FROM ObservedExpected_CTE;
GO

-- SQL2012 solution
WITH
ObservedCombination_CTE AS
(
SELECT NumberCarsOwned AS OnRows,
 MaritalStatus AS OnCols, 
 COUNT(*) AS ObservedCombination
FROM dbo.vTargetMail
GROUP BY NumberCarsOwned, MaritalStatus
),
ExpectedCombination_CTE AS
(
SELECT OnRows, OnCols, ObservedCombination
 ,SUM(ObservedCombination) OVER (PARTITION BY OnRows) AS ObservedOnRows
 ,SUM(ObservedCombination) OVER (PARTITION BY OnCols) AS ObservedOnCols
 ,SUM(ObservedCombination) OVER () AS ObservedTotal
 ,CAST(ROUND(SUM(1.0 * ObservedCombination) OVER (PARTITION BY OnRows)
  * SUM(1.0 * ObservedCombination) OVER (PARTITION BY OnCols) 
  / SUM(1.0 * ObservedCombination) OVER (), 0) AS INT) AS ExpectedCombination
FROM ObservedCombination_CTE
)
--SELECT * FROM ExpectedCombination_CTE
SELECT SUM(SQUARE(ObservedCombination - ExpectedCombination)
  / ExpectedCombination) AS ChiSquared,
 (COUNT(DISTINCT OnRows) - 1) * (COUNT(DISTINCT OnCols) - 1) AS DegreesOfFreedom
FROM ExpectedCombination_CTE;
GO


/* Definite integration */

-- Standard normal distribution table
CREATE TABLE #StdNormDist
(z0 DECIMAL(3,2)	NOT NULL,
 yz DECIMAL(10,9)	 NOT NULL);
GO
-- Insert the data
SET NOCOUNT ON;
GO
DECLARE @z0 DECIMAL(3,2), @yz DECIMAL(10,9);
SET @z0=-4.00;
WHILE @z0 <= 4.00
 BEGIN
  SET @yz=1.00/SQRT(2.00*PI())*EXP((-1.00/2.00)*SQUARE(@z0));
  INSERT INTO #StdNormDist(z0,yz) VALUES(@z0, @yz);
  SET @z0=@z0+0.01;
END
GO
SET NOCOUNT OFF;
GO
SELECT *
FROM #StdNormDist;
GO

-- Trapezoidal Formula for Definite Integral Approximation
-- Pct of Area between 0 and 1
WITH ZvaluesCTE AS
(
SELECT z0, yz,
  FIRST_VALUE(yz) OVER(ORDER BY z0) AS fyz,
  LAST_VALUE(yz) 
   OVER(ORDER BY z0
        ROWS BETWEEN UNBOUNDED PRECEDING
		 AND UNBOUNDED FOLLOWING) AS lyz
FROM #StdNormDist
WHERE z0 >= 0 AND z0 <= 1
)
SELECT 100.0 * ((0.01 / 2.0) * (SUM(2 * yz) - MIN(fyz) - MAX(lyz))) AS pctdistribution
FROM ZvaluesCTE;

-- Right Tail after Z >= 1.96
WITH ZvaluesCTE AS
(
SELECT z0, yz,
  FIRST_VALUE(yz) OVER(ORDER BY z0) AS fyz,
  LAST_VALUE(yz) 
   OVER(ORDER BY z0
        ROWS BETWEEN UNBOUNDED PRECEDING
		 AND UNBOUNDED FOLLOWING) AS lyz
FROM #StdNormDist
WHERE z0 >= 0 AND z0 <= 1.96
)
SELECT 50 - 100.0 * ((0.01 / 2.0) * (SUM(2 * yz) - MIN(fyz) - MAX(lyz))) AS pctdistribution
FROM ZvaluesCTE;
GO


/* Linear dependencies */
/* Discrete and Continuous variables */

-- One-way ANOVA
WITH Anova_CTE AS
(
SELECT NumberCarsOwned, YearlyIncome,
 COUNT(*) OVER (PARTITION BY NumberCarsOwned) AS gr_CasesCount,
 DENSE_RANK() OVER (ORDER BY NumberCarsOwned) AS gr_DenseRank,
 SQUARE(AVG(YearlyIncome) OVER (PARTITION BY NumberCarsOwned) -
        AVG(YearlyIncome) OVER ()) AS between_gr_SS,
 SQUARE(YearlyIncome - 
        AVG(YearlyIncome) OVER (PARTITION BY NumberCarsOwned)) 
		AS within_gr_SS
FROM dbo.vTargetMail
) 
SELECT N'Between groups' AS [Source of Variation],
 SUM(between_gr_SS) AS SS,
 (MAX(gr_DenseRank) - 1) AS df,
 SUM(between_gr_SS) / (MAX(gr_DenseRank) - 1) AS MS,
 (SUM(between_gr_SS) / (MAX(gr_DenseRank) - 1)) /
 (SUM(within_gr_SS) / (COUNT(*) - MAX(gr_DenseRank))) AS F
FROM Anova_CTE
UNION 
SELECT N'Within groups' AS [Source of Variation],
 SUM(within_gr_SS) AS SS,
 (COUNT(*) - MAX(gr_DenseRank)) AS df,
 SUM(within_gr_SS) / (COUNT(*) - MAX(gr_DenseRank)) AS MS,
 NULL AS F
FROM Anova_CTE;
-- Calculating the cumulative F
-- Turn on the SQLCMD mode
!!C:\StatisticalQueries\FDistribution 2256.21946654061 4 18479
GO

/* C# console application foR F distribution */
/*

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms.DataVisualization.Charting;

class FDistribution
{
    static void Main(string[] args)
    {
        // Test input arguments
        if (args.Length != 3)
        {
            Console.WriteLine("Please use three arguments: double FValue, int DF1, int DF2.");
            //Console.ReadLine();
            return;
        }

        // Try to convert the input arguments to numbers. 
        // FValue
        double FValue;
        bool test = double.TryParse(args[0], System.Globalization.NumberStyles.Float,
            System.Globalization.CultureInfo.InvariantCulture.NumberFormat, out FValue);
        if (test == false)
        {
            Console.WriteLine("First argument must be double (nnn.n).");
            return;
        }

        // DF1
        int DF1;
        test = int.TryParse(args[1], out DF1);
        if (test == false)
        {
            Console.WriteLine("Second argument must be int.");
            return;
        }

        // DF2
        int DF2;
        test = int.TryParse(args[2], out DF2);
        if (test == false)
        {
            Console.WriteLine("Third argument must be int.");
            return;
        }

        // Calculate the cumulative F distribution function probability
        Chart c = new Chart();
        double result = c.DataManipulator.Statistics.FDistribution(FValue, DF1, DF2);
        Console.WriteLine("Input parameters: " + 
            FValue.ToString(System.Globalization.CultureInfo.InvariantCulture.NumberFormat)
            + " " + DF1.ToString() + " " + DF2.ToString());
        Console.WriteLine("Cumulative F distribution function probability: " +
            result.ToString("P"));
    }
}

*/
/* C# console application fro F distribution */


/* Moving Averages */

-- Demo table
CREATE TABLE dbo.MAvg
(Id		INT		NOT NULL IDENTITY(1,1),
 Val	FLOAT	NULL);
GO

INSERT INTO dbo.MAvg(Val) VALUES
(1), (2), (3), (4), (1), (2), (3), (4), (1), (2);

SELECT Id, Val 
FROM dbo.MAvg
ORDER BY ID;
GO

-- Simple - last 3 values
SELECT Id, Val,
 AVG(Val)
 OVER (ORDER BY ID 
       ROWS BETWEEN 2 PRECEDING
	     AND CURRENT ROW) AS SMA
FROM dbo.MAvg
ORDER BY Id;
GO

-- Weighted  - last 2 values
DECLARE  @A AS FLOAT;
SET @A = 0.7;
SELECT Id, Val,
 ISNULL((LAG(Val) OVER (ORDER BY Id)), Val) AS PrevVal,
 @A * Val + (1 - @A) *
  ISNULL((LAG(Val) OVER (ORDER BY Id)), Val)  AS WMA
FROM dbo.MAvg
ORDER BY Id;
GO

-- Exponential - cursor
DECLARE @CurrentEMA AS FLOAT, @PreviousEMA AS FLOAT, 
 @Id AS INT, @Val AS FLOAT,
 @A AS FLOAT;
DECLARE @Results AS TABLE(Id INT, Val FLOAT, EMA FLOAT);
SET @A = 0.7;

DECLARE EMACursor CURSOR FOR 
SELECT Id, Val 
FROM dbo.MAvg
ORDER BY Id;

OPEN EMACursor;

FETCH NEXT FROM EMACursor 
 INTO @Id, @Val;
SET @CurrentEMA = @Val;
SET @PreviousEMA = @CurrentEMA;

WHILE @@FETCH_STATUS = 0
BEGIN
 SET @CurrentEMA = @A*@Val + (1-@A)*@PreviousEMA;
 INSERT INTO @Results (Id, Val, EMA)
  VALUES(@Id, @Val, @CurrentEMA);
  SET @PreviousEMA = @CurrentEMA;
 FETCH NEXT FROM EMACursor 
  INTO @Id, @Val;
END;

CLOSE EMACursor;
DEALLOCATE EMACursor;

SELECT Id, Val, EMA
FROM @Results;
GO

-- Exponential - Join + Window functions
-- Using the transformed EMA formula
DECLARE  @A AS FLOAT;
SET @A = 0.7;
WITH RnCTE AS
(
SELECT Id, Val,
 ROW_NUMBER() OVER(ORDER BY Id) AS RN,
 FIRST_VALUE(Val) OVER (ORDER BY Id) AS V1
FROM dbo.MAvg
),
MaCTE AS
(
SELECT RN1.Id AS Id, Rn1.RN AS RN1, Rn2.RN AS RN2, 
 Rn1.V1, Rn1.Val AS YI1, Rn2.Val AS YI2,
 MAX(RN2.RN) OVER (PARTITION BY RN1.RN) AS TRC
FROM RnCTE AS Rn1
 INNER JOIN RnCTE AS Rn2
  ON Rn1.RN >= Rn2.Rn
)
SELECT Id, MAX(YI1) AS YI,
 ROUND(
 SUM(@A * POWER((1 - @A), (RN1 - RN2)) * YI2)
 +
 MAX(POWER((1 - @A), (TRC - 1)))
 ,7) AS EMA
FROM MaCTE
WHERE RN2 > 1
GROUP BY ID
UNION
SELECT 1, 1, 1
ORDER BY Id;
GO

-- Recursive CTE
DECLARE  @A AS FLOAT;
SET @A = 0.7;
WITH RnCTE AS
(
SELECT Id, Val,
 ROW_NUMBER() OVER(ORDER BY Id) AS RN
FROM dbo.MAvg
),
EMACTE AS
(
  SELECT Id, RN, Val, Val AS EMA
  FROM RnCTE
  WHERE id = 1

  UNION ALL

  SELECT C.Id, C.RN, C.Val, 
   @A * C.Val + (1 - @A) * P.EMA AS EMA
  FROM EMACTE AS P
   INNER JOIN RnCTE AS C
      ON C.RN = P.RN + 1
)
SELECT * 
FROM EMACTE;
GO

-- Exponential MA - Quintin du Bruyn Solution
DECLARE @A AS FLOAT = 0.7, @B AS FLOAT;
SET @B = 1 - @A; 
WITH cte_cnt AS
(
SELECT id, val,
  ROW_NUMBER() OVER (ORDER BY id) - 1 as exponent 
FROM dbo.MAvg 
) 
SELECT id, val, 
 ROUND(
  SUM(CASE WHEN exponent=0 THEN 1 
           ELSE @A 
	  END * val * POWER(@B, -exponent))
  OVER (ORDER BY id) * POWER(@B, exponent)
 , 2) AS EMA 
FROM cte_cnt; 
GO

-- Clean-up
DROP TABLE dbo.TestMedian;
DROP AGGREGATE dbo.Skew;
DROP AGGREGATE dbo.Kurt;
DROP ASSEMBLY DescriptiveStatistics;
EXEC sp_configure 'clr enabled', 0;
RECONFIGURE WITH OVERRIDE;
DROP TABLE #StdNormDist;
DROP TABLE dbo.MAvg;
GO
