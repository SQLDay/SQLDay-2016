-- Identity Mapping and De-Duplicating
-- Demos

/*********/
/* SETUP */
/*********/
USE DQS_STAGING_DATA;
GO

-- Creating the table for clean data
IF OBJECT_ID(N'dbo.CustomersClean', N'U') IS NOT NULL
   DROP TABLE dbo.CustomersClean;
GO
CREATE TABLE dbo.CustomersClean
(
 CustomerKey   INT           NOT NULL PRIMARY KEY,
 FullName      NVARCHAR(200) NULL,
 StreetAddress NVARCHAR(200) NULL
);
GO

-- Populating the clean data table
INSERT INTO dbo.CustomersClean
 (CustomerKey, FullName, StreetAddress)
SELECT CustomerKey,
 FirstName + ' ' + LastName AS FullName,
 AddressLine1 AS StreetAddress
FROM AdventureWorksDW2012.dbo.DimCustomer
WHERE CustomerKey % 10 = 0;
GO        

-- Creating and populating the table for dirty data
IF OBJECT_ID(N'dbo.CustomersDirty', N'U') IS NOT NULL
   DROP TABLE dbo.CustomersDirty;
GO
CREATE TABLE dbo.CustomersDirty
(
 CustomerKey      INT           NOT NULL PRIMARY KEY,
 FullName         NVARCHAR(200) NULL,
 StreetAddress    NVARCHAR(200) NULL,
 Updated          INT           NULL,
 CleanCustomerKey INT           NULL
);
GO
INSERT INTO dbo.CustomersDirty
 (CustomerKey, FullName, StreetAddress, Updated)
SELECT CustomerKey * (-1) AS CustomerKey,
 FirstName + ' ' + LastName AS FullName,
 AddressLine1 AS StreetAddress,
 0 AS Updated
FROM AdventureWorksDW2012.dbo.DimCustomer
WHERE CustomerKey % 10 = 0;
GO   

-- Making random changes in the dirty table
DECLARE @i AS INT = 0, @j AS INT = 0;
WHILE (@i < 3)      -- loop more times for more changes
BEGIN
 SET @i += 1;
 SET @j = @i - 2;   -- control here in which step you want to update
                    -- only already updated rows
 WITH RandomNumbersCTE AS
 (
  SELECT  CustomerKey
         ,RAND(CHECKSUM(NEWID()) % 1000000000 + CustomerKey) AS RandomNumber1
         ,RAND(CHECKSUM(NEWID()) % 1000000000 + CustomerKey) AS RandomNumber2  
         ,RAND(CHECKSUM(NEWID()) % 1000000000 + CustomerKey) AS RandomNumber3                      
         ,FullName
         ,StreetAddress
         ,Updated
    FROM dbo.CustomersDirty 
 )    
 UPDATE RandomNumbersCTE SET
         FullName =
         STUFF(FullName,
               CAST(CEILING(RandomNumber1 * LEN(FullName)) AS INT),
               1,
               CHAR(CEILING(RandomNumber2 * 26) + 96))
        ,StreetAddress = 
         STUFF(StreetAddress,
               CAST(CEILING(RandomNumber1 * LEN(StreetAddress)) AS INT),
               2, '')                              
        ,Updated = Updated + 1
  WHERE RAND(CHECKSUM(NEWID()) % 1000000000 - CustomerKey) < 0.17
        AND Updated > @j;
 WITH RandomNumbersCTE AS
 (
  SELECT  CustomerKey
         ,RAND(CHECKSUM(NEWID()) % 1000000000 + CustomerKey) AS RandomNumber1
         ,RAND(CHECKSUM(NEWID()) % 1000000000 + CustomerKey) AS RandomNumber2 
         ,RAND(CHECKSUM(NEWID()) % 1000000000 + CustomerKey) AS RandomNumber3                   
         ,FullName
         ,StreetAddress
		 ,Updated
    FROM dbo.CustomersDirty 
 )    
 UPDATE RandomNumbersCTE SET
         FullName =
         STUFF(FullName, CAST(CEILING(RandomNumber1 * LEN(FullName)) AS INT),
               0,
               CHAR(CEILING(RandomNumber2 * 26) + 96))
        ,StreetAddress = 
         STUFF(StreetAddress,
               CAST(CEILING(RandomNumber1 * LEN(StreetAddress)) AS INT),
               2,
               CHAR(CEILING(RandomNumber2 * 26) + 96) + 
               CHAR(CEILING(RandomNumber3 * 26) + 96))  
        ,Updated = Updated + 1                                                               
  WHERE RAND(CHECKSUM(NEWID()) % 1000000000 - CustomerKey) < 0.17
        AND Updated > @j;
 WITH RandomNumbersCTE AS
 (
  SELECT  CustomerKey
         ,RAND(CHECKSUM(NEWID()) % 1000000000 + CustomerKey) AS RandomNumber1
         ,RAND(CHECKSUM(NEWID()) % 1000000000 + CustomerKey) AS RandomNumber2 
         ,RAND(CHECKSUM(NEWID()) % 1000000000 + CustomerKey) AS RandomNumber3                   
         ,FullName
         ,StreetAddress
         ,Updated
    FROM dbo.CustomersDirty
 )    
 UPDATE RandomNumbersCTE SET
         FullName =
         STUFF(FullName,
               CAST(CEILING(RandomNumber1 * LEN(FullName)) AS INT),
               1, '')
        ,StreetAddress = 
         STUFF(StreetAddress,
               CAST(CEILING(RandomNumber1 * LEN(StreetAddress)) AS INT),
               0,
               CHAR(CEILING(RandomNumber2 * 26) + 96) + 
               CHAR(CEILING(RandomNumber3 * 26) + 96))                           
        ,Updated = Updated + 1               
  WHERE RAND(CHECKSUM(NEWID()) % 1000000000 - CustomerKey) < 0.16
        AND Updated > @j;
END;
GO

-- Checking the data after changes
SELECT  C.FullName
       ,D.FullName
       ,C.StreetAddress
       ,D.StreetAddress
       ,D.Updated
  FROM dbo.CustomersClean AS C
       INNER JOIN dbo.CustomersDirty AS D
        ON C.CustomerKey = D.CustomerKey * (-1)
 WHERE C.FullName <> D.FullName
       OR C.StreetAddress <> D.StreetAddress
ORDER BY D.Updated DESC;
GO       

-- Exact match - Lookup transformation match output
CREATE TABLE dbo.CustomersDirtyMatch
(
 CustomerKey              INT            NOT NULL PRIMARY KEY,
 FullName                 NVARCHAR(200)  NULL,
 StreetAddress            NVARCHAR(200)  NULL,
 Updated                  INT            NULL,
 CleanCustomerKey         INT            NULL,
);
GO

-- No match - Lookup transformation no match output
CREATE TABLE dbo.CustomersDirtyNoMatch
(
 CustomerKey              INT            NOT NULL PRIMARY KEY,
 FullName                 NVARCHAR(200)  NULL,
 StreetAddress            NVARCHAR(200)  NULL,
 Updated                  INT            NULL,
 CleanCustomerKey         INT            NULL,
);
GO

-- Table that unions clean and dirty customer data
-- DQS matching actually means de-duplicating 
SELECT CustomerKey, FullName, StreetAddress
INTO dbo.CustomersDQSMatch
FROM dbo.CustomersClean
UNION
SELECT CustomerKey, FullName, StreetAddress 
FROM dbo.CustomersDirtyNoMatch;
GO

-- Table for Fuzzy Lookup matches
IF OBJECT_ID(N'dbo.FuzzyMatchingResults', N'U') IS NOT NULL
   DROP TABLE dbo.FuzzyMatchingResults;
GO
CREATE TABLE dbo.FuzzyMatchingResults 
(
 CustomerKey               INT            NOT NULL PRIMARY KEY,
 FullName                  NVARCHAR(200)  NULL,
 StreetAddress             NVARCHAR(200)  NULL,
 Updated                   INT            NULL,
 CleanCustomerKey          INT            NULL
);
GO

/*
Run the Starter package
*/

/* Check the view data
SELECT * FROM dbo.CustomersDQSMatch;
*/

/* 
Truncate the tables if needed to restart the SSIS package
TRUNCATE TABLE dbo.CustomersDirtyMatch;
TRUNCATE TABLE dbo.CustomersDirtyNoMatch;
TRUNCATE TABLE dbo.FuzzyMatchingResults;
*/

-- Import the AWCustomersMatching DQS knowledge base
-- learn the matching using the dbo.CustomersDQSMatch view

-- Run a DQS matching project using the dbo.CustomersDQSMatch view
-- Export the results to the DQSMatchingResults and DQSSurvivorshipResults tables

/* Check the matching and survivorship results
SELECT * FROM dbo.DQSMatchingResults;
SELECT * FROM dbo.DQSSurvivorshipResults;
*/
-- Measuring the results - matching
SELECT COALESCE(CLUSTER_ID, 0) AS CLUSTER_ID, 
       SUM(CustomerKey) AS SumCustomerKey,   -- Should be 0
	   COUNT(*) AS NumberOfCustomers         -- Should be 2
  FROM dbo.DQSMatchingResults
GROUP BY COALESCE(CLUSTER_ID, 0)
ORDER BY NumberOfCustomers DESC;
-- When matched, matched correctly
-- However, many not matched

-- Measuring the results - survivorship
WITH SurvivorshipGrouped AS
(
SELECT (SIGN(CustomerKey) * CustomerKey) AS CustomerKey,
       COUNT(*) AS NumberOfCustomers
  FROM dbo.DQSSurvivorshipResults
GROUP BY (SIGN(CustomerKey) * CustomerKey) 
)
SELECT COUNT(*) AS NotMatched
  FROM SurvivorshipGrouped
 WHERE NumberOfCustomers = 2;
-- Many not matched 
-- SELECT * FROM dbo.DQSSurvivorshipResults
WITH SurvivorshipGrouped AS
(
SELECT (SIGN(CustomerKey) * CustomerKey) AS CustomerKey,
       COUNT(*) AS NumberOfCustomers
  FROM dbo.DQSSurvivorshipResults
GROUP BY (SIGN(CustomerKey) * CustomerKey) 
),
SurvivorsWithNegativeCustomerId AS
(
SELECT CustomerKey
  FROM dbo.DQSSurvivorshipResults AS t
 WHERE CustomerKey < 0
)
SELECT COUNT(*)
  FROM dbo.DQSSurvivorshipResults AS n
       INNER JOIN SurvivorshipGrouped AS g
	    ON (-1) * n.CustomerKey = g.CustomerKey;
GO
-- Many wrong survivors

-- Testing Fuzzy Lookup
-- Run the FuzzyMatching package

-- Check the Fuzzy Lookup results
-- Not matched
SELECT * FROM dbo.FuzzyMatchingResults
WHERE CleanCustomerKey IS NULL;
-- Incorrect matches
SELECT * FROM dbo.FuzzyMatchingResults
WHERE CleanCustomerKey <> CustomerKey * (-1);
GO

-- MDS functions and custom algorithm
USE MDS_SolidQ;
GO

-- Creating the table for clean data
IF OBJECT_ID(N'dbo.CustomersClean', N'U') IS NOT NULL
   DROP TABLE dbo.CustomersClean;
GO
CREATE TABLE dbo.CustomersClean
(
 CustomerKey   INT           NOT NULL PRIMARY KEY,
 FullName      NVARCHAR(200) NULL,
 StreetAddress NVARCHAR(200) NULL
);
GO

-- Populating the clean data table
INSERT INTO dbo.CustomersClean
 (CustomerKey, FullName, StreetAddress)
SELECT CustomerKey,
 FullName,
 StreetAddress
FROM DQS_STAGING_DATA.dbo.CustomersClean;
GO        

-- Creating and populating the table for dirty data
IF OBJECT_ID(N'dbo.CustomersDirty', N'U') IS NOT NULL
   DROP TABLE dbo.CustomersDirty;
GO
CREATE TABLE dbo.CustomersDirty
(
 CustomerKey      INT           NOT NULL PRIMARY KEY,
 FullName         NVARCHAR(200) NULL,
 StreetAddress    NVARCHAR(200) NULL,
 Updated          INT           NULL,
 CleanCustomerKey INT           NULL
);
GO

-- Populating the dirty data table
INSERT INTO dbo.CustomersDirty
 (CustomerKey, FullName, StreetAddress, Updated)
SELECT CustomerKey,
 FullName,
 StreetAddress,
 Updated
FROM DQS_STAGING_DATA.dbo.CustomersDirty;
GO   

-- Checking the data after changes
SELECT  C.FullName
       ,D.FullName
       ,C.StreetAddress
       ,D.StreetAddress
       ,D.Updated
  FROM dbo.CustomersClean AS C
       INNER JOIN dbo.CustomersDirty AS D
        ON C.CustomerKey = D.CustomerKey * (-1)
 WHERE C.FullName <> D.FullName
       OR C.StreetAddress <> D.StreetAddress
ORDER BY D.Updated DESC;
GO       

-- Checking the similarity of FullName with 
-- MDS string similarity functions and JWSN
SELECT  m.CustomerKey
       ,m.FullName
       ,t.FullName
       ,mdq.Similarity(m.FullName, t.Fullname, 0, 0.85, 0.00) AS Levenshtein 
       ,mdq.Similarity(m.FullName, t.Fullname, 1, 0.85, 0.00) AS Jaccard 
       ,mdq.Similarity(m.FullName, t.Fullname, 2, 0.85, 0.00) AS JaroWinkler 
       ,mdq.Similarity(m.FullName, t.Fullname, 3, 0.85, 0.00) AS Simil 
	   ,(mdq.Similarity(m.FullName, t.Fullname, 2, 0.85, 0.00) *
	     mdq.Similarity(m.FullName, t.Fullname, 3, 0.85, 0.00)) /
	    ((mdq.Similarity(m.FullName, t.Fullname, 2, 0.85, 0.00) *
	      mdq.Similarity(m.FullName, t.Fullname, 3, 0.85, 0.00)) +
	    ((1 - mdq.Similarity(m.FullName, t.Fullname, 2, 0.85, 0.00)) *
	     (1 - mdq.Similarity(m.FullName, t.Fullname, 3, 0.85, 0.00))))
        AS JWSN          -- Jaro-Winkler * Simil Normalized
  FROM dbo.CustomersClean AS m
       INNER JOIN dbo.CustomersDirty AS t
        ON m.CustomerKey = t.CustomerKey * (-1)    
ORDER BY JWSN;
GO

-- Checking the similarity of StreetAddress with 
-- MDS string similarity functions and JWSN
SELECT  m.CustomerKey
       ,m.StreetAddress
       ,t.StreetAddress
       ,mdq.Similarity(m.StreetAddress, t.StreetAddress, 0, 0.85, 0.00)
	     AS Levenshtein 
       ,mdq.Similarity(m.StreetAddress, t.StreetAddress, 1, 0.85, 0.00)
	     AS Jaccard 
       ,mdq.Similarity(m.StreetAddress, t.StreetAddress, 2, 0.85, 0.00)
	     AS JaroWinkler 
       ,mdq.Similarity(m.StreetAddress, t.StreetAddress, 3, 0.85, 0.00)
	     AS Simil 
	   ,(mdq.Similarity(m.StreetAddress, t.StreetAddress, 2, 0.85, 0.00) *
	     mdq.Similarity(m.StreetAddress, t.StreetAddress, 3, 0.85, 0.00)) /
	    ((mdq.Similarity(m.StreetAddress, t.StreetAddress, 2, 0.85, 0.00) *
	      mdq.Similarity(m.StreetAddress, t.StreetAddress, 3, 0.85, 0.00)) +
	    ((1 - mdq.Similarity(m.StreetAddress, t.StreetAddress, 2, 0.85, 0.00)) *
	     (1 - mdq.Similarity(m.StreetAddress, t.StreetAddress, 3, 0.85, 0.00))))
         AS JWSN          -- Jaro-Winkler * Simil Normalized
  FROM dbo.CustomersClean AS m
       INNER JOIN dbo.CustomersDirty AS t
        ON m.CustomerKey = t.CustomerKey * (-1)    
ORDER BY JWSN;
GO

-- Show the NGrams for the CustomersClean table
SELECT  m.CustomerKey
       ,m.FullName + m.StreetAddress AS NameAddress
       ,g.Token
FROM dbo.CustomersClean AS m
     CROSS APPLY (SELECT Token, Sequence
                  FROM mdq.NGrams(UPPER(m.FullName + 
                                        m.StreetAddress), 4, 0)) AS g
WHERE CHARINDEX('', g.Token) = 0
 AND CHARINDEX('', g.Token) = 0;
GO

-- Store NGrams for CustomersClean
IF OBJECT_ID(N'dbo.CustomersCleanNGrams', N'U') IS NOT NULL
   DROP TABLE dbo.CustomersCleanNGrams;
GO
CREATE TABLE dbo.CustomersCleanNGrams
(
 CustomerKey int NOT NULL,
 Token char(4) NOT NULL
 PRIMARY KEY (Token, CustomerKey)
);
GO
INSERT INTO dbo.CustomersCleanNGrams
SELECT DISTINCT   -- Store one NGram for one customer only once
  m.CustomerKey
 ,g.Token
FROM dbo.CustomersClean AS m
     CROSS APPLY (SELECT Token, Sequence
                  FROM mdq.NGrams(
				   UPPER(m.FullName + 
                         m.StreetAddress), 4, 0)) AS g  -- parameter n
WHERE CHARINDEX('', g.Token) = 0
 AND CHARINDEX('', g.Token) = 0;
-- Check the NGrams
SELECT *
  FROM dbo.CustomersCleanNGrams;
GO  

-- Store NGrams frequency for CustomersClean
IF OBJECT_ID(N'dbo.CustomersCleanNGramsFrequency', N'U') IS NOT NULL
   DROP TABLE dbo.CustomersCleanNGramsFrequency;
GO
CREATE TABLE dbo.CustomersCleanNGramsFrequency
(
 Token char(4) NOT NULL,
 Cnt int NOT NULL,
 RowNo int NOT NULL
 PRIMARY KEY (Token)
);
GO
INSERT INTO dbo.CustomersCleanNGramsFrequency
SELECT  Token
       ,COUNT(*) AS Cnt
       ,ROW_NUMBER() OVER(ORDER BY COUNT(*)) AS RowNo
  FROM dbo.CustomersCleanNGrams
GROUP BY Token;
-- Check the NGrams frequency
SELECT *
FROM dbo.CustomersCleanNGramsFrequency
ORDER BY RowNo DESC;
GO
-- Check space
EXEC sp_spaceused 'dbo.CustomersClean';
EXEC sp_spaceused 'dbo.CustomersDirty';
EXEC sp_spaceused 'dbo.CustomersCleanNGrams';
EXEC sp_spaceused 'dbo.CustomersCleanNGramsFrequency';
GO

-- Merging IDs using filtering techique to reduce the search space

/* Reset MasterCustomerId if needed
UPDATE dbo.CustomersDirty
   SET CleanCustomerKey = NULL;
GO
*/

-- 1. step: exact matches
WITH Matches AS
(
SELECT  t.CleanCustomerKey
       ,m.CustomerKey AS MCid
       ,t.CustomerKey AS TCid
  FROM dbo.CustomersDirty AS t
       INNER JOIN dbo.CustomersClean AS m
        ON t.FullName = m.FullName
           AND t.StreetAddress = m.StreetAddress
)
UPDATE Matches
   SET CleanCustomerKey = MCid;

-- Check after exact matches
SELECT *
FROM dbo.CustomersDirty;
GO

-- Step 2: match those who have at least two identical
-- uncommon NGrams and JWSN above threshold

-- This part is for checking efficiency only
-- Variables to store the number of rows updated in this pass
-- and number of rows to update start time
DECLARE @RowsUpdated AS int,
 @RowsToUpdate AS int,
 @StartTime AS datetime;
SET @RowsToUpdate = 
 (SELECT COUNT(*) FROM dbo.CustomersDirty
  WHERE CleanCustomerKey IS NULL);
SET @StartTime = GETDATE();
-- Tokenize target table rows
WITH CustomersDirtyNGrams AS
(
SELECT  t.CustomerKey AS TCid
       ,g.Token AS TToken
       ,t.CleanCustomerKey
  FROM dbo.CustomersDirty AS t
       CROSS APPLY (SELECT Token, Sequence
                    FROM mdq.NGrams(
					 UPPER(t.FullName + 
                     t.StreetAddress), 4, 0)) AS g  -- parameter n
 WHERE t.CleanCustomerKey IS NULL
       AND CHARINDEX('', g.Token) = 0
       AND CHARINDEX('', g.Token) = 0
),
-- Target rows with 4grams with absolute frequency less or equal 50
NGramsMatch1 AS
(
SELECT  tg.TCid
       ,tg.CleanCustomerKey
       ,mg.Customerkey AS MCid
       ,tg.TToken
       ,f.Cnt
  FROM CustomersDirtyNGrams AS tg
       INNER JOIN dbo.CustomersCleanNGramsFrequency AS f
        ON tg.TToken = f.Token
           AND f.Cnt <= 50                          -- parameter p
       INNER JOIN dbo.CustomersCleanNGrams AS mg
        ON f.Token = mg.Token     
),
-- Matches that have at least two less frequent 4Grams in common 
NGramsMatch2 AS
(
SELECT  TCid
       ,MCid
       ,COUNT(*) AS NMatches
  FROM NGramsMatch1
GROUP BY TCid, MCid
HAVING COUNT(*) >= 2                                -- parameter m
),
-- Adding JWSN Coefficient and row number
NGramsMatch3 AS
(
SELECT  t.CustomerKey AS TCid
       ,m.CustomerKey AS MCid
       ,t.CleanCustomerKey
	   ,(mdq.Similarity(
	       m.FullName + m.StreetAddress,
	       t.FullName + t.StreetAddress, 2, 0.85, 0.00) *
	     mdq.Similarity(
		   m.FullName + m.StreetAddress,
		   t.FullName + t.StreetAddress, 3, 0.85, 0.00)) /
	    ((mdq.Similarity(
		    m.FullName + m.StreetAddress,
			t.FullName + t.StreetAddress, 2, 0.85, 0.00) *
	      mdq.Similarity(
		    m.FullName + m.StreetAddress, 
			t.FullName + t.StreetAddress, 3, 0.85, 0.00)) +
	    ((1 - mdq.Similarity(
		        m.FullName + m.StreetAddress,
				t.FullName + t.StreetAddress, 2, 0.85, 0.00)) *
	     (1 - mdq.Similarity(
		        m.FullName + m.StreetAddress, 
				t.FullName + t.StreetAddress, 3, 0.85, 0.00))))
        AS JWSN          -- Jaro-Winkler * Simil Normalized
       ,ROW_NUMBER() OVER (PARTITION BY t.CustomerKey ORDER BY
	    (mdq.Similarity(
		   m.FullName + m.StreetAddress, 
		   t.FullName + t.StreetAddress, 2, 0.85, 0.00) *
	     mdq.Similarity(
		   m.FullName + m.StreetAddress, 
		   t.FullName + t.StreetAddress, 3, 0.85, 0.00)) /
	    ((mdq.Similarity(
		    m.FullName + m.StreetAddress, 
			t.FullName + t.StreetAddress, 2, 0.85, 0.00) *
	      mdq.Similarity(
		    m.FullName + m.StreetAddress, 
			t.FullName + t.StreetAddress, 3, 0.85, 0.00)) +
	    ((1 - mdq.Similarity(
		        m.FullName + m.StreetAddress, 
				t.FullName + t.StreetAddress, 2, 0.85, 0.00)) *
	     (1 - mdq.Similarity(
		        m.FullName + m.StreetAddress, 
				t.FullName + t.StreetAddress, 3, 0.85, 0.00))))
        DESC)  AS RowNo
       ,ngm2.NMatches
  FROM NGramsMatch2 AS ngm2
       INNER JOIN dbo.CustomersDirty AS t
        ON ngm2.TCid = t.CustomerKey
       INNER JOIN dbo.CustomersClean AS m
        ON ngm2.MCid = m.CustomerKey
)
-- Check visually matches and errors
--SELECT MciD + TCid AS IdDiff, *
--  FROM NGramsMatch3
-- WHERE RowNo = 1
--       AND JWSN > 0.80
--ORDER BY IdDiff DESC;
-- Actual update
UPDATE NGramsMatch3 
   SET CleanCustomerKey = MCid
 WHERE RowNo = 1
       AND JWSN > 0.80;                             -- parameter q
-- Measuring the efficiency
SET @RowsUpdated = @@ROWCOUNT;
SELECT  @RowsUpdated AS RowsUpdated
       ,100.0 * @RowsUpdated / 
	    @RowsToUpdate AS PctUpdated
       ,COUNT(*) AS NumErrors
       ,100.0 * COUNT(*) / @RowsUpdated AS PctErrors
       ,DATEDIFF(MS, @StartTime, GETDATE()) AS TimeElapsedMiliseconds
  FROM dbo.CustomersDirty
 WHERE CleanCustomerKey <> CustomerKey * (-1);
GO


-- Clean up
USE DQS_STAGING_DATA;
GO
DROP TABLE dbo.CustomersClean;
DROP TABLE dbo.CustomersDirty;
DROP TABLE dbo.CustomersDirtyMatch;
DROP TABLE dbo.CustomersDirtyNoMatch;
DROP TABLE dbo.FuzzyMatchingResults;
DROP TABLE dbo.DQSMatchingResults;
DROP TABLE dbo.DQSSurvivorshipResults;
DROP TABLE dbo.CustomersDQSMatch;
GO
USE MDS_SolidQ;
GO
DROP TABLE dbo.CustomersClean;
DROP TABLE dbo.CustomersDirty;
DROP TABLE CustomersCleanNGrams;
DROP TABLE dbo.CustomersCleanNGramsFrequency;
GO

