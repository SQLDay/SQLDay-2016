﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CustomApplicationWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnPaginatedReportClick(object sender, RoutedEventArgs e)
        {
            this.ReportWeBrowser.Source = new Uri(@"http://localhost/Reports/report/SSRS_TIPS_AND_TRICKS/NatualSearchUsingFullTextSearch");
        }

        private void btn_PaginatedReprotHide_Click(object sender, RoutedEventArgs e)
        {
            this.ReportWeBrowser.Source = new Uri(@"http://localhost/Reports/report/SSRS_TIPS_AND_TRICKS/NatualSearchUsingFullTextSearch" + "?rs:Embed=true");
        }

        private void btn_PaginatedReprotHideFull_Click(object sender, RoutedEventArgs e)
        {
            this.ReportWeBrowser.Source = new Uri(@"http://localhost/Reports/report/SSRS_TIPS_AND_TRICKS/NatualSearchUsingFullTextSearch" + "?rs:Embed=true&rc:Parameters=false&rc:Toolbar=false");
        }

        private void btnMobileReprotClick(object sender, RoutedEventArgs e)
        {
            this.ReportWeBrowser.Source = new Uri(@"http://localhost/Reports/mobilereport/New%20Mobile%20Report");
        }

        private void tn_MobileReportsEmbed_Click(object sender, RoutedEventArgs e)
        {
            this.ReportWeBrowser.Source = new Uri(@"http://localhost/Reports/mobilereport/New%20Mobile%20Report" + "?rs:Embed=true");
        }

        private void btn_PaginatedReprotHideFullParameter_Click(object sender, RoutedEventArgs e)
        {
            
            this.ReportWeBrowser.Source = new Uri(@"http://localhost/Reports/report/SSRS_TIPS_AND_TRICKS/NatualSearchUsingFullTextSearch" + "?Products=" + this.txtBox_Param.Text + "&rs:Embed=true&rc:Parameters=false&rc:Toolbar=false?Products=%22gloves%22");
        }

        private void tn_MobileReportsEmedParam_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
