USE TempTableAndTableVariable
GO

DROP FUNCTION IF EXISTS dbo.Func
GO

-- Temporary Table
CREATE FUNCTION dbo.Func()
RETURNS @Return TABLE (Name nvarchar(max))
AS
BEGIN
    CREATE TABLE #TemporaryTable (Name nvarchar(max));
    INSERT INTO #TemporaryTable (Name) VALUES ('TemporaryTable');
    
    INSERT INTO @Return (Name)
    SELECT Name
    FROM #TemporaryTable;
    
    RETURN;
END
GO

-- Table Variable
DROP FUNCTION IF EXISTS dbo.Func
GO

CREATE FUNCTION dbo.Func()
RETURNS @Return TABLE (Name nvarchar(max))
AS
BEGIN
    DECLARE @TableVariable TABLE (Name nvarchar(max));
    INSERT INTO @TableVariable (Name) VALUES ('Func');
    
    INSERT INTO @Return (Name)
    SELECT Name
    FROM @TableVariable;
    
    RETURN;
END
GO

SELECT * FROM dbo.Func();

DROP FUNCTION dbo.Func

-- Table Variable Type
DROP FUNCTION IF EXISTS dbo.Func
GO
DROP TYPE IF EXISTS dbo.TableVariableType
GO

CREATE TYPE TableVariableType AS TABLE (Name nvarchar(max) NOT NULL);
GO

-- Table Variable Type - in function
DROP FUNCTION IF EXISTS dbo.Func
GO

CREATE FUNCTION dbo.Func(@TableVariable TableVariableType READONLY)
RETURNS @Return TABLE (Name nvarchar(max))
AS
BEGIN
	DECLARE @Tmp TableVariableType;

	INSERT INTO @Tmp (Name)
	SELECT
		Name
	FROM @TableVariable
	UNION
	SELECT
		Name + SPACE(1) + 'Lite'
	FROM @TableVariable

	INSERT INTO @Return
	SELECT Name FROM @Tmp

    RETURN;
END
GO

DECLARE @TableVariable TableVariableType;

INSERT INTO @TableVariable (Name) VALUES ('SQL Day 2016')

SELECT * FROM dbo.Func(@TableVariable);
GO

DROP FUNCTION dbo.Func;