USE TempTableAndTableVariable
GO

/*
	Declaration
*/


-- Temporary Table
CREATE TABLE #TemporaryTable (Col nvarchar(max));

INSERT INTO #TemporaryTable (Col) VALUES ('A'), ('B');

SELECT * FROM #TemporaryTable AS TT

UPDATE TT SET Col = 'C' FROM #TemporaryTable AS TT

SELECT * FROM #TemporaryTable AS TT

DELETE TT FROM #TemporaryTable AS TT

DROP TABLE #TemporaryTable


-- Table Variable
DECLARE @TableVariable TABLE (Col nvarchar(max));

INSERT INTO @TableVariable(Col) VALUES ('A'), ('B');

SELECT * FROM @TableVariable AS TV

UPDATE TV SET Col = 'C' FROM @TableVariable AS TV

SELECT * FROM @TableVariable AS TV

DELETE TV FROM @TableVariable AS TV
GO

/*
	SELECT ... INTO
*/

-- Temporary Table
SELECT *
	INTO #TemporaryTable
FROM sys.objects AS O

SELECT * FROM #TemporaryTable

DROP TABLE #TemporaryTable

/*
	DML Change
*/

-- Temporary Table
CREATE TABLE #TemporaryTable (Col nvarchar(max));

INSERT INTO #TemporaryTable (Col) VALUES ('A'), ('B');

SELECT * FROM #TemporaryTable

ALTER TABLE #TemporaryTable ADD Col2 nvarchar(max);

SELECT * FROM #TemporaryTable

DROP TABLE #TemporaryTable

/*
	Defined type
*/

-- Table Variable - type
DROP TYPE IF EXISTS dbo.TableVariableType
GO

CREATE TYPE dbo.TableVariableType AS TABLE
(
	Col nvarchar(max)
)
GO

DECLARE @TableVariable TableVariableType;

INSERT INTO @TableVariable(Col) VALUES ('A'), ('B');

SELECT * FROM @TableVariable
GO

DROP TYPE dbo.TableVariableType
GO