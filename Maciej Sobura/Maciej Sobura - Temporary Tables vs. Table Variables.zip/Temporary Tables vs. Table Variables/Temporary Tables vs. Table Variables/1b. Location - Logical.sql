USE TempTableAndTableVariable
GO

SELECT
	tempdb = DATABASEPROPERTYEX(N'tempdb', 'collation');
-- Latin1_General_100_CI_AS

SELECT
	Db = DATABASEPROPERTYEX(N'TempTableAndTableVariable', 'collation');
-- Polish_100_CI_AS
GO

DROP TABLE IF EXISTS dbo.PolishTable
GO

CREATE TABLE dbo.PolishTable
(
	Col varchar(10)
);

DROP TABLE IF EXISTS dbo.LatinTable
GO

CREATE TABLE dbo.LatinTable
(
	Col varchar(10) COLLATE Latin1_General_100_CI_AS
);

SELECT
	OBJECT_NAME(C.object_id),
	C.name,
	C.collation_name
FROM sys.columns AS C
WHERE C.object_id IN (OBJECT_ID('dbo.PolishTable'), OBJECT_ID('dbo.LatinTable'))

-- Table variable
DECLARE @TableVariable TABLE ([77E939DE-07AD-440B-A077-BC36FF1E4DAA] varchar(10));

SELECT *
FROM @TableVariable AS TV
    JOIN dbo.PolishTable AS PT ON PT.Col = TV.[77E939DE-07AD-440B-A077-BC36FF1E4DAA];
    
SELECT *
FROM @TableVariable AS TV
    JOIN dbo.LatinTable AS LT ON LT.Col = TV.[77E939DE-07AD-440B-A077-BC36FF1E4DAA];

SELECT
	C.name,
	C.collation_name
FROM tempdb.sys.columns AS C
WHERE C.name = '77E939DE-07AD-440B-A077-BC36FF1E4DAA'
GO

-- Temporary table
CREATE TABLE #TemporaryTable ([6F8DDD31-479A-4D29-88DF-3C99D3DEEFCC] varchar(10));

--SELECT *
--FROM #TemporaryTable AS TT
--    JOIN dbo.PolishTable AS PT ON PT.Col = TT.[6F8DDD31-479A-4D29-88DF-3C99D3DEEFCC];
    
--SELECT *
--FROM #TemporaryTable AS TT
--    JOIN dbo.LatinTable AS LT ON LT.Col = TT.[6F8DDD31-479A-4D29-88DF-3C99D3DEEFCC];

SELECT
	C.name,
	C.collation_name
FROM tempdb.sys.columns AS C
WHERE C.name = '6F8DDD31-479A-4D29-88DF-3C99D3DEEFCC'
GO

DROP TABLE #TemporaryTable;
GO

CREATE TABLE #TemporaryTable ([7C3D4D1B-74E5-4633-BF4E-3498F577902F] varchar(10) COLLATE database_default);

SELECT *
FROM #TemporaryTable AS TT
    JOIN dbo.PolishTable AS PT ON PT.Col = TT.[7C3D4D1B-74E5-4633-BF4E-3498F577902F];

SELECT
	C.name,
	C.collation_name
FROM tempdb.sys.columns AS C
WHERE C.name = '7C3D4D1B-74E5-4633-BF4E-3498F577902F'

DROP TABLE #TemporaryTable;
GO

DROP TABLE dbo.PolishTable;
DROP TABLE dbo.LatinTable;