USE TempTableAndTableVariable
GO

-- Include Actual Execution Plan

DECLARE @TableVariable TABLE ([5986554F-F23A-43F5-8ABC-D2E4F59D7B75] int);
CREATE TABLE #TemporaryTable ([DA39B6B1-780E-4ACD-800D-8FC000839202] int);

INSERT INTO @TableVariable 
SELECT TOP (50)
	ROW_NUMBER() OVER(ORDER BY NEWID())
FROM sys.objects

INSERT INTO #TemporaryTable
SELECT *
FROM @TableVariable

SELECT COUNT(*) FROM @TableVariable;
SELECT COUNT(*) FROM #TemporaryTable;

SELECT
     P.partition_id,
	 Name = OBJECT_NAME(P.object_id),
     P.object_id,
     P.index_id,
     P.partition_number,
     P.hobt_id,
     P.rows,
     P.filestream_filegroup_id,
     P.data_compression,
     P.data_compression_desc
FROM tempdb.sys.partitions AS P
    JOIN tempdb.sys.columns AS C ON P.object_id = C.object_id
WHERE C.name IN (
		'5986554F-F23A-43F5-8ABC-D2E4F59D7B75',
		'DA39B6B1-780E-4ACD-800D-8FC000839202'
	);

DROP TABLE #TemporaryTable;
GO

/*
	Stored procedure recompile caused by alter table on temp table
	https://blogs.msdn.microsoft.com/psssql/2011/07/15/stored-procedure-recompile-caused-by-alter-table-on-temp-table/

	This is a feature called deferred compile.
	When the procedure is compiled, the query involving temp table is not even compiled.
	We wait until first time the query is executed.
*/

-- Query recompilation
DECLARE @TableVariable TABLE (Val int);

INSERT INTO @TableVariable (Val)
SELECT TOP (50)
	ROW_NUMBER() OVER(ORDER BY NEWID())
FROM sys.objects

SELECT COUNT(*) FROM @TableVariable;

SELECT COUNT(*) FROM @TableVariable OPTION (RECOMPILE);
GO


-- JOIN Table Variable & Table
DROP TABLE IF EXISTS dbo.PermTable
GO
CREATE TABLE dbo.PermTable (Val int PRIMARY KEY);
INSERT INTO PermTable (Val)
SELECT TOP (10000)
	ROW_NUMBER() OVER(ORDER BY NEWID())
FROM sys.all_objects AS O1, sys.objects AS O2


SET STATISTICS IO ON;

DECLARE @TableVariable TABLE (Val int PRIMARY KEY);

INSERT INTO @TableVariable (Val)
SELECT TOP (1000) PT.Val FROM dbo.PermTable AS PT ORDER BY NEWID();

SELECT COUNT(*)
FROM dbo.PermTable AS PT
	JOIN @TableVariable AS TV ON TV.Val = PT.Val
OPTION (RECOMPILE)
 
SET STATISTICS IO OFF;
GO

DROP TABLE IF EXISTS dbo.PermTable

-- FIX: Poor performance when you use table variables in SQL Server 2012 or SQL Server 2014
-- https://support.microsoft.com/en-us/kb/2952444
-- Since SQL Server 2012 Service Pack 2 and SQL Server 2014 Cumulative Update #3:
-- After you apply this hotfix, you can turn on trace flag 2453 to allow a table variable
--  to trigger recompile when enough number of rows are changed.
-- This (!) may (!) allow the query optimizer to choose a more efficient plan. 

-- Trace Flag ver.1
DBCC TRACEON(2453);
 
DECLARE @TableVariable TABLE (Val int);

INSERT INTO @TableVariable (Val)
SELECT TOP (50)
	ROW_NUMBER() OVER(ORDER BY NEWID())
FROM sys.objects

SELECT COUNT(*) FROM @TableVariable;

SELECT COUNT(*) FROM @TableVariable OPTION (RECOMPILE);
 
DBCC TRACEOFF(2453);
GO

-- If a table variable (!) is joined with other tables (!) in SQL Server,
--  it may result in slow performance due to inefficient query plan selection
--  because SQL Server does not support statistics or track number of rows
--  in a table variable while compiling a query plan.

-- Trace Flag ver.2 - Join
DROP TABLE IF EXISTS dbo.PermTable
GO
CREATE TABLE dbo.PermTable (Val int PRIMARY KEY);
INSERT INTO PermTable (Val)
SELECT TOP (10000)
	ROW_NUMBER() OVER(ORDER BY NEWID())
FROM sys.all_objects AS O1, sys.objects AS O2


SET STATISTICS IO ON;
DBCC TRACEON(2453);

DECLARE @TableVariable TABLE (Val int PRIMARY KEY);
INSERT INTO @TableVariable (Val)
SELECT TOP (1000)
	PT.Val
FROM dbo.PermTable AS PT
ORDER BY NEWID();

SELECT COUNT(*)
FROM dbo.PermTable AS PT
	JOIN @TableVariable AS TV ON TV.Val = PT.Val
 
DBCC TRACEOFF(2453);
SET STATISTICS IO OFF;
GO

DROP TABLE PermTable;
GO

-- Trace Flag ver.3 - ORDER BY
DBCC TRACEON(2453);
 
DECLARE @TableVariable TABLE (Val int);

INSERT INTO @TableVariable (Val)
SELECT TOP (50)
	ROW_NUMBER() OVER(ORDER BY NEWID())
FROM sys.objects

SELECT * FROM @TableVariable ORDER BY Val;

SELECT * FROM @TableVariable ORDER BY Val OPTION (RECOMPILE);
 
DBCC TRACEOFF(2453);
GO

/*
    Column Statisticts

    Paul White: Page Free Space
    Temporary Tables in Stored Procedures
    http://sqlblog.com/blogs/paul_white/archive/2012/08/15/temporary-tables-in-stored-procedures.aspx
    
    UPDATE STATISTICS Does Not Cause Recompilation for a Cached Temporary Table
    http://connect.microsoft.com/SQLServer/feedback/details/758241/update-statistics-does-not-cause-recompilation-for-a-cached-temporary-table

    Plan Caching in SQL Server 2008
    http://msdn.microsoft.com/en-us/library/ee343986%28v=sql.100%29.aspx
*/