USE TempTableAndTableVariable
GO

-- Table Variable
DECLARE @TableVariable TABLE (Col int);

INSERT INTO @TableVariable(Col) VALUES (1), (2);
GO -- Scope end

SELECT * FROM @TableVariable;
GO


-- Temporary Table
CREATE TABLE #TemporaryTable (Col int);

INSERT INTO #TemporaryTable(Col) VALUES (1), (2);
GO -- Scope end

SELECT * FROM #TemporaryTable;

DROP TABLE #TemporaryTable;

SELECT * FROM #TemporaryTable;
GO

-- Dynamic SQL
DECLARE @TableVariable TABLE (DynamicSQL int);
EXEC sp_executesql N'SELECT * FROM @TableVariable';

CREATE TABLE #TemporaryTable (DynamicSQL int);
EXEC sp_executesql N'SELECT * FROM #TemporaryTable';

DROP TABLE #TemporaryTable;