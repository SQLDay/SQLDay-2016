USE TempTableAndTableVariable
GO

-- Table Variable & Stored Procedure
DROP PROCEDURE IF EXISTS dbo.OuterProc
GO

DROP PROCEDURE IF EXISTS dbo.InnerProc
GO

CREATE PROCEDURE dbo.InnerProc
AS
BEGIN
    SET NOCOUNT ON;
    
    INSERT INTO @TableVariable (ProcName) VALUES ('Inner');
END
GO

CREATE PROCEDURE dbo.OuterProc
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @TableVariable TABLE (ProcName nvarchar(max));
    
	INSERT INTO @TableVariable (ProcName) VALUES ('Outer')
    
    EXEC dbo.InnerProc;
    
    SELECT * FROM @TableVariable;
END
GO

SET STATISTICS IO ON;

EXEC dbo.OuterProc;

SET STATISTICS IO OFF;


-- Temporary Table & Stored Procedure
DROP PROCEDURE IF EXISTS dbo.OuterProc
GO

DROP PROCEDURE IF EXISTS dbo.InnerProc
GO

CREATE PROCEDURE dbo.InnerProc
AS
BEGIN
    SET NOCOUNT ON;
    
    INSERT INTO #TemporaryTable (ProcName) VALUES ('Inner');
END
GO

CREATE PROCEDURE dbo.OuterProc
AS
BEGIN
    SET NOCOUNT ON;

    CREATE TABLE #TemporaryTable (ProcName nvarchar(max));
    INSERT INTO #TemporaryTable (ProcName) VALUES ('Outer')
    
    EXEC dbo.InnerProc;
    
    SELECT * FROM #TemporaryTable;
    
    DROP TABLE #TemporaryTable;
END
GO

SET STATISTICS IO ON;

EXEC dbo.OuterProc;

SET STATISTICS IO OFF;


-- Temporary Table & Stored Procedure - INSERT
DROP PROCEDURE IF EXISTS dbo.OuterProc
GO

DROP PROCEDURE IF EXISTS dbo.InnerProc
GO

CREATE PROCEDURE dbo.InnerProc
AS
BEGIN
    SET NOCOUNT ON;

	PRINT 'InnerProc - SELECT * FROM #TemporaryTable'
	SELECT * FROM #TemporaryTable

    PRINT 'InnerProc - CREATE TABLE #TemporaryTable (ProcName nvarchar(max));'
	CREATE TABLE #TemporaryTable (ProcName nvarchar(max)); -- ?
    INSERT INTO #TemporaryTable (ProcName) VALUES ('Inner');
    
    SELECT * FROM #TemporaryTable
   
	PRINT 'InnerProc - DROP TABLE #TemporaryTable'
    DROP TABLE #TemporaryTable
    
    SELECT * FROM #TemporaryTable
END
GO

CREATE PROCEDURE dbo.OuterProc
AS
BEGIN
    SET NOCOUNT ON;

    CREATE TABLE #TemporaryTable (ProcName nvarchar(max));
	PRINT 'OuterProc - INSERT INTO #TemporaryTable (ProcName) VALUES (''Outer'')'
    INSERT INTO #TemporaryTable (ProcName) VALUES ('Outer')
    
    EXEC dbo.InnerProc;
    
	PRINT 'OuterProc - SELECT * FROM #TemporaryTable'
    SELECT * FROM #TemporaryTable;
    
    DROP TABLE #TemporaryTable;
END
GO

SET STATISTICS IO ON;

EXEC dbo.OuterProc;

SET STATISTICS IO OFF;


-- Temporary Table & Stored Procedure - INSERT ver.2
DROP PROCEDURE IF EXISTS dbo.OuterProc
GO

DROP PROCEDURE IF EXISTS dbo.InnerProc
GO

CREATE PROCEDURE dbo.InnerProc
AS
BEGIN    
    SET NOCOUNT ON;
    
	PRINT 'InnerProc - SELECT * FROM #TemporaryTable'
	SELECT * FROM #TemporaryTable

    PRINT 'InnerProc - CREATE TABLE #TemporaryTable (ColA nvarchar(max));'
    CREATE TABLE #TemporaryTable (InnerProcName nvarchar(max)); -- ?
    INSERT INTO #TemporaryTable (InnerProcName) VALUES ('Inner');
    
    SELECT * FROM #TemporaryTable
   
	PRINT 'InnerProc - DROP TABLE #TemporaryTable'
    DROP TABLE #TemporaryTable
    
    SELECT * FROM #TemporaryTable
END
GO

CREATE PROCEDURE dbo.OuterProc
AS
BEGIN
    SET NOCOUNT ON;

    CREATE TABLE #TemporaryTable (ProcName nvarchar(max));
	PRINT 'OuterProc - INSERT INTO #TemporaryTable (ProcName) VALUES (''Outer'')'
    INSERT INTO #TemporaryTable (ProcName) VALUES ('Outer')
    
    EXEC dbo.InnerProc;
    
    PRINT 'OuterProc - SELECT * FROM #TemporaryTable'
	SELECT * FROM #TemporaryTable;
    
    DROP TABLE #TemporaryTable;
END
GO

SET STATISTICS IO ON;

EXEC dbo.OuterProc;

SET STATISTICS IO OFF;

/*
	The SQL Server Books Online describes temp tables in nested stored procedures:
	http://msdn.microsoft.com/en-us/library/ms174979.aspx

	Nested stored procedures can also create temporary tables with the same name
		as a temporary table that was created by the stored procedure that called it.
	However, for modifications to resolve to the table that was created in the nested procedure,
		the table must have the same structure, with the same column names,
		as the table created in the calling procedure.
*/


-- Temporary Table & Stored Procedure - INSERT ver.3
DROP PROCEDURE IF EXISTS dbo.OuterProc
GO

DROP PROCEDURE IF EXISTS dbo.InnerProc
GO

CREATE PROCEDURE dbo.InnerProc
AS
BEGIN
    SET NOCOUNT ON;
    
	PRINT 'InnerProc - SELECT * FROM #TemporaryTable'
	SELECT * FROM #TemporaryTable

    PRINT 'InnerProc - CREATE TABLE #TemporaryTable (ColA nvarchar(max));'
    CREATE TABLE #TemporaryTable (InnerProcName nvarchar(max));
    INSERT INTO #TemporaryTable /* (InnerProcName) */ VALUES ('Inner'); -- ?
    
    SELECT * FROM #TemporaryTable
   
	PRINT 'InnerProc - DROP TABLE #TemporaryTable'
    DROP TABLE #TemporaryTable
    
    SELECT * FROM #TemporaryTable
END
GO

CREATE PROCEDURE dbo.OuterProc
AS
BEGIN
    SET NOCOUNT ON;

    CREATE TABLE #TemporaryTable (ProcName nvarchar(max));
	PRINT 'OuterProc - INSERT INTO #TemporaryTable (ProcName) VALUES (''Outer'')'
    INSERT INTO #TemporaryTable (ProcName) VALUES ('Outer')
    
    EXEC dbo.InnerProc;
    
	PRINT 'OuterProc - SELECT * FROM #TemporaryTable'
    SELECT * FROM #TemporaryTable;
    
    DROP TABLE #TemporaryTable;
END
GO

SET STATISTICS IO ON;

EXEC dbo.OuterProc;

SET STATISTICS IO OFF;



-- Temporary Table & Stored Procedure - INSERT ver.4
DROP PROCEDURE IF EXISTS dbo.OuterProc
GO

DROP PROCEDURE IF EXISTS dbo.InnerProc
GO

CREATE PROCEDURE dbo.InnerProc
AS
BEGIN
    SET NOCOUNT ON;
    
	PRINT 'InnerProc - SELECT * FROM #TemporaryTable'
	SELECT * FROM #TemporaryTable

    PRINT 'InnerProc - SELECT * INTO #TemporaryTable'
    SELECT *
		INTO #TemporaryTable -- ?
    FROM (
		SELECT
			InnerProcName = 'Inner'
    ) AS tmp
    
    SELECT * FROM #TemporaryTable
   
	PRINT 'InnerProc - DROP TABLE #TemporaryTable'
    DROP TABLE #TemporaryTable
    
    SELECT * FROM #TemporaryTable
END
GO

CREATE PROCEDURE dbo.OuterProc
AS
BEGIN
    SET NOCOUNT ON;

    CREATE TABLE #TemporaryTable (ProcName nvarchar(max));
	PRINT 'OuterProc - INSERT INTO #TemporaryTable (ProcName) VALUES (''Outer'')'
    INSERT INTO #TemporaryTable (ProcName) VALUES ('Outer')
    
    EXEC dbo.InnerProc;
    
	PRINT 'OuterProc - SELECT * FROM #TemporaryTable'
    SELECT * FROM #TemporaryTable;
    
    DROP TABLE #TemporaryTable;
END
GO

SET STATISTICS IO ON;

EXEC dbo.OuterProc;

SET STATISTICS IO OFF;



-- Temporary Table & Stored Procedure - INSERT ver.4 & DELETE
DROP PROCEDURE IF EXISTS dbo.OuterProc
GO

DROP PROCEDURE IF EXISTS dbo.InnerProc
GO

CREATE PROCEDURE dbo.InnerProc
AS
BEGIN
    SET NOCOUNT ON;
    
	PRINT 'InnerProc - SELECT * FROM #TemporaryTable'
	SELECT * FROM #TemporaryTable

    PRINT 'InnerProc - SELECT INTO #TemporaryTable'
    SELECT *
		INTO #TemporaryTable
    FROM (
		SELECT
			InnerProcName = 'Inner'
    ) AS tmp
    
    SELECT * FROM #TemporaryTable

	PRINT 'InnerProc - DELETE FROM #TemporaryTable'
	DELETE FROM #TemporaryTable -- ?
		OUTPUT DELETED.*;
   
	PRINT 'InnerProc - DROP TABLE #TemporaryTable'
    DROP TABLE #TemporaryTable
    
    SELECT * FROM #TemporaryTable
END
GO

CREATE PROCEDURE dbo.OuterProc
AS
BEGIN
    SET NOCOUNT ON;

    CREATE TABLE #TemporaryTable (ProcName nvarchar(max));
	PRINT 'INSERT INTO #TemporaryTable (ProcName) VALUES (''Outer'')'
    INSERT INTO #TemporaryTable (ProcName) VALUES ('Outer')
    
    EXEC dbo.InnerProc;
    
	PRINT 'OuterProc - SELECT * FROM #TemporaryTable'
    SELECT * FROM #TemporaryTable;
    
    DROP TABLE #TemporaryTable;
END
GO

SET STATISTICS IO ON;

EXEC dbo.OuterProc;

SET STATISTICS IO OFF;



-- Temporary Table & Stored Procedure - INSERT ver.4 & DELETE ver.2
DROP PROCEDURE IF EXISTS dbo.OuterProc
GO

DROP PROCEDURE IF EXISTS dbo.InnerProc
GO

CREATE PROCEDURE dbo.InnerProc
AS
BEGIN
    SET NOCOUNT ON;

	PRINT 'InnerProc - SELECT * FROM #TemporaryTable'
	SELECT * FROM #TemporaryTable

    PRINT 'InnerProc - SELECT * INTO #TemporaryTable'
    SELECT *
		INTO #TemporaryTable
    FROM (
		SELECT
			InnerProcName = 'Inner'
    ) AS tmp
    
    SELECT * FROM #TemporaryTable

	PRINT 'InnerProc - DELETE FROM #TemporaryTable'
    DELETE FROM #TemporaryTable -- ?
		OUTPUT DELETED.*
	--WHERE InnerProcName IS NOT NULL
	WHERE ProcName IS NOT NULL
    
    DROP TABLE #TemporaryTable
END
GO

CREATE PROCEDURE dbo.OuterProc
AS
BEGIN
    SET NOCOUNT ON;

    CREATE TABLE #TemporaryTable (ProcName nvarchar(max));
	PRINT 'INSERT INTO #TemporaryTable (ProcName) VALUES (''Outer'')'
    INSERT INTO #TemporaryTable (ProcName) VALUES ('Outer')
    
    EXEC dbo.InnerProc;
    
	PRINT 'OuterProc - SELECT * FROM #TemporaryTable'
    SELECT * FROM #TemporaryTable;
    
    DROP TABLE #TemporaryTable;
END
GO

SET STATISTICS IO ON;

EXEC dbo.OuterProc;

SET STATISTICS IO OFF;


-- Temporary Table & Stored Procedure - INSERT ver.4 & UPDATE
DROP PROCEDURE IF EXISTS dbo.OuterProc
GO

DROP PROCEDURE IF EXISTS dbo.InnerProc
GO

CREATE PROCEDURE dbo.InnerProc
AS
BEGIN
    SET NOCOUNT ON;

	PRINT 'InnerProc - SELECT * FROM #TemporaryTable'
	SELECT * FROM #TemporaryTable

    PRINT 'InnerProc - SELECT * INTO #TemporaryTable'
    SELECT *
		INTO #TemporaryTable
    FROM (
		SELECT
			ColA = 'Inner'
    ) AS tmp
    
    SELECT * FROM #TemporaryTable

	PRINT 'InnerProc - UPDATE #TemporaryTable SET'
	UPDATE #TemporaryTable SET
		--ColA = NULL
		ProcName = NULL
    
    DROP TABLE #TemporaryTable
END
GO

CREATE PROCEDURE dbo.OuterProc
AS
BEGIN
    SET NOCOUNT ON;

    CREATE TABLE #TemporaryTable (ProcName nvarchar(max));
	PRINT 'INSERT INTO #TemporaryTable (ProcName) VALUES (''Outer'')'
    INSERT INTO #TemporaryTable (ProcName) VALUES ('Outer')
    
    EXEC dbo.InnerProc;
    
	PRINT 'OuterProc - SELECT * FROM #TemporaryTable'
    SELECT * FROM #TemporaryTable;
    
    DROP TABLE #TemporaryTable;
END
GO

SET STATISTICS IO ON;

EXEC dbo.OuterProc;

SET STATISTICS IO OFF;

DROP PROCEDURE dbo.OuterProc
DROP PROCEDURE dbo.InnerProc
GO

/*
	Compiled Stored Procedure
*/

DROP PROCEDURE IF EXISTS dbo.OuterProc
GO

-- Compiled Stored Procedure - Temporary Table
CREATE PROCEDURE dbo.OuterProc
WITH NATIVE_COMPILATION, SCHEMABINDING, EXECUTE AS OWNER
AS BEGIN ATOMIC WITH 
(
        TRANSACTION ISOLATION LEVEL = SNAPSHOT,
        LANGUAGE = N'us_english'
)
    CREATE TABLE #TemporaryTable (ProcName nvarchar(max));
    INSERT INTO #TemporaryTable (ProcName) VALUES ('Outer');
    
    DROP TABLE #TemporaryTable;
END
GO

/*
	Transact-SQL Constructs Not Supported by In-Memory OLTP
    http://msdn.microsoft.com/en-us/library/dn246937%28v=sql.120%29.aspx

	Tables in tempdb cannot be used in natively compiled stored procedures.
	Instead, use a table variable or a memory-optimized table with DURABILITY=SCHEMA_ONLY.
*/


-- Compiled Stored Procedure ver. 1 - Inline Table Variable
CREATE PROCEDURE dbo.OuterProc
WITH NATIVE_COMPILATION, SCHEMABINDING, EXECUTE AS OWNER
AS BEGIN ATOMIC WITH 
(
        TRANSACTION ISOLATION LEVEL = SNAPSHOT,
        LANGUAGE = N'us_english'
)
    DECLARE @TemporaryTable TABLE (ProcName nvarchar(max));
    INSERT INTO @TemporaryTable (ProcName) VALUES ('Outer');
END
GO

-- Compiled Stored Procedure ver. 2 - Table Variable (Type)
DROP TYPE IF EXISTS dbo.TemporaryTableType;
GO

CREATE TYPE dbo.TemporaryTableType AS TABLE
(
	ProcName int PRIMARY KEY NONCLUSTERED
)
GO

CREATE PROCEDURE dbo.OuterProc
WITH NATIVE_COMPILATION, SCHEMABINDING, EXECUTE AS OWNER
AS BEGIN ATOMIC WITH 
(
        TRANSACTION ISOLATION LEVEL = SNAPSHOT,
        LANGUAGE = N'us_english'
)
    DECLARE @TemporaryTable dbo.TemporaryTableType;
    INSERT INTO @TemporaryTable (ProcName) VALUES ('Outer');
END
GO

DROP TYPE dbo.TemporaryTableType;

-- Compiled Stored Procedure ver. 3 - Table Variable (Type) - Memory Optimized
DROP TYPE IF EXISTS dbo.InMemoryTemporaryTableType;
GO

CREATE TYPE dbo.InMemoryTemporaryVariableType AS TABLE
(
	ProcName int PRIMARY KEY NONCLUSTERED
)
	WITH (MEMORY_OPTIMIZED=ON)
GO

DROP PROCEDURE IF EXISTS dbo.OuterProc
GO

CREATE PROCEDURE dbo.OuterProc
	@InMemoryTableVariable dbo.InMemoryTemporaryVariableType READONLY
WITH NATIVE_COMPILATION, SCHEMABINDING, EXECUTE AS OWNER
AS BEGIN ATOMIC WITH 
(
        TRANSACTION ISOLATION LEVEL = SNAPSHOT,
        LANGUAGE = N'us_english'
)
	SELECT
		ProcName, [Text] = 'InMemory'
	FROM @InMemoryTableVariable
END
GO

DECLARE @InMemoryTableVariable dbo.InMemoryTemporaryVariableType

INSERT INTO @InMemoryTableVariable VALUES (1), (2), (3)

EXEC dbo.OuterProc @InMemoryTableVariable;

DROP PROCEDURE dbo.OuterProc;
DROP TYPE dbo.InMemoryTemporaryVariableType;

/*
    Creating a Memory Optimized Table
    https://msdn.microsoft.com/en-us/library/dn133079.aspx

    SQL Server 2014 In Memory OLTP: Memory-Optimized Table Types and Table Variables
    https://blogs.technet.com/b/dataplatforminsider/archive/2014/01/07/sql-server-2014-in-memory-oltp-memory-optimized-table-types-and-table-variables.aspx

	- The variables are truly in memory: they are guaranteed to never spill to disk.
	- Data access is more efficient due to the same memory-optimized algorithm
		and data structures used for memory-optimized tables,
		especially when the variables are used in natively compiled stored procedures.
	- Finally, with memory-optimized table variables there is no tempdb utilization:
		table variables are not in tempdb, and do not use any resources in tempdb.
*/