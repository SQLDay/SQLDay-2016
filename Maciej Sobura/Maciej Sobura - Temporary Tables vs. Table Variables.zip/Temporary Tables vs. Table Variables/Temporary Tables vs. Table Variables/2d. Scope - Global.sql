USE TempTableAndTableVariable
GO


-- Temporary Table
CREATE TABLE #LocalTemporaryTable (Flag int);
INSERT INTO #LocalTemporaryTable (Flag) VALUES (0);

SELECT * FROM #LocalTemporaryTable

DROP TABLE #LocalTemporaryTable;



-- Global Temporary Table
CREATE TABLE ##GlobalTemporaryTable (Flag bit);
INSERT INTO ##GlobalTemporaryTable (Flag) VALUES (0);

SELECT * FROM ##GlobalTemporaryTable

DROP TABLE ##GlobalTemporaryTable

DROP PROCEDURE IF EXISTS dbo.SampleProc
GO

CREATE PROCEDURE dbo.SampleProc
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @Message nvarchar(max);
	SET @Message = CAST(SYSDATETIME() AS nvarchar(max));

	RAISERROR (@Message, 0, 1) WITH NOWAIT;

	WAITFOR DELAY '00:00:02'
END
GO

WHILE (1 = 1)
BEGIN
	EXEC dbo.SampleProc;
END

CREATE TABLE ##GlobalTemporaryTable (Flag bit);
INSERT INTO ##GlobalTemporaryTable (Flag) VALUES (0);

WHILE (1 = 1)
BEGIN
	IF EXISTS (
		SELECT *
		FROM ##GlobalTemporaryTable
		WHERE Flag = 1
	)
	BEGIN
		PRINT 'Loop end'
		RETURN;
	END

	EXEC dbo.SampleProc;
END

/*
	Copy to other connection

	UPDATE ##GlobalTemporaryTable SET Flag = 1
*/

DROP PROCEDURE dbo.SampleProc
DROP TABLE ##GlobalTemporaryTable;