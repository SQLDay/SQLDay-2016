USE master
GO

IF EXISTS (SELECT name FROM sys.databases WHERE name = N'TempTableAndTableVariable')
BEGIN
    ALTER DATABASE TempTableAndTableVariable SET SINGLE_USER WITH ROLLBACK IMMEDIATE
    DROP DATABASE TempTableAndTableVariable
END
GO

CREATE DATABASE TempTableAndTableVariable COLLATE Polish_100_CI_AS
GO

ALTER DATABASE TempTableAndTableVariable ADD FILEGROUP Test3
GO

ALTER DATABASE TempTableAndTableVariable ADD FILEGROUP Test4
GO

ALTER DATABASE TempTableAndTableVariable ADD FILEGROUP Test5
GO

ALTER DATABASE TempTableAndTableVariable ADD FILEGROUP Test6
GO

ALTER DATABASE TempTableAndTableVariable
ADD FILE
(
    NAME = Test3,
	FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL13.SQLSERVER2016RC3\MSSQL\DATA\TempTableAndTableVariable3.ndf'
)
TO FILEGROUP [Test3]

ALTER DATABASE TempTableAndTableVariable
ADD FILE
(
    NAME = Test4,
	FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL13.SQLSERVER2016RC3\MSSQL\DATA\TempTableAndTableVariable4.ndf'
)
TO FILEGROUP [Test4]

ALTER DATABASE TempTableAndTableVariable
ADD FILE
(
    NAME = Test5,
	FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL13.SQLSERVER2016RC3\MSSQL\DATA\TempTableAndTableVariable5.ndf'
)
TO FILEGROUP [Test5]

ALTER DATABASE TempTableAndTableVariable
ADD FILE
(
    NAME = Test6,
	FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL13.SQLSERVER2016RC3\MSSQL\DATA\TempTableAndTableVariable6.ndf'
)
TO FILEGROUP [Test6]

ALTER DATABASE TempTableAndTableVariable
REMOVE FILE Test5

ALTER DATABASE TempTableAndTableVariable
REMOVE FILE Test4

ALTER DATABASE TempTableAndTableVariable
REMOVE FILE Test3

ALTER DATABASE TempTableAndTableVariable
	ADD FILEGROUP TestInMemory CONTAINS MEMORY_OPTIMIZED_DATA;

ALTER DATABASE TempTableAndTableVariable
	SET MEMORY_OPTIMIZED_ELEVATE_TO_SNAPSHOT=ON
GO

ALTER DATABASE TempTableAndTableVariable
ADD FILE ( 
    NAME = TestInMemory,
    FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL13.SQLSERVER2016RC3\MSSQL\DATA\TempTableAndTableVariable6'
)
TO FILEGROUP TestInMemory
GO

USE TempTableAndTableVariable
GO

SELECT F.file_id, F.name FROM sys.database_files AS F

USE tempdb
GO

SELECT file_id, name FROM sys.database_files