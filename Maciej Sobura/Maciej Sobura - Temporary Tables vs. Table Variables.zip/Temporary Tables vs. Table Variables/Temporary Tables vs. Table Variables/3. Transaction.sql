USE TempTableAndTableVariable
GO

DECLARE @TableVariable TABLE (Id int, Name nvarchar(max));
INSERT INTO @TableVariable (Id, Name)
VALUES
	(1, 'SQL Day 2016'),
	(2, 'SQL Day 2016 Lite');

CREATE TABLE #TemporaryTable (Id int, Name nvarchar(max));

INSERT INTO #TemporaryTable (Id, Name) SELECT Id, Name FROM @TableVariable;

SELECT Name AS [Before Tran - @TableVariable] FROM @TableVariable;
SELECT Name AS [Before Tran - #TemporaryTable] FROM #TemporaryTable;

BEGIN TRAN

    UPDATE @TableVariable SET Name = 'SQL Saturday' WHERE Id = 2;
    UPDATE #TemporaryTable SET Name = 'SQL Saturday' WHERE Id = 2;
    
    SELECT Name AS [Inside Tran - @TableVariable] FROM @TableVariable;
    SELECT Name AS [Inside Tran - #TemporaryTable] FROM #TemporaryTable;

ROLLBACK -- ?

SELECT Name AS [After Tran - @TableVariable] FROM @TableVariable;
SELECT Name AS [After Tran - #TemporaryTable] FROM #TemporaryTable;

DROP TABLE #TemporaryTable;