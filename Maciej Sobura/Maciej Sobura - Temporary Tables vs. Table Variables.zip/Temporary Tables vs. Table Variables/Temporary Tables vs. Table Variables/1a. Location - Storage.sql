USE TempTableAndTableVariable
GO

SET NOCOUNT ON;

SET STATISTICS IO ON;

-- Table - 'PermTable'
CREATE TABLE dbo.PermTable (Col int PRIMARY KEY) ON [Test6]

INSERT INTO dbo.PermTable(Col) VALUES (1);

SELECT
     [File:Page:Slot] = sys.fn_PhysLocFormatter(%%physloc%%)
FROM PermTable; -- IO

DROP TABLE dbo.PermTable;


-- Temporary Table - #TemporaryTable_0000000000E2
CREATE TABLE #TemporaryTable (Col int PRIMARY KEY);

INSERT INTO #TemporaryTable (Col) VALUES (1);

SELECT
     [File:Page:Slot] = sys.fn_PhysLocFormatter(%%physloc%%)
FROM #TemporaryTable; -- IO

DROP TABLE #TemporaryTable;
GO


-- Table Variable - #BEA4DB61
DECLARE @TableVariable TABLE (Col int PRIMARY KEY);

INSERT INTO @TableVariable(Col) VALUES (1);

SELECT
     [File:Page:Slot] = sys.fn_PhysLocFormatter(%%physloc%%)
FROM @TableVariable; -- IO
GO

SET STATISTICS IO OFF;

/*
	>= SQL Server 2014 - Hekaton - In-memory

	-- Include Actual Exution Plan

	CREATE TABLE ...
	(
		...
	)
		WITH (MEMORY_OPTIMIZED=ON)
*/

CREATE TABLE #TemporaryTable
(
	Col int PRIMARY KEY NONCLUSTERED
)
	WITH (MEMORY_OPTIMIZED=ON)
GO


DECLARE @TemporaryTable TABLE
(
	Col int PRIMARY KEY NONCLUSTERED
)
	WITH (MEMORY_OPTIMIZED=ON)
GO


DROP TYPE IF EXISTS dbo.InMemoryTemporaryVariableType;
GO

CREATE TYPE dbo.InMemoryTemporaryVariableType AS TABLE
(
	Col int PRIMARY KEY NONCLUSTERED
)
	WITH (MEMORY_OPTIMIZED=ON)
GO

SET STATISTICS IO ON;

-- In-Memory Table Variable
DECLARE @InMemoryTableVariable dbo.InMemoryTemporaryVariableType

INSERT @InMemoryTableVariable (Col) VALUES (1)

SELECT * FROM @InMemoryTableVariable;

SET STATISTICS IO OFF;
GO

DROP TYPE dbo.InMemoryTemporaryVariableType

/*
    Creating a Memory Optimized Table
    http://msdn.microsoft.com/en-us/library/dn133079%28v=sql.120%29.aspx
*/