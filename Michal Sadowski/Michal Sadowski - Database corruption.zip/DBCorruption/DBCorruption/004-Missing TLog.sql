-- Missing TLog


--Prep

RESTORE DATABASE [AdventureWorks2014_Demo04] 
FROM  DISK = N'D:\MSSQLServer\MSSQL13.MSSQL2016INST01\MSSQL\Backup\AdventureWorks2014-FullRecovery.bak' 
WITH  FILE = 1,  
MOVE N'AdventureWorks2014_Default' 
TO N'D:\MSSQLServer\MSSQL13.MSSQL2016INST01\MSSQL\Data\AdventureWorks2014_Demo04_PRIMARY.mdf',  
MOVE N'AdventureWorks2014_Data' 
TO N'D:\MSSQLServer\MSSQL13.MSSQL2016INST01\MSSQL\Data\AdventureWorks2014_Demo04_Data.ndf',  
MOVE N'AdventureWorks2014_Index' 
TO N'D:\MSSQLServer\MSSQL13.MSSQL2016INST01\MSSQL\Data\AdventureWorks2014_Demo04_Index.ndf',  
MOVE N'AdventureWorks2014_RO' 
TO N'D:\MSSQLServer\MSSQL13.MSSQL2016INST01\MSSQL\Data\AdventureWorks2014_Demo04_RO.ndf',  
MOVE N'AdventureWorks2014_TLog' 
TO N'D:\MSSQLServer\MSSQL13.MSSQL2016INST01\MSSQL\TLog\AdventureWorks2014_Demo04_TLog.ldf',  NOUNLOAD,  STATS = 5
GO


--Stop SQL and remove TLog file

USE [AdventureWorks2014_Demo04]
GO
SELECT * FROM [AdventureWorks2014_Demo04].[Sales].[SalesOrderDetail] 







ALTER DATABASE [AdventureWorks2014_Demo04] 
SET EMERGENCY









ALTER DATABASE [AdventureWorks2014_Demo04] SET SINGLE_USER WITH ROLLBACK IMMEDIATE











DBCC CHECKDB ('AdventureWorks2014_Demo04', REPAIR_ALLOW_DATA_LOSS)








ALTER DATABASE [AdventureWorks2014_Demo04] SET MULTI_USER

USE [AdventureWorks2014_Demo04]
GO
SELECT * FROM [AdventureWorks2014_Demo04].[Sales].[SalesOrderDetail] 







--Cleanup
EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N'AdventureWorks2014_Demo04'
GO
USE [master]
GO
ALTER DATABASE [AdventureWorks2014_Demo04] SET  SINGLE_USER WITH ROLLBACK IMMEDIATE
GO
DROP DATABASE [AdventureWorks2014_Demo04]
GO
