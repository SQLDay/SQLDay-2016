-- Preperation
RESTORE DATABASE [AdventureWorks2014_Demo01] 
FROM  DISK = N'D:\MSSQLServer\MSSQL13.MSSQL2016INST01\MSSQL\Backup\AdventureWorks2014_Demo01.bak' 
WITH  FILE = 1,  NOUNLOAD,  STATS = 20, CONTINUE_AFTER_ERROR
GO


--- Demo starts here





USE [AdventureWorks2014_Demo01]
GO

SELECT ProductModelID, AVG(ListPrice) AS [Average List Price]
FROM [AdventureWorks2014_Demo01].[Production].[Product]
WHERE ListPrice > $1000
GROUP BY ProductModelID
ORDER BY ProductModelID;


-- but SELECT * works...
SELECT * FROM [AdventureWorks2014_Demo01].[Production].[Product]






DBCC CHECKDB (AdventureWorks2014_Demo01) WITH NO_INFOMSGS
GO






DBCC TRACEON (3604);
GO
DBCC PAGE ('AdventureWorks2014_Demo01',1,10296,1)
GO

USE [AdventureWorks2014_Demo01]
GO
SELECT id, indid, name 
FROM sys.sysindexes 
WHERE id = '1973582069' AND indid = 11






-- let's try to rebuild
ALTER INDEX [ix_ncl_ListPrice_ProductModelID] ON [Production].[Product] REBUILD








-- drop and create approach
DROP INDEX [ix_ncl_ListPrice_ProductModelID] ON [Production].[Product]
GO
CREATE NONCLUSTERED INDEX [ix_ncl_ListPrice_ProductModelID] ON [Production].[Product]
(
	[ListPrice] ASC,
	[ProductModelID] ASC
)
GO


-- but what about situation that we have many, many columns in index?






--  we can use some small hack ;)
BEGIN TRAN 
	ALTER 
		INDEX [ix_ncl_ListPrice_ProductModelID] ON [Production].[Product] 
			DISABLE
	ALTER 
		INDEX [ix_ncl_ListPrice_ProductModelID] ON [Production].[Product] 
			REBUILD
COMMIT
GO












-- check if query works
SELECT ProductModelID, AVG(ListPrice) AS [Average List Price]
FROM [AdventureWorks2014_Demo01].[Production].[Product]
WHERE ListPrice > $1000
GROUP BY ProductModelID
ORDER BY ProductModelID;







SELECT * FROM [AdventureWorks2014_Demo01].[Production].[Product]








DBCC CHECKDB (AdventureWorks2014_Demo01) WITH NO_INFOMSGS
GO








SELECT * FROM [msdb].[dbo].[suspect_pages]

/*
The type of error; one of:

1 = An 823 error that causes a suspect page (such as a disk error) or an 824 error other than a bad checksum or a torn page (such as a bad page ID).
2 = Bad checksum.
3 = Torn page.
4 = Restored (page was restored after it was marked bad).
5 = Repaired (DBCC repaired the page).
7 = Deallocated by DBCC.
*/





--Cleanup
DELETE FROM msdb..suspect_pages
GO
EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N'AdventureWorks2014'
GO
USE [master]
GO
ALTER DATABASE [AdventureWorks2014_Demo01] SET  SINGLE_USER WITH ROLLBACK IMMEDIATE
GO
DROP DATABASE [AdventureWorks2014_Demo01]
GO
