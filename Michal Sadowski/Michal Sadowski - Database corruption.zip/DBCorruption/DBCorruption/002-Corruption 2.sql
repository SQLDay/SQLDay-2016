-- Preperation
RESTORE DATABASE [AdventureWorks2014_Demo02] 
FROM  DISK = N'D:\MSSQLServer\MSSQL13.MSSQL2016INST01\MSSQL\Backup\AdventureWorks2014-FullRecovery.bak' 
WITH  FILE = 1,  
MOVE N'AdventureWorks2014_Default' 
TO N'D:\MSSQLServer\MSSQL13.MSSQL2016INST01\MSSQL\Data\AdventureWorks2014_Demo02_PRIMARY.mdf',  
MOVE N'AdventureWorks2014_Data' 
TO N'D:\MSSQLServer\MSSQL13.MSSQL2016INST01\MSSQL\Data\AdventureWorks2014_Demo02_Data.ndf',  
MOVE N'AdventureWorks2014_Index' 
TO N'D:\MSSQLServer\MSSQL13.MSSQL2016INST01\MSSQL\Data\AdventureWorks2014_Demo02_Index.ndf',  
MOVE N'AdventureWorks2014_RO' 
TO N'D:\MSSQLServer\MSSQL13.MSSQL2016INST01\MSSQL\Data\AdventureWorks2014_Demo02_RO.ndf',  
MOVE N'AdventureWorks2014_TLog' 
TO N'D:\MSSQLServer\MSSQL13.MSSQL2016INST01\MSSQL\TLog\AdventureWorks2014_Demo02_TLog.ldf',  NOUNLOAD,  STATS = 5
GO



USE [AdventureWorks2014_Demo02]
GO
CREATE NONCLUSTERED INDEX [ix_ncl_ListPrice_ProductModelID] ON [Production].[Product]
(
	[ListPrice] ASC,
	[ProductModelID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO


BACKUP DATABASE [AdventureWorks2014_Demo02] TO  DISK = N'D:\MSSQLServer\MSSQL13.MSSQL2016INST01\MSSQL\Backup\AdventureWorks2014_Demo02.bak' WITH FORMAT, INIT, COMPRESSION,  STATS = 10
GO

BACKUP LOG [AdventureWorks2014_Demo02] TO  DISK = N'D:\MSSQLServer\MSSQL13.MSSQL2016INST01\MSSQL\Backup\AdventureWorks2014_Demo02-TLog_01.bak' WITH INIT

ALTER DATABASE [AdventureWorks2014_Demo02] SET SINGLE_USER WITH ROLLBACK IMMEDIATE
-- http://www.sqlskills.com/blogs/paul/dbcc-writepage/ ,AdventureWorks2014, file 3, page 8, offset 0, length 1, value 0x00, bufferpool 1
GO
ALTER DATABASE [AdventureWorks2014_Demo02] SET MULTI_USER WITH ROLLBACK IMMEDIATE

--- Demo starts here








USE [AdventureWorks2014_Demo02]
GO
SELECT ProductModelID, AVG(ListPrice) AS [Average List Price]
FROM [Production].[Product]
WHERE ListPrice > $1000
GROUP BY ProductModelID
ORDER BY ProductModelID;








-- check SELECT * 
SELECT * FROM  [AdventureWorks2014_Demo02].[Production].[Product]






DBCC CHECKDB (AdventureWorks2014_Demo02) WITH NO_INFOMSGS
GO








DBCC TRACEON (3604);
GO
DBCC PAGE ('AdventureWorks2014_Demo02',1,929,2)
GO








USE [AdventureWorks2014_Demo02]
GO
SELECT id, indid, name
FROM sys.sysindexes 
WHERE id = '1973582069' AND indid = 1








BEGIN TRAN 
	ALTER 
		INDEX PK_Product_ProductID 
		ON [Production].[Product] DISABLE
	ALTER 
		INDEX PK_Product_ProductID 
		ON [Production].[Product] REBUILD
COMMIT
GO





-- ups, doesn't work...








-- last option - restore from full backup
USE [master]
GO
RESTORE DATABASE [AdventureWorks2014_Demo02] 
FROM  DISK = N'D:\MSSQLServer\MSSQL13.MSSQL2016INST01\MSSQL\Backup\AdventureWorks2014_Demo02.bak' WITH  FILE = 1,  
NORECOVERY,  NOUNLOAD,  STATS = 10

-- but...






-- in Enterprise Edition you can restore single page ;) 
USE [master]
GO
RESTORE DATABASE [AdventureWorks2014_Demo02] 
PAGE='1:929' 
FROM  DISK = N'D:\MSSQLServer\MSSQL13.MSSQL2016INST01\MSSQL\Backup\AdventureWorks2014_Demo02.bak' WITH  FILE = 1,  
NORECOVERY,  NOUNLOAD,  STATS = 10

BACKUP LOG [AdventureWorks2014_Demo02] TO DISK = 'D:\MSSQLServer\MSSQL13.MSSQL2016INST01\MSSQL\Backup\AdventureWorks2014_Demo02_Tail.bak' WITH INIT;
GO

-- ... and restore it again.

RESTORE LOG [AdventureWorks2014_Demo02] FROM DISK = 'D:\MSSQLServer\MSSQL13.MSSQL2016INST01\MSSQL\Backup\AdventureWorks2014_Demo02-TLog_01.bak';
GO


RESTORE LOG [AdventureWorks2014_Demo02] FROM DISK = 'D:\MSSQLServer\MSSQL13.MSSQL2016INST01\MSSQL\Backup\AdventureWorks2014_Demo02_Tail.bak';
GO








-- check if query works
USE [AdventureWorks2014_Demo02]
GO
SELECT ProductModelID, AVG(ListPrice) AS [Average List Price]
FROM [Production].[Product]
WHERE ListPrice > $1000
GROUP BY ProductModelID
ORDER BY ProductModelID;








-- check SELECT * 
SELECT * FROM  [AdventureWorks2014_Demo02].[Production].[Product]




SELECT * FROM msdb.dbo.suspect_pages






--Cleanup
DELETE FROM msdb.dbo.suspect_pages
GO
EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N'AdventureWorks2014_Demo02'
GO
USE [master]
GO
ALTER DATABASE [AdventureWorks2014_Demo02] SET  SINGLE_USER WITH ROLLBACK IMMEDIATE
GO
DROP DATABASE [AdventureWorks2014_Demo02]
GO
