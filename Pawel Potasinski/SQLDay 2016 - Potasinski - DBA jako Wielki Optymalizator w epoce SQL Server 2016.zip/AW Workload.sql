USE AdventureWorks2012;
GO

EXECUTE AS USER = 'david8'
DECLARE @i int = 0
WHILE (@i < 100)
BEGIN
	EXEC sp_get_top_products;
	SET @i = @i + 1;
END
REVERT
GO

EXECUTE AS USER = 'stephen0'
DECLARE @i int = 0
WHILE (@i < 100)
BEGIN
	EXEC sp_get_top_products;
	SET @i = @i + 1;
END
REVERT
GO