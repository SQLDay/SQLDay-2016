USE [master];
GO
RESTORE DATABASE [AdventureWorks2012] 
FROM DISK = N'C:\Program Files\Microsoft SQL Server\MSSQL13.RC3\MSSQL\Backup\AdventureWorks2012.bak' 
WITH FILE = 1,  
MOVE N'AdventureWorks2012_Data' TO N'C:\Program Files\Microsoft SQL Server\MSSQL13.RC3\MSSQL\DATA\AdventureWorks2012_Data.mdf',  
MOVE N'AdventureWorks2012_Log' TO N'C:\Program Files\Microsoft SQL Server\MSSQL13.RC3\MSSQL\DATA\AdventureWorks2012_log.ldf',  
NOUNLOAD, REPLACE, STATS = 5;
GO

ALTER DATABASE AdventureWorks2012 SET COMPATIBILITY_LEVEL = 130;
GO

USE AdventureWorks2012
GO

DROP INDEX AK_Employee_LoginID ON HumanResources.Employee
DROP INDEX AK_Employee_NationalIDNumber ON HumanResources.Employee
DROP INDEX AK_Employee_rowguid ON HumanResources.Employee
DROP INDEX IX_Employee_OrganizationLevel_OrganizationNode ON HumanResources.Employee
DROP INDEX IX_Employee_OrganizationNode ON HumanResources.Employee
DROP INDEX AK_SalesOrderHeader_rowguid ON Sales.SalesOrderHeader
DROP INDEX AK_SalesOrderHeader_SalesOrderNumber ON Sales.SalesOrderHeader
DROP INDEX IX_SalesOrderHeader_CustomerID ON Sales.SalesOrderHeader
DROP INDEX IX_SalesOrderHeader_SalesPersonID ON Sales.SalesOrderHeader
DROP INDEX AK_SalesOrderDetail_rowguid ON Sales.SalesOrderDetail
DROP INDEX IX_SalesOrderDetail_ProductID ON Sales.SalesOrderDetail
GO

CREATE USER stephen0 WITHOUT LOGIN -- North American Sales Manager (hierarchyid = /6/1/)
CREATE USER david8 WITHOUT LOGIN -- regular salesperson (hierarchyid = /6/1/9/)
CREATE USER amy0 WITHOUT LOGIN -- European Sales Manager (hierarchyid = /6/3/)
CREATE USER rachel0 WITHOUT LOGIN -- regular salesperson (hierarchyid = /6/3/1/)

GRANT SELECT ON Sales.SalesOrderHeader TO stephen0, david8, amy0, rachel0
GRANT SELECT ON Sales.SalesOrderDetail TO stephen0, david8, amy0, rachel0
go

CREATE SCHEMA rls
go

CREATE FUNCTION rls.salesPersonPredicate(@SalesPersonID int)
	RETURNS TABLE
	WITH SCHEMABINDING
AS
	RETURN SELECT 1 AS accessResult
	FROM HumanResources.Employee e1
	INNER JOIN HumanResources.Employee e2
		ON e2.OrganizationNode.IsDescendantOf(e1.OrganizationNode) = 1
	WHERE e1.LoginID = 'adventure-works\' + USER_NAME()
	AND e2.BusinessEntityID = @SalesPersonID
go

CREATE FUNCTION rls.salesPersonPredicate_LookupSalesPerson(@SalesOrderID int)
	RETURNS TABLE
	WITH SCHEMABINDING
AS
	RETURN SELECT 1 AS accessResult
	FROM HumanResources.Employee e1
	INNER JOIN HumanResources.Employee e2
		ON e2.OrganizationNode.IsDescendantOf(e1.OrganizationNode) = 1
	INNER JOIN Sales.SalesOrderHeader soh 
		ON e2.BusinessEntityID = soh.SalesPersonID
	WHERE e1.LoginID = 'adventure-works\' + USER_NAME()
	AND soh.SalesOrderID = @SalesOrderID
go

CREATE SECURITY POLICY rls.salesPersonPolicy
	ADD FILTER PREDICATE rls.salesPersonPredicate(SalesPersonID) ON Sales.SalesOrderHeader,
	ADD FILTER PREDICATE rls.salesPersonPredicate_LookupSalesPerson(SalesOrderID) ON Sales.SalesOrderDetail
go

CREATE PROC sp_get_top_products
AS
	SELECT TOP 10 p.Name, SUM(sod.OrderQty) AS TotalOrders
	FROM Sales.SalesOrderDetail sod
	INNER JOIN Production.Product p ON p.ProductID = sod.ProductID
	GROUP BY p.Name 
	ORDER BY TotalOrders DESC
go

GRANT EXECUTE ON sp_get_top_products TO stephen0, david8, amy0, rachel0
go