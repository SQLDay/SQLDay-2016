--*******************************************
--Konfiguracja baz danych
--*******************************************

-------------------------------------
--ALTER DATABASE SCOPED CONFIGURATION
--Parameter sniffing
-------------------------------------

USE [master];
GO
RESTORE DATABASE [AdventureWorks2012] 
FROM DISK = N'C:\Program Files\Microsoft SQL Server\MSSQL13.RC3\MSSQL\Backup\AdventureWorks2012.bak' 
WITH FILE = 1,  
MOVE N'AdventureWorks2012_Data' TO N'C:\Program Files\Microsoft SQL Server\MSSQL13.RC3\MSSQL\DATA\AdventureWorks2012_Data.mdf',  
MOVE N'AdventureWorks2012_Log' TO N'C:\Program Files\Microsoft SQL Server\MSSQL13.RC3\MSSQL\DATA\AdventureWorks2012_log.ldf',  
NOUNLOAD, REPLACE, STATS = 5;
GO

ALTER DATABASE AdventureWorks2012 SET COMPATIBILITY_LEVEL = 130;
GO

USE AdventureWorks2012;
GO

SELECT * FROM sys.database_scoped_configurations;
GO

DROP PROC IF EXISTS dbo.usp_GetOrderDetailsByProduct;
GO
CREATE PROC dbo.usp_GetOrderDetailsByProduct
@ProductID int
AS
SET NOCOUNT ON;
SELECT *
FROM Sales.SalesOrderDetail
WHERE ProductID = @ProductID;
GO

ALTER DATABASE SCOPED CONFIGURATION
CLEAR PROCEDURE_CACHE;
GO

--Parameter sniffing
SET STATISTICS IO ON;
GO
PRINT '---- ProductID = 710 -------------'
EXEC dbo.usp_GetOrderDetailsByProduct 710;
PRINT '---- ProductID = 707 -------------'
EXEC dbo.usp_GetOrderDetailsByProduct 707;
GO
SET STATISTICS IO OFF;
GO

ALTER DATABASE SCOPED CONFIGURATION
CLEAR PROCEDURE_CACHE;
GO

--To teraz odwrotnie
SET STATISTICS IO ON;
GO
PRINT '---- ProductID = 707 -------------'
EXEC dbo.usp_GetOrderDetailsByProduct 707;
PRINT '---- ProductID = 710 -------------'
EXEC dbo.usp_GetOrderDetailsByProduct 710;
GO
SET STATISTICS IO OFF;
GO

/* 

ALTER PROC dbo.usp_GetOrderDetailsByProduct
@ProductID int
AS
SET NOCOUNT ON;
DECLARE @ProdID int;
SET @ProdID = @ProductID;
SELECT *
FROM Sales.SalesOrderDetail
WHERE ProductID = @ProdID
OPTION(RECOMPILE);
GO

*/

ALTER DATABASE SCOPED CONFIGURATION
SET PARAMETER_SNIFFING = OFF;
GO

SELECT * FROM sys.database_scoped_configurations;
GO

ALTER DATABASE SCOPED CONFIGURATION
CLEAR PROCEDURE_CACHE;
GO

SET STATISTICS IO ON;
GO
PRINT '---- ProductID = 710 -------------'
EXEC dbo.usp_GetOrderDetailsByProduct 710;
PRINT '---- ProductID = 707 -------------'
EXEC dbo.usp_GetOrderDetailsByProduct 707;
GO
SET STATISTICS IO OFF;
GO

ALTER DATABASE SCOPED CONFIGURATION
CLEAR PROCEDURE_CACHE;
GO

SET STATISTICS IO ON;
GO
PRINT '---- ProductID = 707 -------------'
EXEC dbo.usp_GetOrderDetailsByProduct 707;
PRINT '---- ProductID = 710 -------------'
EXEC dbo.usp_GetOrderDetailsByProduct 710;
GO
SET STATISTICS IO OFF;
GO

-------------------------------------------------
--Monitoring konfiguracji na poziomie bazy danych
-------------------------------------------------

DECLARE @SQL varchar(max);
SET @SQL = '
DROP TABLE IF EXISTS #temp
CREATE TABLE #temp (
  db sysname,
  name sysname,
  value sql_variant
);'
SELECT @SQL = @SQL + '
INSERT INTO #temp (db, name, value) SELECT TOP 4 ' + 
QUOTENAME(name, '''') + ', name, value FROM ' + 
QUOTENAME(name) + '.sys.database_scoped_configurations;'
FROM sys.databases;
SET @SQL = @SQL + '
SELECT 
  db, 
  [LEGACY_CARDINALITY_ESTIMATION], [MAXDOP], 
  [PARAMETER_SNIFFING], [QUERY_OPTIMIZER_HOTFIXES]
FROM #temp 
PIVOT (MAX(value) 
  FOR name IN (
    [LEGACY_CARDINALITY_ESTIMATION], 
    [MAXDOP], 
    [PARAMETER_SNIFFING], 
    [QUERY_OPTIMIZER_HOTFIXES]
  )
) AS pvt
ORDER BY db;';
EXEC (@SQL);
GO

------------------------------
--Mixed page allocations
------------------------------

--W��czanie/wy��czanie mixed page allocation per baza
ALTER DATABASE AdventureWorks2012 
SET MIXED_PAGE_ALLOCATION ON;
GO

--Sprawdzamy dzia�anie powy�szego
SELECT name, is_mixed_page_allocation_on
FROM sys.databases 
WHERE database_id = DB_ID('AdventureWorks2012');
GO

--Porz�dki
ALTER DATABASE AdventureWorks2012 
SET MIXED_PAGE_ALLOCATION OFF;
GO

--*******************************************
--DMVs
--*******************************************

SELECT 'sys.' + name AS name
FROM sys.system_objects WHERE name LIKE '%dm[_]%'
EXCEPT
SELECT 'sys.' + value FROM STRING_SPLIT('dm_audit_actions,dm_audit_class_type_map,dm_broker_activated_tasks,dm_broker_connections,dm_broker_forwarded_messages,dm_broker_queue_monitors,dm_cdc_errors,dm_cdc_log_scan_sessions,dm_clr_appdomains,dm_clr_loaded_assemblies,dm_clr_properties,dm_clr_tasks,dm_cryptographic_provider_algorithms,dm_cryptographic_provider_keys,dm_cryptographic_provider_properties,dm_cryptographic_provider_sessions,dm_database_encryption_keys,dm_db_database_page_allocations,dm_db_file_space_usage,dm_db_fts_index_physical_stats,dm_db_index_operational_stats,dm_db_index_physical_stats,dm_db_index_usage_stats,dm_db_log_space_usage,dm_db_mirroring_auto_page_repair,dm_db_mirroring_connections,dm_db_mirroring_past_actions,dm_db_missing_index_columns,dm_db_missing_index_details,dm_db_missing_index_group_stats,dm_db_missing_index_groups,dm_db_objects_disabled_on_compatibility_level_change,dm_db_partition_stats,dm_db_persisted_sku_features,dm_db_script_level,dm_db_session_space_usage,dm_db_stats_properties,dm_db_stats_properties_internal,dm_db_task_space_usage,dm_db_uncontained_entities,dm_db_xtp_checkpoint_files,dm_db_xtp_checkpoint_stats,dm_db_xtp_gc_cycle_stats,dm_db_xtp_hash_index_stats,dm_db_xtp_index_stats,dm_db_xtp_memory_consumers,dm_db_xtp_merge_requests,dm_db_xtp_nonclustered_index_stats,dm_db_xtp_object_stats,dm_db_xtp_table_memory_stats,dm_db_xtp_transactions,dm_exec_background_job_queue,dm_exec_background_job_queue_stats,dm_exec_cached_plan_dependent_objects,dm_exec_cached_plans,dm_exec_connections,dm_exec_cursors,dm_exec_describe_first_result_set,dm_exec_describe_first_result_set_for_object,dm_exec_plan_attributes,dm_exec_procedure_stats,dm_exec_query_memory_grants,dm_exec_query_optimizer_info,dm_exec_query_plan,dm_exec_query_profiles,dm_exec_query_resource_semaphores,dm_exec_query_stats,dm_exec_query_transformation_stats,dm_exec_requests,dm_exec_sessions,dm_exec_sql_text,dm_exec_text_query_plan,dm_exec_trigger_stats,dm_exec_xml_handles,dm_filestream_file_io_handles,dm_filestream_file_io_requests,dm_filestream_non_transacted_handles,dm_fts_active_catalogs,dm_fts_fdhosts,dm_fts_index_keywords,dm_fts_index_keywords_by_document,dm_fts_index_keywords_by_property,dm_fts_index_population,dm_fts_memory_buffers,dm_fts_memory_pools,dm_fts_outstanding_batches,dm_fts_parser,dm_fts_population_ranges,dm_fts_semantic_similarity_population,dm_hadr_auto_page_repair,dm_hadr_availability_group_states,dm_hadr_availability_replica_cluster_nodes,dm_hadr_availability_replica_cluster_states,dm_hadr_availability_replica_states,dm_hadr_cluster,dm_hadr_cluster_members,dm_hadr_cluster_networks,dm_hadr_database_replica_cluster_states,dm_hadr_database_replica_states,dm_hadr_instance_node_map,dm_hadr_name_id_map,dm_io_backup_tapes,dm_io_cluster_shared_drives,dm_io_cluster_valid_path_names,dm_io_pending_io_requests,dm_io_virtual_file_stats,dm_logconsumer_cachebufferrefs,dm_logconsumer_privatecachebuffers,dm_logpool_consumers,dm_logpool_hashentries,dm_logpool_sharedcachebuffers,dm_logpool_stats,dm_logpoolmgr_freepools,dm_logpoolmgr_respoolsize,dm_logpoolmgr_stats,dm_os_buffer_descriptors,dm_os_buffer_pool_extension_configuration,dm_os_child_instances,dm_os_cluster_nodes,dm_os_cluster_properties,dm_os_dispatcher_pools,dm_os_dispatchers,dm_os_hosts,dm_os_latch_stats,dm_os_loaded_modules,dm_os_memory_allocations,dm_os_memory_broker_clerks,dm_os_memory_brokers,dm_os_memory_cache_clock_hands,dm_os_memory_cache_counters,dm_os_memory_cache_entries,dm_os_memory_cache_hash_tables,dm_os_memory_clerks,dm_os_memory_node_access_stats,dm_os_memory_nodes,dm_os_memory_objects,dm_os_memory_pools,dm_os_nodes,dm_os_performance_counters,dm_os_process_memory,dm_os_ring_buffers,dm_os_schedulers,dm_os_server_diagnostics_log_configurations,dm_os_spinlock_stats,dm_os_stacks,dm_os_sublatches,dm_os_sys_info,dm_os_sys_memory,dm_os_tasks,dm_os_threads,dm_os_virtual_address_dump,dm_os_volume_stats,dm_os_wait_stats,dm_os_waiting_tasks,dm_os_windows_info,dm_os_worker_local_storage,dm_os_workers,dm_qn_subscriptions,dm_repl_articles,dm_repl_schemas,dm_repl_tranhash,dm_repl_traninfo,dm_resource_governor_configuration,dm_resource_governor_resource_pool_affinity,dm_resource_governor_resource_pool_volumes,dm_resource_governor_resource_pools,dm_resource_governor_workload_groups,dm_server_audit_status,dm_server_memory_dumps,dm_server_registry,dm_server_services,dm_sql_referenced_entities,dm_sql_referencing_entities,dm_tcp_listener_states,dm_tran_active_snapshot_database_transactions,dm_tran_active_transactions,dm_tran_commit_table,dm_tran_current_snapshot,dm_tran_current_transaction,dm_tran_database_transactions,dm_tran_locks,dm_tran_session_transactions,dm_tran_top_version_generators,dm_tran_transactions_snapshot,dm_tran_version_store,dm_xe_map_values,dm_xe_object_columns,dm_xe_objects,dm_xe_packages,dm_xe_session_event_actions,dm_xe_session_events,dm_xe_session_object_columns,dm_xe_session_targets,dm_xe_sessions,dm_xtp_gc_queue_stats,dm_xtp_gc_stats,dm_xtp_system_memory_consumers,dm_xtp_threads,dm_xtp_transaction_recent_rows,dm_xtp_transaction_stats', ',')
ORDER BY name DESC;
GO

-----------------------------------
--sys.dm_exec_session_wait_stats
-----------------------------------

SELECT * FROM sys.dm_exec_session_wait_stats 
WHERE session_id = @@SPID
ORDER BY wait_time_ms DESC;
GO

DBCC SQLPERF('sys.dm_exec_session_wait_stats', CLEAR);
GO

DBCC SQLPERF('sys.dm_os_wait_stats', CLEAR);
GO

SELECT * FROM sys.dm_exec_session_wait_stats 
WHERE session_id = @@SPID
ORDER BY wait_time_ms DESC;
GO

--Test - CXPACKET
--Ksi�ga waits'�w (Paul S. Randal): https://www.sqlskills.com/help/waits/

DROP TABLE IF EXISTS #waits;
GO

SELECT * 
INTO #waits
FROM sys.dm_exec_session_wait_stats
WHERE session_id = @@SPID;
GO

USE AdventureWorks2016CTP3;
GO

SELECT *
FROM Sales.SalesOrderDetail_ondisk AS sod
INNER JOIN Production.Product_ondisk AS p 
ON sod.ProductID = p.ProductID
ORDER BY p.Style
--OPTION (MAXDOP 2);
GO

SELECT s.wait_type, s.wait_time_ms - w.wait_time_ms AS wait_time_ms
FROM sys.dm_exec_session_wait_stats AS s
INNER JOIN #waits AS w
ON s.wait_type = w.wait_type AND s.wait_time_ms <> w.wait_time_ms
WHERE s.session_id = @@SPID
UNION
SELECT wait_type, wait_time_ms 
FROM sys.dm_exec_session_wait_stats
WHERE session_id = @@SPID AND wait_type NOT IN (SELECT wait_type FROM #waits)
ORDER BY wait_time_ms DESC;
GO

--***********************************************
--Query Store
--***********************************************

--*** Uruchomi� AW Mess ***

--*** Uruchomi� AW Workload ***

ALTER DATABASE AdventureWorks2012 
SET QUERY_STORE = ON;
GO
ALTER DATABASE AdventureWorks2012 
SET QUERY_STORE (
  INTERVAL_LENGTH_MINUTES = 1, 
  QUERY_CAPTURE_MODE = AUTO
);
GO
ALTER DATABASE AdventureWorks2012 
SET QUERY_STORE CLEAR;
GO

--*** Uruchomi� Profiler (filtr Management Studio) ***

--*** Top Resource Consuming Queries ***

--*** Uruchomi� podejrzane zapytanie ***
USE AdventureWorks2012;
GO

--A z�y programista m�wi: "To nie nasz indeks! Nie chcemy nowinek technicznych!"
USE AdventureWorks2012;
GO

DROP INDEX IX_1
ON [Sales].[SalesOrderHeader];
GO

--*** Uruchomi� Regressed Queries ***

--***********************************************
--Live Query Statistics
--***********************************************

USE AdventureWorks2016CTP3;
GO

SELECT *
FROM Sales.SalesOrderDetail_ondisk AS sod
INNER JOIN Production.Product_ondisk AS p 
ON sod.ProductID = p.ProductID
ORDER BY p.Style;
GO